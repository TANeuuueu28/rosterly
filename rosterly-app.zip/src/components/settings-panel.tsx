"use client";

import { useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  Camera,
  Check,
  CheckCheck,
  Globe,
  Loader2,
  Palette,
  Save,
  ShieldCheck,
  Trash2,
  TriangleAlert,
  UserCog,
} from "lucide-react";
import { Card } from "@/components/ui";
import { useApp, useT } from "@/components/providers";
import { SecuritySection } from "@/components/security-section";
import { LANGS, THEMES, type Lang } from "@/lib/i18n";
import { cn } from "@/lib/ui";

type Initial = {
  name: string;
  language: Lang;
  theme: string;
  photoUrl: string | null;
  email: string | null;
  phone: string | null;
};

function readPhoto(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("read"));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("img"));
      img.onload = () => {
        const S = 256;
        const c = document.createElement("canvas");
        c.width = S;
        c.height = S;
        const ctx = c.getContext("2d");
        if (!ctx) return reject(new Error("ctx"));
        const side = Math.min(img.width, img.height);
        ctx.drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, S, S);
        resolve(c.toDataURL("image/jpeg", 0.78));
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

export function SettingsPanel({ initial }: { initial: Initial }) {
  const router = useRouter();
  const t = useT();
  const { lang, setLang, theme, setTheme } = useApp();
  const fileRef = useRef<HTMLInputElement>(null);

  const [name, setName] = useState(initial.name);
  const [photo, setPhoto] = useState<string | null>(initial.photoUrl);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [confirmWipe, setConfirmWipe] = useState(false);
  const [wiping, setWiping] = useState(false);
  const [, startRefresh] = useTransition();

  const dirty =
    name.trim() !== initial.name ||
    lang !== initial.language ||
    theme !== initial.theme ||
    photo !== initial.photoUrl;

  async function save() {
    setSaving(true);
    try {
      await fetch("/api/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), language: lang, theme, photoUrl: photo }),
      });
      setSaved(true);
      startRefresh(() => router.refresh());
    } finally {
      setSaving(false);
    }
  }

  async function wipe() {
    setWiping(true);
    try {
      await fetch("/api/account", { method: "DELETE" });
      router.push("/login");
      router.refresh();
    } finally {
      setWiping(false);
    }
  }

  return (
    <div className="space-y-5">
      <header className="animate-fade-up">
        <p className="inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.25em] text-acc-300/90">
          <UserCog className="size-3.5" /> {t("set.title")}
        </p>
        <h1 className="font-display mt-3 text-4xl font-bold tracking-tight text-stone-50">
          {t("set.title")}
        </h1>
      </header>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* profile */}
        <Card className="p-6">
          <h2 className="font-display flex items-center gap-2 text-base font-semibold text-stone-100">
            <UserCog className="size-4 text-acc-300" /> {t("set.profile")}
          </h2>
          <div className="mt-5 flex items-center gap-4">
            <button
              onClick={() => fileRef.current?.click()}
              className="group relative"
              aria-label={t("p.photo")}
            >
              {photo ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={photo} alt="" className="size-20 rounded-3xl object-cover ring-1 ring-white/10" />
              ) : (
                <span className="grid size-20 place-items-center rounded-3xl bg-acc-400/15 font-display text-2xl font-bold text-acc-300">
                  {(name || "?").slice(0, 1).toUpperCase()}
                </span>
              )}
              <span className="absolute inset-0 grid place-items-center rounded-3xl bg-black/55 opacity-0 transition-opacity group-hover:opacity-100">
                <Camera className="size-5 text-white" />
              </span>
            </button>
            <div className="min-w-0 flex-1">
              <input
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  setSaved(false);
                }}
                className="w-full rounded-xl border border-white/[0.08] bg-white/[0.03] px-3.5 py-2.5 text-sm text-stone-100 outline-none focus:border-acc-400/50"
              />
              <p className="mt-1.5 truncate text-[11px] text-stone-500">
                {initial.email ?? initial.phone ?? ""}
              </p>
            </div>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={async (e) => {
                const f = e.target.files?.[0];
                if (!f) return;
                try {
                  setPhoto(await readPhoto(f));
                  setSaved(false);
                } catch {}
                e.target.value = "";
              }}
            />
          </div>
        </Card>

        {/* theme */}
        <Card className="p-6">
          <h2 className="font-display flex items-center gap-2 text-base font-semibold text-stone-100">
            <Palette className="size-4 text-acc-300" /> {t("set.theme")}
          </h2>
          <div className="mt-5 flex flex-wrap gap-2.5">
            {THEMES.map((th) => (
              <button
                key={th.id}
                onClick={() => {
                  setTheme(th.id);
                  setSaved(false);
                }}
                className={cn(
                  "flex items-center gap-2 rounded-xl border px-3.5 py-2.5 transition-all",
                  theme === th.id
                    ? "border-white/20 bg-white/[0.06]"
                    : "border-white/[0.08] hover:border-white/[0.16]",
                )}
              >
                <span
                  className="grid size-6 place-items-center rounded-full"
                  style={{ background: `${th.hex}26` }}
                >
                  <span className="size-3 rounded-full" style={{ background: th.hex }} />
                </span>
                <span className="text-xs font-semibold text-stone-200">{t(th.key)}</span>
                {theme === th.id && <Check className="size-3.5 text-stone-300" strokeWidth={3} />}
              </button>
            ))}
          </div>
        </Card>
      </div>

      {/* language */}
      <Card className="p-6">
        <h2 className="font-display flex items-center gap-2 text-base font-semibold text-stone-100">
          <Globe className="size-4 text-acc-300" /> {t("set.language")}
        </h2>
        <div className="mt-5 grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-7">
          {LANGS.map((l) => (
            <button
              key={l.id}
              dir={l.dir}
              onClick={() => {
                setLang(l.id);
                setSaved(false);
              }}
              className={cn(
                "flex items-center gap-2 rounded-2xl border px-3 py-2.5 text-start transition-all",
                lang === l.id
                  ? "border-acc-400/50 bg-acc-400/10"
                  : "border-white/[0.07] hover:border-white/[0.16]",
              )}
            >
              <span className="text-base leading-none">{l.flag}</span>
              <span className="min-w-0 flex-1">
                <span
                  className={cn(
                    "block truncate text-xs font-semibold",
                    lang === l.id ? "text-acc-200" : "text-stone-200",
                  )}
                >
                  {l.native}
                </span>
                <span className="block truncate text-[10px] text-stone-500">{l.english}</span>
              </span>
            </button>
          ))}
        </div>
      </Card>

      {/* save */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-white/[0.06] bg-white/[0.02] px-5 py-4">
        <p className="inline-flex items-center gap-2 text-xs text-stone-500">
          {saved && !dirty ? (
            <span className="inline-flex items-center gap-1.5 font-semibold text-emerald-300">
              <CheckCheck className="size-4" /> {t("set.saved")}
            </span>
          ) : (
            <>
              <ShieldCheck className="size-4 text-emerald-400/80" />
              {t("set.secure")}
            </>
          )}
        </p>
        <button
          onClick={save}
          disabled={saving || !dirty}
          className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-br from-acc-400 to-acc-500 px-5 py-2.5 text-xs font-bold text-ink-950 transition-transform hover:-translate-y-0.5 disabled:opacity-40 disabled:hover:translate-y-0"
        >
          {saving ? <Loader2 className="size-3.5 animate-spin" /> : <Save className="size-3.5" strokeWidth={2.6} />}
          {t("set.save")}
        </button>
      </div>

      {/* security */}
      <SecuritySection />

      {/* danger zone */}
      <Card className="border-rose-400/15 p-6">
        <h2 className="font-display flex items-center gap-2 text-base font-semibold text-rose-300">
          <TriangleAlert className="size-4" /> {t("set.account")}
        </h2>
        <p className="mt-2 max-w-xl text-sm text-stone-500">{t("set.deleteHint")}</p>
        {!confirmWipe ? (
          <button
            onClick={() => setConfirmWipe(true)}
            className="mt-4 inline-flex items-center gap-2 rounded-xl border border-rose-400/30 px-4 py-2.5 text-xs font-bold text-rose-300 transition-colors hover:bg-rose-400/10"
          >
            <Trash2 className="size-3.5" /> {t("set.delete")}
          </button>
        ) : (
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold text-stone-200">{t("set.deleteQ")}</span>
            <button
              onClick={() => setConfirmWipe(false)}
              className="rounded-xl border border-white/[0.08] px-3.5 py-2 text-xs font-semibold text-stone-300"
            >
              {t("c.cancel")}
            </button>
            <button
              onClick={wipe}
              disabled={wiping}
              className="inline-flex items-center gap-1.5 rounded-xl bg-rose-500 px-3.5 py-2 text-xs font-bold text-white disabled:opacity-50"
            >
              {wiping && <Loader2 className="size-3 animate-spin" />}
              {t("c.delete")}
            </button>
          </div>
        )}
      </Card>

      <p className="pb-4 text-center text-[11px] text-stone-600">{t("app.credit")}</p>
    </div>
  );
}
