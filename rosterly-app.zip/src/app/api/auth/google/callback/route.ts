import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, googleConfigured, normalizeEmail } from "@/lib/auth";

export async function GET(req: NextRequest) {
  if (!googleConfigured()) {
    return NextResponse.redirect(new URL("/login", req.url));
  }
  const code = req.nextUrl.searchParams.get("code");
  if (!code) return NextResponse.redirect(new URL("/login?error=google", req.url));

  try {
    const redirectUri = new URL("/api/auth/google/callback", req.nextUrl.origin).toString();
    const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code,
        client_id: process.env.GOOGLE_CLIENT_ID!,
        client_secret: process.env.GOOGLE_CLIENT_SECRET!,
        redirect_uri: redirectUri,
        grant_type: "authorization_code",
      }),
    });
    const token = (await tokenRes.json()) as { access_token?: string };
    if (!token.access_token) throw new Error("no token");

    const profileRes = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
      headers: { Authorization: `Bearer ${token.access_token}` },
    });
    const profile = (await profileRes.json()) as {
      email?: string;
      name?: string;
      picture?: string;
    };
    if (!profile.email) throw new Error("no email");

    const email = normalizeEmail(profile.email);
    const existing = await db.select().from(users).where(eq(users.email, email)).limit(1);

    const userId =
      existing[0]?.id ??
      (
        await db
          .insert(users)
          .values({
            email,
            name: profile.name?.trim() || email.split("@")[0],
            photoUrl: profile.picture ?? null,
            provider: "google",
            emailVerified: true, // Google ne already verify kiya hai
          })
          .returning()
      )[0].id;

    // Google-verified login → mark verification + last login
    await db
      .update(users)
      .set({ emailVerified: true, lastLoginAt: new Date() })
      .where(eq(users.id, userId));

    await createSession(userId, req.headers.get("user-agent"));
    return NextResponse.redirect(new URL("/", req.url));
  } catch {
    return NextResponse.redirect(new URL("/login?error=google", req.url));
  }
}
