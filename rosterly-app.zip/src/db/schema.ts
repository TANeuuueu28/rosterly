import {
  boolean,
  date,
  index,
  integer,
  pgEnum,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";

export const attendanceStatus = pgEnum("attendance_status", [
  "present",
  "absent",
  "leave",
  "half_day",
]);

/** Account — email/phone/Google login, per-user preferences */
export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    email: varchar("email", { length: 200 }),
    phone: varchar("phone", { length: 24 }),
    countryCode: varchar("country_code", { length: 8 }),
    name: varchar("name", { length: 120 }).notNull(),
    photoUrl: text("photo_url"),
    passwordHash: text("password_hash"),
    provider: varchar("provider", { length: 16 }).notNull().default("email"),
    language: varchar("language", { length: 8 }).notNull().default("en"),
    theme: varchar("theme", { length: 16 }).notNull().default("saffron"),
    emailVerified: boolean("email_verified").notNull().default(false),
    phoneVerified: boolean("phone_verified").notNull().default(false),
    failedAttempts: integer("failed_attempts").notNull().default(0),
    lockedUntil: timestamp("locked_until", { withTimezone: true }),
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("users_email_unique").on(t.email),
    uniqueIndex("users_phone_unique").on(t.phone),
  ],
);

export const sessions = pgTable(
  "sessions",
  {
    token: varchar("token", { length: 64 }).primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    userAgent: text("user_agent"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("sessions_user_idx").on(t.userId)],
);

/** One-time codes for signup / login / password reset / contact changes. */
export const otpCodes = pgTable(
  "otp_codes",
  {
    id: serial("id").primaryKey(),
    target: varchar("target", { length: 200 }).notNull(),
    purpose: varchar("purpose", { length: 24 }).notNull(),
    codeHash: text("code_hash").notNull(),
    attempts: integer("attempts").notNull().default(0),
    meta: text("meta"),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("otp_target_idx").on(t.target)],
);

/** "Remember this device" — skips OTP for 14 days on that browser. */
export const trustedDevices = pgTable(
  "trusted_devices",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    token: varchar("token", { length: 64 }).notNull(),
    userAgent: text("user_agent"),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("trusted_devices_token_unique").on(t.token)],
);

/** Org-wide holidays — show up on the calendar, mark the day for everyone */
export const holidays = pgTable(
  "holidays",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    date: date("date", { mode: "string" }).notNull(),
    name: varchar("name", { length: 120 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("holidays_user_date_unique").on(t.userId, t.date)],
);

/** An attendance table — office, school, gym, NGO… anything */
export const groups = pgTable(
  "groups",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 120 }).notNull(),
    kind: varchar("kind", { length: 24 }).notNull().default("office"),
    orgName: varchar("org_name", { length: 160 }),
    memberLabel: varchar("member_label", { length: 40 }).notNull().default("Member"),
    roleLabel: varchar("role_label", { length: 40 }).notNull().default("Role"),
    icon: varchar("icon", { length: 8 }).notNull().default("🏢"),
    color: varchar("color", { length: 16 }).notNull().default("amber"),
    trackTime: varchar("track_time", { length: 4 }).notNull().default("yes"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("groups_user_idx").on(t.userId)],
);

export const members = pgTable(
  "members",
  {
    id: serial("id").primaryKey(),
    groupId: integer("group_id")
      .notNull()
      .references(() => groups.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 120 }).notNull(),
    identifier: varchar("identifier", { length: 40 }),
    role: varchar("role", { length: 120 }),
    phone: varchar("phone", { length: 24 }),
    email: varchar("email", { length: 200 }),
    photoUrl: text("photo_url"),
    color: varchar("color", { length: 16 }).notNull().default("amber"),
    joinDate: date("join_date", { mode: "string" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("members_group_idx").on(t.groupId)],
);

export const attendance = pgTable(
  "attendance",
  {
    id: serial("id").primaryKey(),
    memberId: integer("member_id")
      .notNull()
      .references(() => members.id, { onDelete: "cascade" }),
    date: date("date", { mode: "string" }).notNull(),
    status: attendanceStatus("status").notNull(),
    checkIn: varchar("check_in", { length: 5 }),
    note: text("note"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("attendance_member_date_unique").on(t.memberId, t.date),
    index("attendance_date_idx").on(t.date),
  ],
);

export type User = typeof users.$inferSelect;
export type Group = typeof groups.$inferSelect;
export type Member = typeof members.$inferSelect;
export type AttendanceRecord = typeof attendance.$inferSelect;
export type AttendanceStatus = (typeof attendanceStatus.enumValues)[number];
