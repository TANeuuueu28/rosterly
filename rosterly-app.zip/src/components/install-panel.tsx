"use client";

import { Apple, Download, Package, Smartphone } from "lucide-react";
import { Card } from "@/components/ui";
import { useInstallPrompt } from "@/components/install-app";
import { useT } from "@/components/providers";

export function InstallPanel() {
  const t = useT();
  const { available, install } = useInstallPrompt();

  const steps = [
    { icon: Smartphone, text: t("install.android") },
    { icon: Apple, text: t("install.ios") },
    { icon: Package, text: t("install.apk") },
  ];

  return (
    <div className="space-y-6">
      <header className="animate-fade-up text-center">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/icons/icon-512.png"
          alt="Rosterly"
          className="mx-auto size-24 rounded-[26%] shadow-[0_24px_70px_-18px_var(--acc-glow)]"
        />
        <h1 className="font-display mt-6 text-4xl font-bold tracking-tight text-stone-50">
          {t("install.title")}
        </h1>
        <p className="mx-auto mt-2 max-w-md text-sm text-stone-500">{t("install.sub")}</p>

        <button
          onClick={() => void install()}
          disabled={!available}
          className="mt-6 inline-flex items-center gap-2 rounded-2xl bg-gradient-to-br from-acc-400 to-acc-500 px-7 py-3.5 text-sm font-bold text-ink-950 shadow-[0_18px_44px_-14px_var(--acc-glow)] transition-transform hover:-translate-y-0.5 disabled:opacity-40 disabled:hover:translate-y-0"
        >
          <Download className="size-4" strokeWidth={2.6} />
          {t("install.btn")}
        </button>
        {!available && (
          <p className="mt-3 text-[11px] text-stone-600">
            Chrome / Edge → menu → &ldquo;Install app&rdquo;
          </p>
        )}
      </header>

      <div className="grid gap-3 sm:grid-cols-3">
        {steps.map((s, i) => (
          <Card key={i} className="p-5">
            <div className="grid size-10 place-items-center rounded-2xl bg-acc-400/10 text-acc-300">
              <s.icon className="size-[18px]" strokeWidth={2.2} />
            </div>
            <p className="mt-3 text-sm leading-relaxed text-stone-400">{s.text}</p>
          </Card>
        ))}
      </div>

      <p className="pb-4 text-center text-[11px] text-stone-600">{t("app.credit")}</p>
    </div>
  );
}
