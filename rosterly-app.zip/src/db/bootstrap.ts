import { pool } from "@/db";

/**
 * Self-healing schema — ek nayi khaali database par app khud apni tables
 * bana leta hai (har cold start par ek baar; IF NOT EXISTS = safe no-op).
 */
const DDL = `
DO $$ BEGIN
  CREATE TYPE attendance_status AS ENUM ('present','absent','leave','half_day');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS users (
  id serial PRIMARY KEY,
  email varchar(200),
  phone varchar(24),
  country_code varchar(8),
  name varchar(120) NOT NULL,
  photo_url text,
  password_hash text,
  provider varchar(16) NOT NULL DEFAULT 'email',
  language varchar(8) NOT NULL DEFAULT 'en',
  theme varchar(16) NOT NULL DEFAULT 'saffron',
  email_verified boolean NOT NULL DEFAULT false,
  phone_verified boolean NOT NULL DEFAULT false,
  failed_attempts integer NOT NULL DEFAULT 0,
  locked_until timestamptz,
  last_login_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS users_email_unique ON users (email);
CREATE UNIQUE INDEX IF NOT EXISTS users_phone_unique ON users (phone);

CREATE TABLE IF NOT EXISTS sessions (
  token varchar(64) PRIMARY KEY,
  user_id integer NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at timestamptz NOT NULL,
  user_agent text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS sessions_user_idx ON sessions (user_id);

CREATE TABLE IF NOT EXISTS otp_codes (
  id serial PRIMARY KEY,
  target varchar(200) NOT NULL,
  purpose varchar(24) NOT NULL,
  code_hash text NOT NULL,
  attempts integer NOT NULL DEFAULT 0,
  meta text,
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS otp_target_idx ON otp_codes (target);

CREATE TABLE IF NOT EXISTS holidays (
  id serial PRIMARY KEY,
  user_id integer NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  date date NOT NULL,
  name varchar(120) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS holidays_user_date_unique ON holidays (user_id, date);

CREATE TABLE IF NOT EXISTS trusted_devices (
  id serial PRIMARY KEY,
  user_id integer NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token varchar(64) NOT NULL,
  user_agent text,
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS trusted_devices_token_unique ON trusted_devices (token);

CREATE TABLE IF NOT EXISTS groups (
  id serial PRIMARY KEY,
  user_id integer NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name varchar(120) NOT NULL,
  kind varchar(24) NOT NULL DEFAULT 'office',
  org_name varchar(160),
  member_label varchar(40) NOT NULL DEFAULT 'Member',
  role_label varchar(40) NOT NULL DEFAULT 'Role',
  icon varchar(8) NOT NULL DEFAULT '🏢',
  color varchar(16) NOT NULL DEFAULT 'amber',
  track_time varchar(4) NOT NULL DEFAULT 'yes',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS groups_user_idx ON groups (user_id);

CREATE TABLE IF NOT EXISTS members (
  id serial PRIMARY KEY,
  group_id integer NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
  name varchar(120) NOT NULL,
  identifier varchar(40),
  role varchar(120),
  phone varchar(24),
  email varchar(200),
  photo_url text,
  color varchar(16) NOT NULL DEFAULT 'amber',
  join_date date,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS members_group_idx ON members (group_id);

CREATE TABLE IF NOT EXISTS attendance (
  id serial PRIMARY KEY,
  member_id integer NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  date date NOT NULL,
  status attendance_status NOT NULL,
  check_in varchar(5),
  note text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS attendance_member_date_unique ON attendance (member_id, date);
CREATE INDEX IF NOT EXISTS attendance_date_idx ON attendance (date);

ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verified boolean NOT NULL DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS phone_verified boolean NOT NULL DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS failed_attempts integer NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS locked_until timestamptz;
ALTER TABLE users ADD COLUMN IF NOT EXISTS last_login_at timestamptz;
ALTER TABLE sessions ADD COLUMN IF NOT EXISTS user_agent text;
`;

const globalForBoot = globalThis as typeof globalThis & {
  __haziriDbBoot?: Promise<void>;
};

export function ensureDb(): Promise<void> {
  globalForBoot.__haziriDbBoot ??= (async () => {
    const client = await pool.connect();
    try {
      await client.query(DDL);
    } finally {
      client.release();
    }
  })().catch((err) => {
    // Agar bootstrap fail ho jaye to app normal tarike se error dega — log only.
    console.error("DB bootstrap failed:", err);
    globalForBoot.__haziriDbBoot = undefined;
  });
  return globalForBoot.__haziriDbBoot;
}
