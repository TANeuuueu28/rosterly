import { NextRequest, NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { groups } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, ctx: Ctx) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await ctx.params;
  const groupId = Number(id);
  if (!Number.isFinite(groupId)) {
    return NextResponse.json({ error: "Invalid id" }, { status: 400 });
  }
  try {
    const body = await req.json();
    const patch: Partial<typeof groups.$inferInsert> = {};
    if (body.name !== undefined) patch.name = String(body.name).trim().slice(0, 120);
    if (body.orgName !== undefined)
      patch.orgName = body.orgName ? String(body.orgName).trim().slice(0, 160) : null;
    if (body.memberLabel !== undefined) patch.memberLabel = String(body.memberLabel).slice(0, 40);
    if (body.roleLabel !== undefined) patch.roleLabel = String(body.roleLabel).slice(0, 40);
    if (body.icon !== undefined) patch.icon = String(body.icon).slice(0, 8);
    if (body.color !== undefined) patch.color = String(body.color).slice(0, 16);
    if (body.trackTime !== undefined) patch.trackTime = body.trackTime === false ? "no" : "yes";

    const [updated] = await db
      .update(groups)
      .set(patch)
      .where(and(eq(groups.id, groupId), eq(groups.userId, user.id)))
      .returning();
    if (!updated) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json({ group: updated });
  } catch {
    return NextResponse.json({ error: "Could not update" }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await ctx.params;
  const groupId = Number(id);
  if (!Number.isFinite(groupId)) {
    return NextResponse.json({ error: "Invalid id" }, { status: 400 });
  }
  await db.delete(groups).where(and(eq(groups.id, groupId), eq(groups.userId, user.id)));
  return NextResponse.json({ ok: true });
}
