import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { DM_Sans, Space_Grotesk } from "next/font/google";
import { AppProvider } from "@/components/providers";
import { WelcomeGate } from "@/components/welcome-gate";
import { InstallBanner, ServiceWorkerRegister } from "@/components/install-app";
import { AppShell } from "@/components/app-shell";
import { getViewer } from "@/lib/session-user";
import { langMeta } from "@/lib/i18n";
import "./globals.css";

const spaceGrotesk = Space_Grotesk({ subsets: ["latin"], variable: "--font-space-grotesk" });
const dmSans = DM_Sans({ subsets: ["latin"], variable: "--font-dm-sans" });

export const metadata: Metadata = {
  title: "Rosterly — Attendance for every workplace",
  description:
    "Create attendance tables for any office, school, gym or team. Mark daily attendance, track reports, works offline as an app. Created by Tanuj.",
  applicationName: "Rosterly",
  appleWebApp: { capable: true, statusBarStyle: "black-translucent", title: "Rosterly" },
  formatDetection: { telephone: false },
};

export const viewport: Viewport = { themeColor: "#0b0906" };

export default async function RootLayout({ children }: { children: ReactNode }) {
  const viewer = await getViewer();
  const lang = viewer?.language ?? "en";
  const theme = viewer?.theme ?? "saffron";
  const meta = langMeta(lang);

  return (
    <html lang={lang} dir={meta.dir} data-theme={theme}>
      <body
        className={`${spaceGrotesk.variable} ${dmSans.variable} bg-ink-950 text-stone-200 antialiased`}
      >
        <div className="ambient" aria-hidden />
        <ServiceWorkerRegister />
        <AppProvider initialLang={lang} initialTheme={theme}>
          <WelcomeGate viewerName={viewer?.name ?? null} loggedIn={Boolean(viewer)} />
          <AppShell
            signedIn={Boolean(viewer)}
            userName={viewer?.name ?? null}
            userPhoto={viewer?.photoUrl ?? null}
          >
            {children}
          </AppShell>
          <InstallBanner />
        </AppProvider>
      </body>
    </html>
  );
}
