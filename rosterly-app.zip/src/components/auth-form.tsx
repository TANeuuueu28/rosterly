"use client";

import { useCallback, useEffect, useRef, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import {
  AtSign,
  KeyRound,
  Loader2,
  Lock,
  MailCheck,
  Phone,
  ShieldCheck,
  Smartphone,
  Ticket,
  User,
  ArrowLeft,
} from "lucide-react";
import { Brand } from "@/components/brand";
import { useApp, useT } from "@/components/providers";
import { COUNTRIES } from "@/lib/countries";
import { cn } from "@/lib/ui";

type Mode = "signup" | "login" | "forgot";
type Step = "form" | "otp";

function strengthColor(score: number) {
  return ["bg-rose-500", "bg-rose-500", "bg-orange-400", "bg-amber-400", "bg-emerald-400"][score];
}
function strengthLabel(score: number) {
  return ["Bahut kamzor", "Kamzor", "Theek", "Accha", "Mazboot"][score];
}

export function AuthForm({ googleEnabled }: { googleEnabled: boolean }) {
  const router = useRouter();
  const t = useT();
  const { lang, theme } = useApp();

  const [mode, setMode] = useState<Mode>("signup");
  const [step, setStep] = useState<Step>("form");
  const [method, setMethod] = useState<"email" | "phone">("email");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [country, setCountry] = useState("IN");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const [remember, setRemember] = useState(false);
  const [requireOtp, setRequireOtp] = useState(true);
  const [devCode, setDevCode] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [cooldown, setCooldown] = useState(0);
  const codeRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (step !== "otp") return;
    setCooldown(15);
    const id = setInterval(() => setCooldown((c) => (c <= 1 ? (clearInterval(id), 0) : c - 1)), 1000);
    return () => clearInterval(id);
  }, [step]);

  useEffect(() => {
    if (step === "otp") setTimeout(() => codeRef.current?.focus(), 80);
  }, [step]);

  const dial = COUNTRIES.find((c) => c.code === country)?.dial ?? "+91";
  const score = passwordScoreLocal(password);

  const targetPayload = useCallback((): Record<string, unknown> => {
    if (method === "email") return { email };
    return { phone: `${dial}${phone.replace(/\D/g, "")}`, countryCode: country };
  }, [method, email, phone, dial, country]);

  async function callApi(payload: Record<string, unknown>) {
    const res = await fetch("/api/auth", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json().catch(() => null);
    if (!res.ok) throw new Error(data?.error ?? t("auth.err"));
    return data as Record<string, unknown>;
  }

  function goDone() {
    router.push("/");
    router.refresh();
  }

  async function submitForm(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      if (mode === "signup") {
        const data = await callApi({ action: "signup", name, password, language: lang, theme, ...targetPayload() });
        const dev = (data.devCode as string) ?? null;
        setDevCode(dev);
        if (dev) setCode(dev); // instant: no typing needed
        setStep("otp");
      } else if (mode === "login") {
        const data = await callApi({ action: "login", ...targetPayload() });
        if (data.requireOtp === false) {
          setRequireOtp(false);
          // password-only path for remembered device — verify immediately
          const v = await callApi({ action: "login-verify", password, ...targetPayload() });
          void v;
          goDone();
        } else {
          setRequireOtp(true);
          const dev = (data.devCode as string) ?? null;
          setDevCode(dev);
          if (dev) setCode(dev);
          setStep("otp");
        }
      } else {
        const data = await callApi({ action: "reset-start", ...targetPayload() });
        const dev = (data.devCode as string) ?? null;
        setDevCode(dev);
        if (dev) setCode(dev);
        setStep("otp");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : t("auth.err"));
    } finally {
      setBusy(false);
    }
  }

  async function submitOtp(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      if (mode === "signup") {
        await callApi({ action: "signup-verify", code, ...targetPayload() });
      } else if (mode === "login") {
        await callApi({
          action: "login-verify",
          password,
          code: requireOtp ? code : undefined,
          remember,
          ...targetPayload(),
        });
      } else {
        await callApi({ action: "reset-verify", code, password, ...targetPayload() });
      }
      goDone();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("auth.err"));
    } finally {
      setBusy(false);
    }
  }

  async function resend() {
    if (cooldown > 0) return;
    setBusy(true);
    setError(null);
    try {
      const action = mode === "signup" ? "signup" : mode === "login" ? "login" : "reset-start";
      const data = await callApi({
        action,
        ...(mode === "signup" ? { name, password, language: lang, theme } : {}),
        ...(mode === "login" ? { skipPasswordCheck: true } : {}),
        ...targetPayload(),
      });
              if (mode === "login" && data.requireOtp === false) {
        // remembered device — go straight to password step
        setRequireOtp(false);
        setStep("form");
        return;
      }
      const dev = (data.devCode as string) ?? null;
      setDevCode(dev);
      if (dev) setCode(dev);
      setStep("otp");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Resend fail");
    } finally {
      setBusy(false);
    }
  }

  function backToForm() {
    setStep("form");
    setCode("");
    setDevCode(null);
    setError(null);
  }

  const field =
    "w-full rounded-xl border border-white/[0.08] bg-white/[0.03] py-3 ps-11 pe-4 text-sm text-stone-100 outline-none transition-colors placeholder:text-stone-600 focus:border-acc-400/50";
  const iconCls = "pointer-events-none absolute start-3.5 top-1/2 size-4 -translate-y-1/2 text-stone-600";
  const targetLabel = method === "email" ? email : `${dial}${phone}`;

  return (
    <div className="flex min-h-screen items-center justify-center p-5">
      <motion.div
        initial={{ opacity: 0, y: 22 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className="w-full max-w-md"
      >
        <div className="flex justify-center">
          <Brand size="lg" href={null} />
        </div>

        <div className="mt-8 rounded-3xl border border-white/[0.07] bg-white/[0.02] p-6 shadow-[0_30px_80px_-40px_rgba(0,0,0,0.9)] backdrop-blur-sm sm:p-7">
          {step === "form" ? (
            <>
              <h1 className="font-display text-2xl font-bold tracking-tight text-stone-50">
                {t(mode === "signup" ? "auth.welcome" : mode === "login" ? "auth.signin" : "auth.welcome")}
              </h1>
              <p className="mt-1.5 text-sm text-stone-500">
                {mode === "forgot"
                  ? "Apna email/phone daalo — OTP bhej kar password reset karte hain."
                  : mode === "signup"
                    ? "Account banao — verification ke liye 6-digit code jayega."
                    : "Login ke liye password + OTP dono chahiye (device yaad ho to OTP skip)."}
              </p>

              {mode !== "forgot" && (
                <div className="mt-6 grid grid-cols-2 gap-1 rounded-2xl border border-white/[0.06] bg-white/[0.02] p-1">
                  {(["signup", "login"] as const).map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => {
                        setMode(m);
                        setError(null);
                      }}
                      className={cn(
                        "rounded-xl py-2.5 text-xs font-bold transition-all",
                        mode === m
                          ? "bg-acc-400/15 text-acc-300"
                          : "text-stone-500 hover:text-stone-300",
                      )}
                    >
                      {t(m === "signup" ? "auth.signup" : "auth.signin")}
                    </button>
                  ))}
                </div>
              )}

              <div className="mt-4 grid grid-cols-2 gap-1 rounded-2xl border border-white/[0.06] bg-white/[0.02] p-1">
                {(["email", "phone"] as const).map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setMethod(m)}
                    className={cn(
                      "inline-flex items-center justify-center gap-1.5 rounded-xl py-2 text-[11px] font-bold transition-all",
                      method === m
                        ? "bg-acc-400/15 text-acc-300"
                        : "text-stone-500 hover:text-stone-300",
                    )}
                  >
                    {m === "email" ? <AtSign className="size-3.5" /> : <Phone className="size-3.5" />}
                    {t(m === "email" ? "auth.tabEmail" : "auth.tabPhone")}
                  </button>
                ))}
              </div>

              <form onSubmit={submitForm} className="mt-4 space-y-3">
                {mode === "signup" && (
                  <div className="relative">
                    <User className={iconCls} />
                    <input
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder={t("auth.name")}
                      className={field}
                    />
                  </div>
                )}

                {method === "email" ? (
                  <div className="relative">
                    <AtSign className={iconCls} />
                    <input
                      required
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder={t("auth.email")}
                      className={field}
                    />
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <select
                      value={country}
                      onChange={(e) => setCountry(e.target.value)}
                      aria-label={t("auth.country")}
                      className="w-[128px] shrink-0 rounded-xl border border-white/[0.08] bg-white/[0.03] px-2 py-3 text-sm text-stone-100 outline-none focus:border-acc-400/50"
                    >
                      {COUNTRIES.map((c) => (
                        <option key={c.code} value={c.code} className="bg-ink-900">
                          {c.flag} {c.dial}
                        </option>
                      ))}
                    </select>
                    <div className="relative flex-1">
                      <Smartphone className={iconCls} />
                      <input
                        required
                        inputMode="numeric"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder={t("auth.phone")}
                        className={field}
                      />
                    </div>
                  </div>
                )}

                {mode !== "forgot" && (
                  <div>
                    <div className="relative">
                      <Lock className={iconCls} />
                      <input
                        required
                        type="password"
                        minLength={8}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder={t("auth.password")}
                        className={field}
                      />
                    </div>
                    {mode === "signup" && password && (
                      <div className="mt-2 flex items-center gap-2 px-1">
                        <div className="flex h-1.5 flex-1 gap-1">
                          {[0, 1, 2, 3].map((i) => (
                            <span
                              key={i}
                              className={cn(
                                "h-full flex-1 rounded-full transition-colors",
                                i < score ? strengthColor(score) : "bg-white/[0.08]",
                              )}
                            />
                          ))}
                        </div>
                        <span className="text-[10px] font-semibold text-stone-500">
                          {strengthLabel(score)}
                        </span>
                      </div>
                    )}
                  </div>
                )}

                {error && (
                  <p className="rounded-xl bg-rose-400/10 px-3.5 py-2.5 text-xs font-semibold text-rose-300">
                    {error}
                  </p>
                )}

                <button
                  type="submit"
                  disabled={busy}
                  className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-acc-400 to-acc-500 py-3.5 text-sm font-bold text-ink-950 shadow-[0_16px_40px_-14px_var(--acc-glow)] transition-transform hover:-translate-y-0.5 disabled:opacity-50 disabled:hover:translate-y-0"
                >
                  {busy && <Loader2 className="size-4 animate-spin" />}
                  {mode === "signup"
                    ? "OTP bhejo → account banao"
                    : mode === "login"
                      ? "Login karo"
                      : "Reset code bhejo"}
                </button>
              </form>

              {mode === "login" && (
                <button
                  type="button"
                  onClick={() => {
                    setMode("forgot");
                    setError(null);
                  }}
                  className="mt-3 w-full text-center text-[11px] font-semibold text-stone-500 hover:text-acc-300"
                >
                  Password bhool gaye? OTP se reset karo
                </button>
              )}
              {mode === "forgot" && (
                <button
                  type="button"
                  onClick={() => {
                    setMode("login");
                    setError(null);
                  }}
                  className="mt-3 inline-flex items-center gap-1 text-[11px] font-semibold text-stone-500 hover:text-acc-300"
                >
                  <ArrowLeft className="size-3 rtl:rotate-180" /> Login par wapas
                </button>
              )}

              <div className="my-5 flex items-center gap-3">
                <span className="h-px flex-1 bg-white/[0.07]" />
                <span className="text-[11px] uppercase tracking-widest text-stone-600">
                  {t("auth.or")}
                </span>
                <span className="h-px flex-1 bg-white/[0.07]" />
              </div>

              <a
                href={googleEnabled ? "/api/auth/google" : undefined}
                aria-disabled={!googleEnabled}
                onClick={(e) => {
                  if (!googleEnabled) {
                    e.preventDefault();
                    setError("Google sign-in server env vars se enable hota hai (GOOGLE_CLIENT_ID + SECRET).");
                  }
                }}
                className={cn(
                  "inline-flex w-full items-center justify-center gap-2.5 rounded-xl border border-white/[0.1] bg-white/[0.04] py-3 text-sm font-semibold text-stone-200 transition-colors",
                  googleEnabled ? "hover:bg-white/[0.08]" : "cursor-not-allowed opacity-50",
                )}
              >
                <svg viewBox="0 0 24 24" className="size-4" aria-hidden>
                  <path fill="#4285F4" d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.5a5.6 5.6 0 0 1-2.4 3.7v3h3.9c2.3-2.1 3.5-5.2 3.5-8.9z" />
                  <path fill="#34A853" d="M12 24c3.2 0 5.9-1.1 7.9-2.9l-3.9-3c-1.1.7-2.4 1.2-4 1.2-3.1 0-5.7-2.1-6.6-4.9H1.4v3.1A12 12 0 0 0 12 24z" />
                  <path fill="#FBBC05" d="M5.4 14.4a7.2 7.2 0 0 1 0-4.6V6.7H1.4a12 12 0 0 0 0 10.8l4-3.1z" />
                  <path fill="#EA4335" d="M12 4.8c1.8 0 3.3.6 4.6 1.8l3.4-3.4A12 12 0 0 0 1.4 6.7l4 3.1C6.3 7 8.9 4.8 12 4.8z" />
                </svg>
                {t("auth.google")}
              </a>

              <p className="mt-5 flex items-center justify-center gap-2 text-[11px] text-stone-600">
                <ShieldCheck className="size-3.5 text-emerald-400/80" />
                Password + OTP · 5 galat try par auto-lock
              </p>
            </>
          ) : (
            /* ---------------- OTP STEP ---------------- */
            <motion.form
              onSubmit={submitOtp}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            >
              <button
                type="button"
                onClick={backToForm}
                className="inline-flex items-center gap-1 text-[11px] font-semibold text-stone-500 hover:text-stone-300"
              >
                <ArrowLeft className="size-3.5 rtl:rotate-180" /> {t("c.back")}
              </button>

              <div className="mt-4 grid size-12 place-items-center rounded-2xl bg-acc-400/10 text-acc-300">
                {mode === "forgot" ? <KeyRound className="size-5" /> : <MailCheck className="size-5" />}
              </div>
              <h1 className="font-display mt-4 text-2xl font-bold tracking-tight text-stone-50">
                OTP daalo
              </h1>
              <p className="mt-1.5 text-sm leading-relaxed text-stone-500">
                {mode === "login" ? (
                  <>
                    Password ke saath verification — <b className="text-stone-300">{targetLabel}</b> par
                    6-digit code bheja hai.
                  </>
                ) : (
                  <>
                    <b className="text-stone-300">{targetLabel}</b> par 6-digit verification code
                    bheja hai — 10 minute mein expire hoga.
                  </>
                )}
              </p>

              {devCode && (
                <p className="mt-3 rounded-xl border border-amber-400/25 bg-amber-400/10 px-3.5 py-2.5 text-[11px] leading-relaxed text-amber-200">
                  ⚡ <b>Demo mode:</b> code niche field mein <b>auto-fill</b> ho gaya hai — seedha{" "}
                  <b>Verify</b> dabao! <span className="font-mono text-sm font-bold tracking-[0.3em]">({devCode})</span>
                  <br />
                  <span className="text-amber-200/70">
                    Live par ye code sirf aapke {method === "email" ? "email" : "phone"} par jayega
                    (RESEND_API_KEY / MSG91 keys set karo).
                  </span>
                </p>
              )}

              <div className="relative mt-5">
                <Ticket className={iconCls} />
                <input
                  ref={codeRef}
                  required
                  inputMode="numeric"
                  maxLength={6}
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
                  placeholder="••••••"
                  className={cn(field, "font-mono text-lg tracking-[0.5em] placeholder:text-stone-700")}
                />
              </div>

              {mode === "login" && (
                <>
                  <div className="relative mt-3">
                    <Lock className={iconCls} />
                    <input
                      required
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder={t("auth.password")}
                      className={field}
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => setRemember((v) => !v)}
                    className={cn(
                      "mt-3 inline-flex items-center gap-2 rounded-xl border px-3.5 py-2.5 text-[11px] font-semibold transition-all",
                      remember
                        ? "border-acc-400/40 bg-acc-400/10 text-acc-300"
                        : "border-white/[0.08] text-stone-500 hover:text-stone-300",
                    )}
                  >
                    <span
                      className={cn(
                        "grid size-4 place-items-center rounded border",
                        remember ? "border-acc-400 bg-acc-400 text-ink-950" : "border-white/20",
                      )}
                    >
                      {remember && <Ticket className="size-2.5" strokeWidth={4} />}
                    </span>
                    Is device ko 14 din yaad rakho (OTP skip)
                  </button>
                </>
              )}

              {mode === "forgot" && (
                <div>
                  <div className="relative mt-3">
                    <Lock className={iconCls} />
                    <input
                      required
                      type="password"
                      minLength={8}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Naya password"
                      className={field}
                    />
                  </div>
                </div>
              )}

              {error && (
                <p className="mt-3 rounded-xl bg-rose-400/10 px-3.5 py-2.5 text-xs font-semibold text-rose-300">
                  {error}
                </p>
              )}

              <button
                type="submit"
                disabled={busy || code.length !== 6}
                className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-acc-400 to-acc-500 py-3.5 text-sm font-bold text-ink-950 transition-transform hover:-translate-y-0.5 disabled:opacity-50 disabled:hover:translate-y-0"
              >
                {busy ? <Loader2 className="size-4 animate-spin" /> : <ShieldCheck className="size-4" />}
                Verify karo
              </button>

              <button
                type="button"
                onClick={resend}
                disabled={cooldown > 0 || busy}
                className="mt-3 w-full text-center text-[11px] font-semibold text-stone-500 hover:text-acc-300 disabled:opacity-40"
              >
                {cooldown > 0 ? `Code dobara bhejein (${cooldown}s)` : "Code nahi aaya? Dobara bhejein"}
              </button>
            </motion.form>
          )}
        </div>

        <p className="mt-5 text-center text-[11px] text-stone-700">{t("app.credit")}</p>
      </motion.div>
    </div>
  );
}

/** local copy to avoid importing server-only lib */
function passwordScoreLocal(pw: string): number {
  let s = 0;
  if (pw.length >= 8) s++;
  if (pw.length >= 12) s++;
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) s++;
  if (/\d/.test(pw)) s++;
  if (/[^A-Za-z0-9]/.test(pw)) s++;
  return Math.min(s, 4);
}
