import { NextRequest, NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { groups, members } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

/** Photos are stored as small data URLs — keep them bounded (~1.5 MB). */
const MAX_PHOTO = 1_500_000;

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  try {
    const body = await req.json();
    const groupId = Number(body.groupId);
    const name = String(body.name ?? "").trim();
    if (!Number.isFinite(groupId) || !name) {
      return NextResponse.json({ error: "Name is required" }, { status: 400 });
    }

    const owned = await db
      .select({ id: groups.id })
      .from(groups)
      .where(and(eq(groups.id, groupId), eq(groups.userId, user.id)))
      .limit(1);
    if (!owned.length) return NextResponse.json({ error: "Not found" }, { status: 404 });

    const photo = typeof body.photoUrl === "string" ? body.photoUrl : null;
    if (photo && photo.length > MAX_PHOTO) {
      return NextResponse.json({ error: "Photo too large" }, { status: 413 });
    }

    const [created] = await db
      .insert(members)
      .values({
        groupId,
        name: name.slice(0, 120),
        identifier: body.identifier ? String(body.identifier).trim().slice(0, 40) : null,
        role: body.role ? String(body.role).trim().slice(0, 120) : null,
        phone: body.phone ? String(body.phone).trim().slice(0, 24) : null,
        email: body.email ? String(body.email).trim().slice(0, 200) : null,
        photoUrl: photo,
        color: String(body.color ?? "amber").slice(0, 16),
        joinDate: body.joinDate ? String(body.joinDate) : null,
      })
      .returning();
    return NextResponse.json({ member: created }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Could not add person" }, { status: 500 });
  }
}
