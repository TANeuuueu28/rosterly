"use client";

import {
  createContext,
  useCallback,
  useContext,
  useState,
  type ReactNode,
} from "react";
import { langMeta, tr, type Lang } from "@/lib/i18n";

type Ctx = {
  lang: Lang;
  setLang: (l: Lang) => void;
  theme: string;
  setTheme: (t: string) => void;
};

const AppCtx = createContext<Ctx>({
  lang: "en",
  setLang: () => {},
  theme: "saffron",
  setTheme: () => {},
});

export function AppProvider({
  initialLang,
  initialTheme,
  children,
}: {
  initialLang: Lang;
  initialTheme: string;
  children: ReactNode;
}) {
  const [lang, setLangState] = useState<Lang>(initialLang);
  const [theme, setThemeState] = useState(initialTheme);

  const setLang = useCallback((l: Lang) => {
    setLangState(l);
    const meta = langMeta(l);
    document.documentElement.lang = l;
    document.documentElement.dir = meta.dir;
  }, []);

  const setTheme = useCallback((t: string) => {
    setThemeState(t);
    document.documentElement.dataset.theme = t;
  }, []);

  return (
    <AppCtx.Provider value={{ lang, setLang, theme, setTheme }}>{children}</AppCtx.Provider>
  );
}

export function useApp() {
  return useContext(AppCtx);
}

/** Translator hook: const t = useT(); t("nav.home") */
export function useT() {
  const { lang } = useApp();
  return useCallback((key: string) => tr(lang, key), [lang]);
}

/** Speak a phrase in the active language (used by the welcome screen). */
export function speak(text: string, lang: Lang) {
  try {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = langMeta(lang).voice;
    u.rate = 0.95;
    u.pitch = 1.03;
    u.volume = 1;
    const voices = window.speechSynthesis.getVoices();
    const match =
      voices.find((v) => v.lang === u.lang) ??
      voices.find((v) => v.lang.startsWith(u.lang.split("-")[0]));
    if (match) u.voice = match;
    window.speechSynthesis.speak(u);
  } catch {
    /* voice is a bonus — never break the UI */
  }
}
