import Link from "next/link";

export function Brand({
  size = "md",
  href = "/",
  tagline,
}: {
  size?: "sm" | "md" | "lg";
  href?: string | null;
  tagline?: string;
}) {
  const dims = {
    sm: { box: "size-9 rounded-xl", title: "text-lg", wrap: "gap-2.5" },
    md: { box: "size-11 rounded-2xl", title: "text-xl", wrap: "gap-3" },
    lg: { box: "size-16 rounded-[22px]", title: "text-3xl", wrap: "gap-4" },
  }[size];

  const inner = (
    <span className={`flex items-center ${dims.wrap}`}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src="/icons/icon-512.png"
        alt="Rosterly logo"
        className={`${dims.box} shadow-[0_8px_30px_-8px_var(--acc-glow)] transition-transform duration-500 group-hover:rotate-6`}
      />
      <span className="leading-tight">
        <span
          className={`font-display block ${dims.title} font-bold tracking-tight text-stone-50`}
        >
          Rosterly
        </span>
        {tagline ? (
          <span className="block text-[10px] font-semibold uppercase tracking-[0.22em] text-stone-500">
            {tagline}
          </span>
        ) : null}
      </span>
    </span>
  );

  if (!href) return <span className="group inline-flex">{inner}</span>;
  return (
    <Link href={href} className="group inline-flex">
      {inner}
    </Link>
  );
}
