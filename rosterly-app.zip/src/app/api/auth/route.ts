import { NextRequest, NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { trustedDevices, users } from "@/db/schema";
import {
  createSession,
  destroySession,
  getCurrentUser,
  hashPassword,
  verifyPassword,
} from "@/lib/auth";
import {
  TRUST_COOKIE,
  TRUST_DAYS,
  assertNotLocked,
  clearFailures,
  createAndSendOtp,
  normalizeEmail,
  normalizePhone,
  passwordScore,
  purgeExpiredOtps,
  registerFailure,
  verifyOtp,
} from "@/lib/security";

const LANGS = ["en","hi","bn","mr","ta","te","gu","kn","ur","ar","es","fr","pt","zh"];

function targetOf(body: Record<string, unknown>): { target: string; email: string | null; phone: string | null } {
  const email = body.email ? normalizeEmail(String(body.email)) : null;
  const phone = body.phone ? normalizePhone(String(body.phone)) : null;
  return { target: (email ?? phone ?? "") as string, email, phone };
}

async function findUser(email: string | null, phone: string | null) {
  if (email) {
    const rows = await db.select().from(users).where(eq(users.email, email)).limit(1);
    if (rows[0]) return rows[0];
  }
  if (phone) {
    const rows = await db.select().from(users).where(eq(users.phone, phone)).limit(1);
    if (rows[0]) return rows[0];
  }
  return null;
}

/** Returns the trust token if this browser was remembered for this user. */
async function trustedFor(req: NextRequest, userId: number): Promise<boolean> {
  const token = req.cookies.get(TRUST_COOKIE)?.value;
  if (!token || token.length !== 64) return false;
  const rows = await db
    .select({ id: trustedDevices.id })
    .from(trustedDevices)
    .where(
      and(
        eq(trustedDevices.token, token),
        eq(trustedDevices.userId, userId),
      ),
    )
    .limit(1);
  return rows.length > 0;
}

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ user: null });
  return NextResponse.json({
    user: { id: user.id, name: user.name, email: user.email, phone: user.phone },
  });
}

export async function POST(req: NextRequest) {
  void purgeExpiredOtps();
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const action = String(body.action ?? "");
    const { target, email, phone } = targetOf(body);
    const store = await import("next/headers").then((m) => m.cookies());

    if (!target) {
      return NextResponse.json({ error: "Email ya phone chahiye" }, { status: 400 });
    }
    if (email && !email.includes("@")) {
      return NextResponse.json({ error: "Valid email daalo" }, { status: 400 });
    }
    if (!email && (phone?.length ?? 0) < 6) {
      return NextResponse.json({ error: "Valid phone number daalo" }, { status: 400 });
    }

    /* ---------------- SIGNUP ---------------- */
    if (action === "signup") {
      const name = String(body.name ?? "").trim();
      const password = String(body.password ?? "");
      if (!name) return NextResponse.json({ error: "Naam likhna zaroori hai" }, { status: 400 });
      if (password.length < 8 || passwordScore(password) < 2) {
        return NextResponse.json(
          { error: "Password kamzor hai — 8+ characters, mix letters/numbers use karo" },
          { status: 400 },
        );
      }
      const existing = await findUser(email, phone);
      if (existing) {
        return NextResponse.json(
          { error: "Ye account pehle se hai — login karo ya password reset karo" },
          { status: 409 },
        );
      }
      const send = await createAndSendOtp(target, "signup", {
        name,
        email,
        phone,
        countryCode: body.countryCode ? String(body.countryCode) : null,
        passwordHash: await hashPassword(password),
        language: LANGS.includes(String(body.language)) ? String(body.language) : "en",
        theme: String(body.theme ?? "saffron"),
      });
      return NextResponse.json({ ok: true, step: "otp", target, devCode: send.devCode });
    }

    if (action === "signup-verify") {
      const code = String(body.code ?? "").trim();
      const result = await verifyOtp(target, "signup", code);
      if (!result.ok) {
        return NextResponse.json({ error: "Galat OTP — check karo (10 min mein expire hota hai)" }, { status: 400 });
      }
      const meta = result.meta as Record<string, string | null> | undefined;
      if (!meta?.passwordHash) {
        return NextResponse.json({ error: "Session expire ho gaya — dobara try karo" }, { status: 400 });
      }
      const [created] = await db
        .insert(users)
        .values({
          name: String(meta.name),
          email: meta.email || null,
          phone: meta.phone || null,
          countryCode: meta.countryCode || null,
          passwordHash: meta.passwordHash,
          provider: "email",
          language: meta.language ?? "en",
          theme: meta.theme ?? "saffron",
          emailVerified: Boolean(meta.email),
          phoneVerified: Boolean(meta.phone),
          lastLoginAt: new Date(),
        })
        .returning();
      await createSession(created.id, req.headers.get("user-agent"));
      return NextResponse.json({ ok: true, user: { id: created.id, name: created.name } });
    }

    /* ---------------- LOGIN ---------------- */
    if (action === "login") {
      const user = await findUser(email, phone);
      if (!user || user.provider === "google") {
        return NextResponse.json(
          { error: user ? "Is account ke liye Google se login karo" : "Account nahi mila — pehle sign up karo" },
          { status: 404 },
        );
      }
      await assertNotLocked(email, phone);
      const remembered = await trustedFor(req, user.id);
      if (remembered) {
        return NextResponse.json({ ok: true, step: "password", requireOtp: false });
      }
      const send = await createAndSendOtp(target, "login");
      return NextResponse.json({
        ok: true,
        step: "password-otp",
        requireOtp: true,
        devCode: send.devCode,
      });
    }

    if (action === "login-verify") {
      const user = await findUser(email, phone);
      if (!user) return NextResponse.json({ error: "Account nahi mila" }, { status: 404 });
      await assertNotLocked(email, phone);

      const password = String(body.password ?? "");
      const pwOk = user.passwordHash
        ? await verifyPassword(password, user.passwordHash)
        : false;
      if (!pwOk) {
        await registerFailure(user.id);
        return NextResponse.json({ error: "Galat password" }, { status: 401 });
      }

      const remembered = await trustedFor(req, user.id);
      if (!remembered) {
        const code = String(body.code ?? "").trim();
        const result = await verifyOtp(target, "login", code);
        if (!result.ok) {
          return NextResponse.json(
            { error: "Galat OTP — check karo (10 min mein expire hota hai)" },
            { status: 400 },
          );
        }
      }

      await clearFailures(user.id);
      await db
        .update(users)
        .set({ lastLoginAt: new Date() })
        .where(eq(users.id, user.id));
      await createSession(user.id, req.headers.get("user-agent"));

      if (body.remember === true && !remembered) {
        const token = crypto.randomUUID().replaceAll("-", "") + crypto.randomUUID().replaceAll("-", "");
        await db.insert(trustedDevices).values({
          userId: user.id,
          token,
          userAgent: req.headers.get("user-agent"),
          expiresAt: new Date(Date.now() + TRUST_DAYS * 864e5),
        });
        store.set(TRUST_COOKIE, token, {
          httpOnly: true,
          sameSite: "lax",
          secure: true,
          path: "/",
          maxAge: TRUST_DAYS * 86400,
        });
      }
      return NextResponse.json({ ok: true, user: { id: user.id, name: user.name } });
    }

    /* ---------------- PASSWORD RESET ---------------- */
    if (action === "reset-start") {
      const user = await findUser(email, phone);
      if (!user) {
        return NextResponse.json({ error: "Is se koi account nahi mila" }, { status: 404 });
      }
      const send = await createAndSendOtp(target, "reset");
      return NextResponse.json({ ok: true, step: "reset-verify", devCode: send.devCode });
    }

    if (action === "reset-verify") {
      const code = String(body.code ?? "").trim();
      const password = String(body.password ?? "");
      if (password.length < 8 || passwordScore(password) < 2) {
        return NextResponse.json({ error: "Naya password kamzor hai" }, { status: 400 });
      }
      const result = await verifyOtp(target, "reset", code);
      if (!result.ok) {
        return NextResponse.json({ error: "Galat OTP" }, { status: 400 });
      }
      const user = await findUser(email, phone);
      if (!user) return NextResponse.json({ error: "Account nahi mila" }, { status: 404 });
      await db
        .update(users)
        .set({
          passwordHash: await hashPassword(password),
          emailVerified: user.email ? true : user.emailVerified,
          phoneVerified: user.phone ? true : user.phoneVerified,
        })
        .where(eq(users.id, user.id));
      await clearFailures(user.id);
      await createSession(user.id, req.headers.get("user-agent"));
      return NextResponse.json({ ok: true });
    }

    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Kuch galat ho gaya";
    const status = msg.includes("lock") || msg.includes("limit") || msg.includes("ruko") ? 429 : 500;
    return NextResponse.json({ error: msg }, { status });
  }
}

export async function DELETE() {
  await destroySession();
  return NextResponse.json({ ok: true });
}
