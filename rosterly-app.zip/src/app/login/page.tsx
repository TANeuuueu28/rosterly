import { redirect } from "next/navigation";
import { getViewer } from "@/lib/session-user";
import { googleConfigured } from "@/lib/auth";
import { AuthForm } from "@/components/auth-form";

export const dynamic = "force-dynamic";

export default async function LoginPage() {
  const viewer = await getViewer();
  if (viewer) redirect("/");
  return <AuthForm googleEnabled={googleConfigured()} />;
}
