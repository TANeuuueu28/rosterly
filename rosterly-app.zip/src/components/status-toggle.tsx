"use client";

import { CalendarOff, Check, Clock3, X } from "lucide-react";
import { cn, STATUS_META } from "@/lib/ui";
import type { AttendanceStatus } from "@/db/schema";

const ICONS: Record<AttendanceStatus, typeof Check> = {
  present: Check,
  absent: X,
  leave: CalendarOff,
  half_day: Clock3,
};

export function StatusToggle({
  value,
  onChange,
  clearable = true,
  compact = false,
}: {
  value: AttendanceStatus | null;
  onChange: (s: AttendanceStatus | null) => void;
  clearable?: boolean;
  compact?: boolean;
}) {
  const order: AttendanceStatus[] = ["present", "absent", "leave", "half_day"];
  return (
    <div className="flex items-center gap-1">
      {order.map((s) => {
        const Icon = ICONS[s];
        const meta = STATUS_META[s];
        const active = value === s;
        return (
          <button
            key={s}
            type="button"
            title={meta.label}
            aria-label={meta.label}
            onClick={() => onChange(active && clearable ? null : s)}
            className={cn(
              "grid place-items-center rounded-xl border transition-all duration-200",
              compact ? "size-8" : "size-9",
              active
                ? cn(meta.soft, meta.border, meta.text, "scale-105 shadow-sm")
                : "border-white/[0.06] bg-white/[0.02] text-stone-600 hover:border-white/[0.12] hover:text-stone-300",
            )}
          >
            <Icon className={compact ? "size-3.5" : "size-4"} strokeWidth={2.4} />
          </button>
        );
      })}
    </div>
  );
}
