import type { AttendanceStatus } from "@/db/schema";

export function cn(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(" ");
}

export const DEPARTMENTS = [
  "Engineering",
  "Design",
  "Marketing",
  "Sales",
  "HR",
  "Operations",
  "Finance",
] as const;

export const AVATAR_COLORS: Record<
  string,
  { bg: string; text: string; ring: string }
> = {
  amber: { bg: "bg-amber-400/15", text: "text-amber-300", ring: "ring-amber-400/30" },
  emerald: { bg: "bg-emerald-400/15", text: "text-emerald-300", ring: "ring-emerald-400/30" },
  rose: { bg: "bg-rose-400/15", text: "text-rose-300", ring: "ring-rose-400/30" },
  sky: { bg: "bg-sky-400/15", text: "text-sky-300", ring: "ring-sky-400/30" },
  violet: { bg: "bg-violet-400/15", text: "text-violet-300", ring: "ring-violet-400/30" },
  teal: { bg: "bg-teal-400/15", text: "text-teal-300", ring: "ring-teal-400/30" },
  orange: { bg: "bg-orange-400/15", text: "text-orange-300", ring: "ring-orange-400/30" },
  fuchsia: { bg: "bg-fuchsia-400/15", text: "text-fuchsia-300", ring: "ring-fuchsia-400/30" },
};

export const AVATAR_COLOR_KEYS = Object.keys(AVATAR_COLORS);

export type StatusMeta = {
  label: string;
  labelHi: string;
  short: string;
  dot: string;
  text: string;
  soft: string;
  solidBg: string;
  border: string;
  hex: string;
};

export const STATUS_META: Record<AttendanceStatus, StatusMeta> = {
  present: {
    label: "Present",
    labelHi: "Hazir",
    short: "P",
    dot: "bg-emerald-400",
    text: "text-emerald-300",
    soft: "bg-emerald-400/10",
    solidBg: "bg-emerald-400",
    border: "border-emerald-400/30",
    hex: "#34d399",
  },
  absent: {
    label: "Absent",
    labelHi: "Gairhazir",
    short: "A",
    dot: "bg-rose-400",
    text: "text-rose-300",
    soft: "bg-rose-400/10",
    solidBg: "bg-rose-400",
    border: "border-rose-400/30",
    hex: "#fb7185",
  },
  leave: {
    label: "Leave",
    labelHi: "Chhutti",
    short: "L",
    dot: "bg-violet-400",
    text: "text-violet-300",
    soft: "bg-violet-400/10",
    solidBg: "bg-violet-400",
    border: "border-violet-400/30",
    hex: "#a78bfa",
  },
  half_day: {
    label: "Half Day",
    labelHi: "Aadha din",
    short: "H",
    dot: "bg-sky-400",
    text: "text-sky-300",
    soft: "bg-sky-400/10",
    solidBg: "bg-sky-400",
    border: "border-sky-400/30",
    hex: "#38bdf8",
  },
};

export const STATUS_ORDER: AttendanceStatus[] = ["present", "absent", "leave", "half_day"];

export const CLASS_SUGGESTIONS = [
  "Nursery",
  "LKG",
  "UKG",
  "1-A",
  "2-A",
  "3-A",
  "4-A",
  "5-A",
  "6-A",
  "6-B",
  "7-A",
  "7-B",
  "8-A",
  "8-B",
  "9-A",
  "9-B",
  "10-A",
  "10-B",
  "11-Sci",
  "11-Com",
  "12-Sci",
  "12-Com",
];

export type BoardKind = "staff" | "students";

export const KIND_META: Record<
  BoardKind,
  { singular: string; plural: string; hiPlural: string; api: string; idKey: "employeeId" | "studentId" }
> = {
  staff: {
    singular: "Employee",
    plural: "Team",
    hiPlural: "टीम",
    api: "/api/attendance",
    idKey: "employeeId",
  },
  students: {
    singular: "Student",
    plural: "Students",
    hiPlural: "विद्यार्थी",
    api: "/api/student-attendance",
    idKey: "studentId",
  },
};

export function initials(name: string): string {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join("");
}

/** Weighted attendance score: present = 1, half day = 0.5, rest = 0 */
export function scoreOf(status: AttendanceStatus): number {
  if (status === "present") return 1;
  if (status === "half_day") return 0.5;
  return 0;
}

export function pct(part: number, whole: number): number {
  if (whole <= 0) return 0;
  return Math.round((part / whole) * 100);
}
