import { NextRequest, NextResponse } from "next/server";
import { and, desc, eq, gt, ne } from "drizzle-orm";
import { cookies } from "next/headers";
import { db } from "@/db";
import { sessions, trustedDevices, users } from "@/db/schema";
import { getCurrentUser, hashPassword, SESSION_COOKIE, verifyPassword } from "@/lib/auth";
import {
  channelsConfigured,
  createAndSendOtp,
  normalizeEmail,
  normalizePhone,
  passwordScore,
  verifyOtp,
} from "@/lib/security";

export const dynamic = "force-dynamic";

function primaryTarget(user: { email: string | null; phone: string | null }) {
  const t = user.email ?? user.phone;
  if (!t) throw new Error("Account pehle email ya phone add karo (login screen → forgot password)");
  return t;
}

export async function GET(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const current = (await cookies()).get(SESSION_COOKIE)?.value;

  const [allSessions, devices] = await Promise.all([
    db
      .select()
      .from(sessions)
      .where(and(eq(sessions.userId, user.id), gt(sessions.expiresAt, new Date())))
      .orderBy(desc(sessions.createdAt)),
    db
      .select()
      .from(trustedDevices)
      .where(and(eq(trustedDevices.userId, user.id), gt(trustedDevices.expiresAt, new Date())))
      .orderBy(desc(trustedDevices.createdAt)),
  ]);

  void req;
  return NextResponse.json({
    stats: {
      email: user.email,
      phone: user.phone,
      emailVerified: user.emailVerified,
      phoneVerified: user.phoneVerified,
      lastLoginAt: user.lastLoginAt,
      channels: channelsConfigured(),
    },
    sessions: allSessions.map((s) => ({
      token: s.token.slice(0, 8),
      current: s.token === current,
      userAgent: s.userAgent,
      createdAt: s.createdAt,
    })),
    devices: devices.map((d) => ({
      id: d.id,
      userAgent: d.userAgent,
      createdAt: d.createdAt,
      expiresAt: d.expiresAt,
    })),
  });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const action = String(body.action ?? "");

    /* password change: current password → OTP → new password (one call after OTP sent) */
    if (action === "password-send") {
      const target = primaryTarget(user);
      const send = await createAndSendOtp(target, "change-password", {
        verifyPassword: String(body.currentPassword ?? ""),
        hash: user.passwordHash,
      });
      return NextResponse.json({ ok: true, sentTo: target, devCode: send.devCode });
    }
    if (action === "password-change") {
      const target = primaryTarget(user);
      const code = String(body.code ?? "").trim();
      const next = String(body.newPassword ?? "");
      if (next.length < 8 || passwordScore(next) < 2) {
        return NextResponse.json({ error: "Naya password kamzor hai" }, { status: 400 });
      }
      const result = await verifyOtp(target, "change-password", code);
      if (!result.ok) return NextResponse.json({ error: "Galat OTP" }, { status: 400 });
      const meta = result.meta as { verifyPassword?: string; hash?: string } | undefined;
      const given = String(body.currentPassword ?? meta?.verifyPassword ?? "");
      const stored = user.passwordHash ?? meta?.hash ?? "";
      if (!stored || !(await verifyPassword(given, stored))) {
        return NextResponse.json({ error: "Current password galat hai" }, { status: 401 });
      }
      await db
        .update(users)
        .set({ passwordHash: await hashPassword(next) })
        .where(eq(users.id, user.id));
      return NextResponse.json({ ok: true });
    }

    /* email change: prove control of the NEW address with OTP */
    if (action === "email-send") {
      const newEmail = normalizeEmail(String(body.email ?? ""));
      if (!newEmail.includes("@")) return NextResponse.json({ error: "Valid email daalo" }, { status: 400 });
      const taken = await db.select({ id: users.id }).from(users).where(eq(users.email, newEmail)).limit(1);
      if (taken.length) return NextResponse.json({ error: "Ye email kisi aur account mein hai" }, { status: 409 });
      const send = await createAndSendOtp(newEmail, "change-email", { newEmail, userId: user.id });
      return NextResponse.json({ ok: true, sentTo: newEmail, devCode: send.devCode });
    }
    if (action === "email-confirm") {
      const newEmail = normalizeEmail(String(body.email ?? ""));
      const result = await verifyOtp(newEmail, "change-email", String(body.code ?? "").trim());
      if (!result.ok) return NextResponse.json({ error: "Galat OTP" }, { status: 400 });
      await db
        .update(users)
        .set({ email: newEmail, emailVerified: true })
        .where(eq(users.id, user.id));
      return NextResponse.json({ ok: true });
    }

    /* phone change */
    if (action === "phone-send") {
      const newPhone = normalizePhone(String(body.phone ?? ""));
      if (newPhone.length < 6) return NextResponse.json({ error: "Valid phone daalo" }, { status: 400 });
      const taken = await db.select({ id: users.id }).from(users).where(eq(users.phone, newPhone)).limit(1);
      if (taken.length) return NextResponse.json({ error: "Ye number kisi aur account mein hai" }, { status: 409 });
      const send = await createAndSendOtp(newPhone, "change-phone", { newPhone, userId: user.id });
      return NextResponse.json({ ok: true, sentTo: newPhone, devCode: send.devCode });
    }
    if (action === "phone-confirm") {
      const newPhone = normalizePhone(String(body.phone ?? ""));
      const result = await verifyOtp(newPhone, "change-phone", String(body.code ?? "").trim());
      if (!result.ok) return NextResponse.json({ error: "Galat OTP" }, { status: 400 });
      await db
        .update(users)
        .set({ phone: newPhone, phoneVerified: true })
        .where(eq(users.id, user.id));
      return NextResponse.json({ ok: true });
    }

    if (action === "revoke-device") {
      await db
        .delete(trustedDevices)
        .where(and(eq(trustedDevices.id, Number(body.id)), eq(trustedDevices.userId, user.id)));
      return NextResponse.json({ ok: true });
    }
    if (action === "revoke-all-devices") {
      await db.delete(trustedDevices).where(eq(trustedDevices.userId, user.id));
      const store = await cookies();
      store.delete("haziri_trust");
      return NextResponse.json({ ok: true });
    }
    if (action === "logout-others") {
      const current = (await cookies()).get(SESSION_COOKIE)?.value;
      if (current) {
        await db
          .delete(sessions)
          .where(and(eq(sessions.userId, user.id), ne(sessions.token, current)));
      }
      return NextResponse.json({ ok: true });
    }

    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Kuch galat ho gaya" },
      { status: 400 },
    );
  }
}
