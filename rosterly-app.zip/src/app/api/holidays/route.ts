import { NextRequest, NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { holidays } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  try {
    const body = await req.json();
    const date = String(body.date ?? "");
    const name = String(body.name ?? "").trim().slice(0, 120);
    if (!DATE_RE.test(date) || !name) {
      return NextResponse.json({ error: "Date aur naam chahiye" }, { status: 400 });
    }
    await db
      .insert(holidays)
      .values({ userId: user.id, date, name })
      .onConflictDoUpdate({
        target: [holidays.userId, holidays.date],
        set: { name: holidays.name },
      });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Could not save holiday" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const date = new URL(req.url).searchParams.get("date") ?? "";
  if (!DATE_RE.test(date)) return NextResponse.json({ error: "Bad date" }, { status: 400 });
  await db.delete(holidays).where(and(eq(holidays.userId, user.id), eq(holidays.date, date)));
  return NextResponse.json({ ok: true });
}
