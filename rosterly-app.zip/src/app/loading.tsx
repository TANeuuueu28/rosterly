export default function Loading() {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src="/icons/icon-192.png"
        alt=""
        className="size-14 animate-pulse-soft rounded-2xl"
      />
      <p className="text-xs font-semibold uppercase tracking-[0.3em] text-stone-600">Rosterly</p>
    </div>
  );
}
