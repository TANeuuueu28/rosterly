"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowRight,
  CalendarDays,
  Check,
  LayoutGrid,
  Loader2,
  PartyPopper,
  Plus,
  Sparkles,
  Trash2,
  X,
} from "lucide-react";
import { friendlyDate, todayStr } from "@/lib/dates";
import { useApp, useT } from "@/components/providers";
import { greetKey, tr } from "@/lib/i18n";
import { cn } from "@/lib/ui";

export type GroupCard = {
  id: number;
  name: string;
  kind: string;
  orgName: string | null;
  icon: string;
  color: string;
  memberLabel: string;
  total: number;
  markedToday: number;
};

const KINDS = [
  { id: "office", icon: "🏢", member: "Employee", role: "Designation", time: true },
  { id: "school", icon: "🎒", member: "Student", role: "Class", time: false },
  { id: "college", icon: "🎓", member: "Student", role: "Course", time: false },
  { id: "gym", icon: "🏋️", member: "Member", role: "Plan", time: true },
  { id: "factory", icon: "🏭", member: "Worker", role: "Shift", time: true },
  { id: "shop", icon: "🏪", member: "Staff", role: "Role", time: true },
  { id: "event", icon: "🎪", member: "Guest", role: "Pass", time: true },
  { id: "other", icon: "📋", member: "Member", role: "Role", time: true },
];

const SWATCHES = ["amber", "emerald", "sky", "violet", "rose", "teal", "orange", "fuchsia"];

const DOT: Record<string, string> = {
  amber: "bg-amber-400", emerald: "bg-emerald-400", sky: "bg-sky-400", violet: "bg-violet-400",
  rose: "bg-rose-400", teal: "bg-teal-400", orange: "bg-orange-400", fuchsia: "bg-fuchsia-400",
};

export function GroupsDashboard({
  viewerName,
  groups,
  todayStats,
  upcomingHolidays,
}: {
  viewerName: string;
  groups: GroupCard[];
  todayStats: { members: number; marked: number; present: number; absent: number; leave: number; half_day: number };
  upcomingHolidays: { date: string; name: string }[];
}) {
  const router = useRouter();
  const t = useT();
  const { lang } = useApp();

  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmId, setConfirmId] = useState<number | null>(null);

  const [kind, setKind] = useState(KINDS[0]);
  const [name, setName] = useState("");
  const [orgName, setOrgName] = useState("");
  const [memberLabel, setMemberLabel] = useState(KINDS[0].member);
  const [roleLabel, setRoleLabel] = useState(KINDS[0].role);
  const [trackTime, setTrackTime] = useState(true);
  const [color, setColor] = useState("amber");

  function pickKind(k: (typeof KINDS)[number]) {
    setKind(k);
    setMemberLabel(k.member);
    setRoleLabel(k.role);
    setTrackTime(k.time);
  }

  async function create(e: FormEvent) {
    e.preventDefault();
    if (!name.trim()) return setError(t("c.required"));
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/groups", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          kind: kind.id,
          orgName,
          memberLabel,
          roleLabel,
          trackTime,
          color,
          icon: kind.icon,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error ?? "Error");
      setOpen(false);
      setName("");
      setOrgName("");
      router.push(`/t/${data.group.id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Error");
    } finally {
      setBusy(false);
    }
  }

  async function removeGroup(id: number) {
    setBusy(true);
    try {
      await fetch(`/api/groups/${id}`, { method: "DELETE" });
      setConfirmId(null);
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  const field =
    "w-full rounded-xl border border-white/[0.08] bg-white/[0.03] px-3.5 py-2.5 text-sm text-stone-100 outline-none transition-colors placeholder:text-stone-600 focus:border-acc-400/50";
  const label = "mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.18em] text-stone-500";

  return (
    <div className="space-y-7">
      <header className="animate-fade-up flex flex-wrap items-end justify-between gap-5">
        <div>
          <p className="inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.25em] text-acc-300/90">
            <Sparkles className="size-3.5" />
            {tr(lang, greetKey(new Date().getHours()))}, {viewerName}
          </p>
          <h1 className="font-display mt-3 text-4xl font-bold tracking-tight text-stone-50 sm:text-5xl">
            {t("home.title")}
          </h1>
          <p className="mt-2 max-w-md text-sm text-stone-500">{t("home.sub")}</p>
        </div>
        <div className="flex items-center gap-3">
          <Link
            href="/calendar"
            className="inline-flex items-center gap-2 rounded-2xl border border-white/[0.08] bg-white/[0.03] px-5 py-3 text-sm font-semibold text-stone-300 transition-all hover:border-white/[0.15] hover:text-stone-100"
          >
            <CalendarDays className="size-4" /> {t("nav.calendar")}
          </Link>
          <button
            onClick={() => setOpen(true)}
            className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-br from-acc-400 to-acc-500 px-5 py-3 text-sm font-bold text-ink-950 shadow-[0_14px_36px_-12px_var(--acc-glow)] transition-transform hover:-translate-y-0.5"
          >
            <Plus className="size-4" strokeWidth={2.8} />
            {t("home.new")}
          </button>
        </div>
      </header>

      {/* today across all tables */}
      {todayStats.members > 0 && (
        <section className="grid grid-cols-2 gap-3 sm:grid-cols-5">
          {(
            [
              { k: "present", label: "Present", dot: "bg-emerald-400" },
              { k: "absent", label: "Absent", dot: "bg-rose-400" },
              { k: "leave", label: "Leave", dot: "bg-violet-400" },
              { k: "half_day", label: "Half Day", dot: "bg-sky-400" },
            ] as const
          ).map((s) => (
            <div
              key={s.k}
              className="rounded-2xl border border-white/[0.05] bg-white/[0.02] px-4 py-3"
            >
              <p className="flex items-center gap-1.5 text-[11px] font-semibold text-stone-400">
                <span className={cn("size-1.5 rounded-full", s.dot)} /> {s.label}
              </p>
              <p className="font-display mt-1 text-2xl font-bold text-stone-100 tabular-nums">
                {todayStats[s.k]}
              </p>
            </div>
          ))}
          <div className="rounded-2xl border border-acc-400/20 bg-gradient-to-br from-acc-400/10 to-transparent px-4 py-3">
            <p className="text-[11px] font-semibold text-acc-300">Marked today</p>
            <p className="font-display mt-1 text-2xl font-bold text-stone-50 tabular-nums">
              {todayStats.marked}
              <span className="text-sm text-stone-500">/{todayStats.members}</span>
            </p>
          </div>
        </section>
      )}

      {/* upcoming holidays */}
      {upcomingHolidays.length > 0 && (
        <section className="flex flex-wrap items-center gap-2 rounded-2xl border border-white/[0.05] bg-white/[0.02] px-4 py-3">
          <span className="inline-flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[0.2em] text-stone-500">
            <PartyPopper className="size-3.5 text-acc-300" /> Aane wali chhuttiyan
          </span>
          {upcomingHolidays.map((h) => {
            const daysAway = Math.round(
              (new Date(h.date).getTime() - new Date(todayStr()).getTime()) / 864e5,
            );
            return (
              <span
                key={h.date}
                title={friendlyDate(h.date)}
                className="inline-flex items-center gap-1.5 rounded-full bg-acc-400/10 px-3 py-1.5 text-[11px] font-semibold text-acc-200"
              >
                {h.name}
                <b className="text-[10px] text-acc-300/70">
                  {daysAway === 0 ? "today" : daysAway === 1 ? "tomorrow" : `${daysAway}d`}
                </b>
              </span>
            );
          })}
        </section>
      )}

      {groups.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-white/[0.09] bg-white/[0.02] px-6 py-20 text-center">
          <div className="mx-auto grid size-16 place-items-center rounded-full border border-white/[0.08] bg-white/[0.02]">
            <LayoutGrid className="size-7 text-stone-500" strokeWidth={1.6} />
          </div>
          <p className="font-display mt-4 text-lg font-semibold text-stone-200">
            {t("home.empty")}
          </p>
          <p className="mx-auto mt-1.5 max-w-sm text-sm text-stone-500">{t("home.emptyHint")}</p>
          <button
            onClick={() => setOpen(true)}
            className="mt-5 inline-flex items-center gap-2 rounded-xl bg-gradient-to-br from-acc-400 to-acc-500 px-5 py-2.5 text-xs font-bold text-ink-950"
          >
            <Plus className="size-4" strokeWidth={2.8} /> {t("home.new")}
          </button>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {groups.map((g, i) => (
            <motion.div
              key={g.id}
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: Math.min(i * 0.05, 0.4) }}
              className="group relative overflow-hidden rounded-3xl border border-white/[0.06] bg-white/[0.02] p-5 transition-all duration-500 hover:-translate-y-1 hover:border-white/[0.13] hover:bg-white/[0.04]"
            >
              <div className="flex items-start justify-between">
                <span className="grid size-12 place-items-center rounded-2xl bg-white/[0.04] text-2xl">
                  {g.icon}
                </span>
                <button
                  onClick={() => setConfirmId(confirmId === g.id ? null : g.id)}
                  aria-label={t("c.delete")}
                  className="grid size-8 place-items-center rounded-xl text-stone-600 opacity-0 transition-all hover:text-rose-300 group-hover:opacity-100"
                >
                  <Trash2 className="size-3.5" />
                </button>
              </div>

              <Link href={`/t/${g.id}`} className="mt-4 block">
                <p className="font-display truncate text-lg font-semibold text-stone-100">
                  {g.name}
                </p>
                <p className="mt-0.5 truncate text-xs text-stone-500">
                  {g.orgName || t(`kind.${g.kind}`)}
                </p>

                <div className="mt-4 flex items-center justify-between rounded-2xl bg-white/[0.03] px-4 py-3">
                  <span className="inline-flex items-center gap-2 text-[11px] text-stone-400">
                    <span className={cn("size-1.5 rounded-full", DOT[g.color] ?? DOT.amber)} />
                    <b className="font-semibold text-stone-200 tabular-nums">{g.total}</b>{" "}
                    {t("home.members")}
                  </span>
                  <span className="text-[11px] text-stone-500 tabular-nums">
                    {g.markedToday}/{g.total} {t("home.todayMarked")}
                  </span>
                </div>

                <span className="mt-4 inline-flex items-center gap-1.5 text-xs font-bold text-acc-300">
                  {t("home.open")}
                  <ArrowRight className="size-3.5 transition-transform group-hover:translate-x-1 rtl:rotate-180" />
                </span>
              </Link>

              <AnimatePresence>
                {confirmId === g.id && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-3 bg-ink-900/95 p-5 text-center backdrop-blur"
                  >
                    <p className="text-sm font-semibold text-stone-100">{g.name}</p>
                    <p className="text-xs text-stone-500">{t("set.deleteHint")}</p>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setConfirmId(null)}
                        className="rounded-xl border border-white/[0.08] px-3.5 py-2 text-xs font-semibold text-stone-300"
                      >
                        {t("c.cancel")}
                      </button>
                      <button
                        onClick={() => removeGroup(g.id)}
                        disabled={busy}
                        className="inline-flex items-center gap-1.5 rounded-xl bg-rose-500 px-3.5 py-2 text-xs font-bold text-white disabled:opacity-50"
                      >
                        {busy && <Loader2 className="size-3 animate-spin" />}
                        {t("c.delete")}
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      )}

      {/* Create modal */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setOpen(false)}
            className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/70 p-4 py-10 backdrop-blur-sm"
          >
            <motion.form
              initial={{ opacity: 0, scale: 0.95, y: 18 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 18 }}
              onClick={(e) => e.stopPropagation()}
              onSubmit={create}
              className="w-full max-w-lg rounded-3xl border border-white/10 bg-ink-900 p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg font-bold text-stone-50">
                  {t("create.title")}
                </h2>
                <button
                  type="button"
                  onClick={() => setOpen(false)}
                  aria-label={t("c.cancel")}
                  className="grid size-8 place-items-center rounded-xl text-stone-500 hover:text-stone-200"
                >
                  <X className="size-4" />
                </button>
              </div>

              <div className="mt-5 space-y-4">
                <div>
                  <label className={label}>{t("create.type")}</label>
                  <div className="grid grid-cols-4 gap-2">
                    {KINDS.map((k) => (
                      <button
                        key={k.id}
                        type="button"
                        onClick={() => pickKind(k)}
                        className={cn(
                          "flex flex-col items-center gap-1 rounded-2xl border px-2 py-2.5 transition-all",
                          kind.id === k.id
                            ? "border-acc-400/50 bg-acc-400/10"
                            : "border-white/[0.07] hover:border-white/[0.16]",
                        )}
                      >
                        <span className="text-xl">{k.icon}</span>
                        <span className="truncate text-[10px] font-semibold text-stone-400">
                          {t(`kind.${k.id}`)}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className={label}>{t("create.name")}</label>
                  <input
                    autoFocus
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={t("create.namePh")}
                    className={field}
                  />
                </div>

                <div>
                  <label className={label}>{t("create.org")}</label>
                  <input
                    value={orgName}
                    onChange={(e) => setOrgName(e.target.value)}
                    className={field}
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className={label}>{t("create.memberLabel")}</label>
                    <input
                      value={memberLabel}
                      onChange={(e) => setMemberLabel(e.target.value)}
                      className={field}
                    />
                  </div>
                  <div>
                    <label className={label}>{t("create.roleLabel")}</label>
                    <input
                      value={roleLabel}
                      onChange={(e) => setRoleLabel(e.target.value)}
                      className={field}
                    />
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex gap-2">
                    {SWATCHES.map((c) => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => setColor(c)}
                        aria-label={c}
                        className={cn(
                          "size-7 rounded-full transition-all",
                          DOT[c],
                          color === c ? "scale-110 ring-2 ring-white/70" : "opacity-60 hover:opacity-100",
                        )}
                      />
                    ))}
                  </div>
                  <button
                    type="button"
                    onClick={() => setTrackTime((v) => !v)}
                    className={cn(
                      "inline-flex items-center gap-2 rounded-xl border px-3.5 py-2 text-[11px] font-semibold transition-all",
                      trackTime
                        ? "border-acc-400/40 bg-acc-400/10 text-acc-300"
                        : "border-white/[0.08] text-stone-500",
                    )}
                  >
                    {trackTime && <Check className="size-3.5" strokeWidth={3} />}
                    {t("create.trackTime")}
                  </button>
                </div>
              </div>

              {error && (
                <p className="mt-4 rounded-xl bg-rose-400/10 px-3.5 py-2.5 text-xs font-semibold text-rose-300">
                  {error}
                </p>
              )}

              <button
                type="submit"
                disabled={busy}
                className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-acc-400 to-acc-500 py-3 text-sm font-bold text-ink-950 transition-transform hover:-translate-y-0.5 disabled:opacity-50"
              >
                {busy && <Loader2 className="size-4 animate-spin" />}
                {t("create.submit")}
              </button>
            </motion.form>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
