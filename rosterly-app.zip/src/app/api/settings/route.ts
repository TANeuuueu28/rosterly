import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { LANGS, THEMES } from "@/lib/i18n";

export async function PATCH(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  try {
    const body = await req.json();
    const patch: Partial<typeof users.$inferInsert> = {};

    if (body.name !== undefined) {
      const name = String(body.name).trim().slice(0, 120);
      if (!name) return NextResponse.json({ error: "Name is required" }, { status: 400 });
      patch.name = name;
    }
    if (body.language !== undefined) {
      if (!LANGS.some((l) => l.id === body.language)) {
        return NextResponse.json({ error: "Invalid language" }, { status: 400 });
      }
      patch.language = String(body.language);
    }
    if (body.theme !== undefined) {
      if (!THEMES.some((t) => t.id === body.theme)) {
        return NextResponse.json({ error: "Invalid theme" }, { status: 400 });
      }
      patch.theme = String(body.theme);
    }
    if (body.photoUrl !== undefined) {
      const photo = typeof body.photoUrl === "string" ? body.photoUrl : null;
      if (photo && photo.length > 1_500_000) {
        return NextResponse.json({ error: "Photo too large" }, { status: 413 });
      }
      patch.photoUrl = photo;
    }

    if (Object.keys(patch).length === 0) {
      return NextResponse.json({ error: "Nothing to update" }, { status: 400 });
    }

    const [updated] = await db
      .update(users)
      .set(patch)
      .where(eq(users.id, user.id))
      .returning();

    return NextResponse.json({
      settings: {
        name: updated.name,
        language: updated.language,
        theme: updated.theme,
        photoUrl: updated.photoUrl,
      },
    });
  } catch {
    return NextResponse.json({ error: "Could not save settings" }, { status: 500 });
  }
}
