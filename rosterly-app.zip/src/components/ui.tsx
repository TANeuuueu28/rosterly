import type { ReactNode } from "react";
import type { LucideIcon } from "lucide-react";
import { cn, STATUS_META } from "@/lib/ui";
import type { AttendanceStatus } from "@/db/schema";

export function Card({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "rounded-3xl border border-white/[0.06] bg-white/[0.02] shadow-[0_20px_60px_-30px_rgba(0,0,0,0.8)] backdrop-blur-sm",
        className,
      )}
    >
      {children}
    </div>
  );
}

export function SectionHeading({
  title,
  hint,
  className,
}: {
  title: string;
  hint?: string;
  className?: string;
}) {
  return (
    <div className={cn("flex items-baseline justify-between gap-4", className)}>
      <h2 className="font-display text-lg font-semibold tracking-tight text-stone-100">
        {title}
      </h2>
      {hint ? <p className="text-xs text-stone-500">{hint}</p> : null}
    </div>
  );
}

export function StatusPill({
  status,
  className,
}: {
  status: AttendanceStatus;
  className?: string;
}) {
  const meta = STATUS_META[status];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-semibold",
        meta.soft,
        meta.border,
        meta.text,
        className,
      )}
    >
      <span className={cn("size-1.5 rounded-full", meta.dot)} />
      {meta.label}
    </span>
  );
}

export function EmptyState({
  icon: Icon,
  title,
  hint,
  action,
}: {
  icon: LucideIcon;
  title: string;
  hint: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 px-6 py-16 text-center">
      <div className="grid size-16 place-items-center rounded-full border border-dashed border-stone-700 bg-white/[0.02]">
        <Icon className="size-7 text-stone-500" strokeWidth={1.6} />
      </div>
      <p className="font-display text-base font-semibold text-stone-300">{title}</p>
      <p className="max-w-xs text-sm text-stone-500">{hint}</p>
      {action}
    </div>
  );
}

export function GhostButton({
  children,
  onClick,
  className,
  disabled,
}: {
  children: ReactNode;
  onClick?: () => void;
  className?: string;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "inline-flex items-center gap-2 rounded-xl border border-white/[0.08] bg-white/[0.03] px-3.5 py-2 text-xs font-semibold text-stone-300 transition-all duration-300 hover:border-white/[0.14] hover:bg-white/[0.06] hover:text-stone-100 disabled:cursor-not-allowed disabled:opacity-40",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function PrimaryButton({
  children,
  onClick,
  className,
  disabled,
}: {
  children: ReactNode;
  onClick?: () => void;
  className?: string;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "inline-flex items-center gap-2 rounded-xl bg-gradient-to-br from-acc-400 to-acc-500 px-4 py-2 text-xs font-bold text-ink-950 shadow-[0_10px_30px_-10px_var(--acc-glow)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_16px_36px_-10px_var(--acc-glow)] active:translate-y-0 disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:translate-y-0",
        className,
      )}
    >
      {children}
    </button>
  );
}
