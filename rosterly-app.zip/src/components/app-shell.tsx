"use client";

import type { ReactNode } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { CalendarDays, Download, Home, LogOut, Settings } from "lucide-react";
import { Brand } from "@/components/brand";
import { useT } from "@/components/providers";
import { cn } from "@/lib/ui";

export function AppShell({
  signedIn,
  userName,
  userPhoto,
  children,
}: {
  signedIn: boolean;
  userName: string | null;
  userPhoto: string | null;
  children: ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const t = useT();

  // Login screen gets a clean, full-bleed canvas
  if (!signedIn || pathname === "/login") {
    return <main className="relative min-h-screen">{children}</main>;
  }

  const nav = [
    { href: "/", label: t("nav.home"), icon: Home },
    { href: "/calendar", label: t("nav.calendar"), icon: CalendarDays },
    { href: "/settings", label: t("nav.settings"), icon: Settings },
    { href: "/install", label: t("nav.install"), icon: Download },
  ];

  async function logout() {
    await fetch("/api/auth", { method: "DELETE" });
    router.push("/login");
    router.refresh();
  }

  return (
    <>
      <aside className="fixed inset-y-0 start-0 z-30 hidden w-[256px] flex-col border-e border-white/[0.05] bg-ink-900/60 px-5 py-8 backdrop-blur-xl lg:flex">
        <div className="px-1">
          <Brand tagline={t("app.tagline")} />
        </div>

        <nav className="mt-10 flex flex-1 flex-col gap-1.5">
          {nav.map((item) => {
            const active =
              item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "group relative flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-medium transition-all duration-300",
                  active
                    ? "bg-white/[0.06] text-acc-300"
                    : "text-stone-400 hover:bg-white/[0.03] hover:text-stone-200",
                )}
              >
                <span
                  className={cn(
                    "absolute start-0 top-1/2 h-6 w-1 -translate-y-1/2 rounded-full bg-gradient-to-b from-acc-400 to-acc-500 transition-all",
                    active ? "scale-100 opacity-100" : "scale-50 opacity-0",
                  )}
                />
                <item.icon
                  className={cn("size-[18px]", active ? "text-acc-400" : "text-stone-500")}
                  strokeWidth={2.2}
                />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="rounded-3xl border border-white/[0.06] bg-white/[0.02] p-4">
          <div className="flex items-center gap-3">
            {userPhoto ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={userPhoto} alt="" className="size-10 rounded-xl object-cover" />
            ) : (
              <div className="grid size-10 place-items-center rounded-xl bg-acc-400/15 font-display text-sm font-bold text-acc-300">
                {(userName ?? "?").slice(0, 1).toUpperCase()}
              </div>
            )}
            <p className="min-w-0 flex-1 truncate text-sm font-semibold text-stone-200">
              {userName}
            </p>
          </div>
          <button
            onClick={logout}
            className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-xl border border-white/[0.08] py-2 text-[11px] font-semibold text-stone-400 transition-colors hover:border-rose-400/30 hover:text-rose-300"
          >
            <LogOut className="size-3.5" /> {t("nav.logout")}
          </button>
          <p className="mt-3 text-center text-[10px] text-stone-600">{t("app.credit")}</p>
        </div>
      </aside>

      <header className="fixed inset-x-0 top-0 z-30 border-b border-white/[0.05] bg-ink-950/85 backdrop-blur-xl lg:hidden">
        <div className="flex items-center justify-between px-4 py-3">
          <Brand size="sm" />
          <nav className="flex items-center gap-1">
            {nav.map((item) => {
              const active =
                item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  aria-label={item.label}
                  className={cn(
                    "grid size-10 place-items-center rounded-xl transition-colors",
                    active
                      ? "bg-acc-400/15 text-acc-300"
                      : "text-stone-500 hover:bg-white/[0.04] hover:text-stone-300",
                  )}
                >
                  <item.icon className="size-[18px]" strokeWidth={2.2} />
                </Link>
              );
            })}
            <button
              onClick={logout}
              aria-label={t("nav.logout")}
              className="grid size-10 place-items-center rounded-xl text-stone-500 hover:text-rose-300"
            >
              <LogOut className="size-[18px]" strokeWidth={2.2} />
            </button>
          </nav>
        </div>
      </header>

      <main className="relative min-h-screen px-5 pb-24 pt-20 sm:px-8 lg:ps-[288px] lg:pe-12 lg:pt-12">
        <div className="mx-auto w-full max-w-6xl">{children}</div>
      </main>
    </>
  );
}
