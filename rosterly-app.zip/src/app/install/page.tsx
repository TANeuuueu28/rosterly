import { redirect } from "next/navigation";
import { getViewer } from "@/lib/session-user";
import { InstallPanel } from "@/components/install-panel";

export const dynamic = "force-dynamic";

export default async function InstallPage() {
  const viewer = await getViewer();
  if (!viewer) redirect("/login");
  return <InstallPanel />;
}
