import { AVATAR_COLORS, cn, initials } from "@/lib/ui";

const SIZES = {
  sm: "size-8 text-[11px] rounded-xl",
  md: "size-10 text-xs rounded-2xl",
  lg: "size-14 text-base rounded-2xl",
} as const;

export function Avatar({
  name,
  color,
  photoUrl,
  size = "md",
  className,
}: {
  name: string;
  color: string;
  photoUrl?: string | null;
  size?: keyof typeof SIZES;
  className?: string;
}) {
  if (photoUrl) {
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img
        src={photoUrl}
        alt={name}
        className={cn("shrink-0 object-cover ring-1 ring-white/10", SIZES[size], className)}
      />
    );
  }
  const c = AVATAR_COLORS[color] ?? AVATAR_COLORS.amber;
  return (
    <div
      className={cn(
        "grid shrink-0 place-items-center font-display font-bold ring-1",
        c.bg,
        c.text,
        c.ring,
        SIZES[size],
        className,
      )}
    >
      {initials(name)}
    </div>
  );
}
