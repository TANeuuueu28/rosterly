import { NextRequest, NextResponse } from "next/server";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { groups } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const rows = await db
    .select()
    .from(groups)
    .where(eq(groups.userId, user.id))
    .orderBy(asc(groups.createdAt));
  return NextResponse.json({ groups: rows });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  try {
    const body = await req.json();
    const name = String(body.name ?? "").trim();
    if (!name) return NextResponse.json({ error: "Name is required" }, { status: 400 });

    const [created] = await db
      .insert(groups)
      .values({
        userId: user.id,
        name: name.slice(0, 120),
        kind: String(body.kind ?? "office").slice(0, 24),
        orgName: body.orgName ? String(body.orgName).trim().slice(0, 160) : null,
        memberLabel: String(body.memberLabel ?? "Member").slice(0, 40),
        roleLabel: String(body.roleLabel ?? "Role").slice(0, 40),
        icon: String(body.icon ?? "🏢").slice(0, 8),
        color: String(body.color ?? "amber").slice(0, 16),
        trackTime: body.trackTime === false ? "no" : "yes",
      })
      .returning();
    return NextResponse.json({ group: created }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Could not create table" }, { status: 500 });
  }
}
