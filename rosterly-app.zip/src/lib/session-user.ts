import { getCurrentUser } from "@/lib/auth";
import type { Lang } from "@/lib/i18n";

export type Viewer = {
  id: number;
  name: string;
  email: string | null;
  phone: string | null;
  photoUrl: string | null;
  language: Lang;
  theme: string;
};

const VALID_LANGS = [
  "en","hi","bn","mr","ta","te","gu","kn","ur","ar","es","fr","pt","zh",
];

/** Signed-in viewer (null when logged out) with safe defaults. */
export async function getViewer(): Promise<Viewer | null> {
  const user = await getCurrentUser();
  if (!user) return null;
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    phone: user.phone,
    photoUrl: user.photoUrl,
    language: (VALID_LANGS.includes(user.language) ? user.language : "en") as Lang,
    theme: user.theme || "saffron",
  };
}
