"use client";

import { useMemo, useRef, useState, useTransition, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft,
  BarChart3,
  CalendarCheck2,
  CalendarDays,
  Camera,
  CheckCheck,
  ChevronLeft,
  ChevronRight,
  Download,
  IdCard,
  Loader2,
  Pencil,
  Plus,
  RotateCcw,
  Save,
  Search,
  Trash2,
  UserCheck,
  Users,
  X,
} from "lucide-react";
import { Avatar } from "@/components/avatar";
import { StatusToggle } from "@/components/status-toggle";
import { IdCardModal, type IdCardPerson } from "@/components/id-card";
import { useT } from "@/components/providers";
import { STATUS_META, cn, pct } from "@/lib/ui";
import {
  addDays,
  daysInMonth,
  friendlyDate,
  isWeekend,
  monthLabel,
  nowTimeStr,
  shiftMonth,
  todayStr,
} from "@/lib/dates";
import type { AttendanceStatus } from "@/db/schema";

type Group = {
  id: number;
  name: string;
  kind: string;
  orgName: string | null;
  icon: string;
  color: string;
  memberLabel: string;
  roleLabel: string;
  trackTime: boolean;
};

export type Person = {
  id: number;
  name: string;
  identifier: string | null;
  role: string | null;
  phone: string | null;
  email: string | null;
  photoUrl: string | null;
  color: string;
  joinDate: string | null;
};

type Mark = { status: AttendanceStatus; checkIn: string | null; note: string };
type Tab = "register" | "people" | "report";

const SWATCHES = ["amber", "emerald", "sky", "violet", "rose", "teal", "orange", "fuchsia"];

/** Downscale a picked image to a small square data URL (keeps the DB light). */
function readPhoto(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("read"));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("img"));
      img.onload = () => {
        const S = 256;
        const canvas = document.createElement("canvas");
        canvas.width = S;
        canvas.height = S;
        const ctx = canvas.getContext("2d");
        if (!ctx) return reject(new Error("ctx"));
        const side = Math.min(img.width, img.height);
        ctx.drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, S, S);
        resolve(canvas.toDataURL("image/jpeg", 0.78));
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

export function GroupWorkspace({
  group,
  people,
  monthRecords,
  dayRecords,
  date,
  month,
  today,
  initialTab,
}: {
  group: Group;
  people: Person[];
  monthRecords: { memberId: number; date: string; status: AttendanceStatus }[];
  dayRecords: { memberId: number; status: AttendanceStatus; checkIn: string | null; note: string | null }[];
  date: string;
  month: string;
  today: string;
  initialTab: Tab;
}) {
  const router = useRouter();
  const t = useT();
  const [, startNav] = useTransition();
  const [tab, setTab] = useState<Tab>(initialTab);

  // ---------- register state ----------
  const [marks, setMarks] = useState<Record<number, Mark>>(() => {
    const m: Record<number, Mark> = {};
    for (const r of dayRecords)
      m[r.memberId] = { status: r.status, checkIn: r.checkIn, note: r.note ?? "" };
    return m;
  });
  const [dirty, setDirty] = useState<Map<number, Mark | null>>(new Map());
  const [saving, setSaving] = useState(false);
  const [flash, setFlash] = useState(false);
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return people;
    return people.filter((p) =>
      [p.name, p.identifier, p.role, p.phone].some((v) => v?.toLowerCase().includes(q)),
    );
  }, [people, query]);

  const counts = useMemo(() => {
    const c = { present: 0, absent: 0, leave: 0, half_day: 0 };
    for (const p of people) {
      const m = marks[p.id];
      if (m) c[m.status] += 1;
    }
    return c;
  }, [marks, people]);

  const marked = counts.present + counts.absent + counts.leave + counts.half_day;

  function setMark(id: number, status: AttendanceStatus | null) {
    setFlash(false);
    setMarks((prev) => {
      const copy = { ...prev };
      if (status) {
        const old = copy[id];
        copy[id] = {
          status,
          checkIn:
            group.trackTime && (status === "present" || status === "half_day")
              ? old?.checkIn ?? nowTimeStr()
              : null,
          note: old?.note ?? "",
        };
      } else delete copy[id];
      return copy;
    });
    setDirty((d) => {
      const copy = new Map(d);
      const base = dayRecords.find((r) => r.memberId === id);
      if (status) {
        const old = marks[id];
        copy.set(id, {
          status,
          checkIn:
            group.trackTime && (status === "present" || status === "half_day")
              ? old?.checkIn ?? base?.checkIn ?? nowTimeStr()
              : null,
          note: old?.note ?? base?.note ?? "",
        });
      } else if (base) copy.set(id, null);
      else copy.delete(id);
      return copy;
    });
  }

  function setNote(id: number, note: string) {
    const cur = marks[id];
    if (!cur) return;
    setMarks((p) => ({ ...p, [id]: { ...cur, note } }));
    setDirty((d) => new Map(d).set(id, { ...cur, note }));
    setFlash(false);
  }

  function markAll() {
    const m = { ...marks };
    const d = new Map(dirty);
    for (const p of filtered) {
      const next: Mark = {
        status: "present",
        checkIn: group.trackTime ? m[p.id]?.checkIn ?? nowTimeStr() : null,
        note: m[p.id]?.note ?? "",
      };
      m[p.id] = next;
      d.set(p.id, next);
    }
    setMarks(m);
    setDirty(d);
    setFlash(false);
  }

  function reset() {
    const m: Record<number, Mark> = {};
    for (const r of dayRecords)
      m[r.memberId] = { status: r.status, checkIn: r.checkIn, note: r.note ?? "" };
    setMarks(m);
    setDirty(new Map());
  }

  async function save() {
    if (!dirty.size) return;
    setSaving(true);
    try {
      const toSave: Array<Record<string, unknown>> = [];
      const toDelete: number[] = [];
      for (const [id, mark] of dirty) {
        if (mark)
          toSave.push({
            memberId: id,
            status: mark.status,
            checkIn: mark.checkIn,
            note: mark.note.trim() || null,
          });
        else toDelete.push(id);
      }
      await Promise.all([
        toSave.length
          ? fetch("/api/attendance", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ date, groupId: group.id, records: toSave }),
            })
          : Promise.resolve(),
        ...toDelete.map((id) =>
          fetch(`/api/attendance?date=${date}&memberId=${id}&groupId=${group.id}`, {
            method: "DELETE",
          }),
        ),
      ]);
      setDirty(new Map());
      setFlash(true);
      router.refresh();
    } finally {
      setSaving(false);
    }
  }

  function goDate(d: string) {
    startNav(() => router.push(`/t/${group.id}?date=${d}&month=${month}&tab=register`));
  }
  function goMonth(m: string) {
    startNav(() => router.push(`/t/${group.id}?month=${m}&date=${date}&tab=report`));
  }

  // ---------- people editor ----------
  type Form = Partial<Person> & { id?: number };
  const [form, setForm] = useState<Form | null>(null);
  const [busy, setBusy] = useState(false);
  const [confirmId, setConfirmId] = useState<number | null>(null);
  const [idCardFor, setIdCardFor] = useState<IdCardPerson | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  async function savePerson(e: FormEvent) {
    e.preventDefault();
    if (!form?.name?.trim()) return;
    setBusy(true);
    try {
      const payload = {
        groupId: group.id,
        name: form.name,
        identifier: form.identifier ?? null,
        role: form.role ?? null,
        phone: form.phone ?? null,
        email: form.email ?? null,
        photoUrl: form.photoUrl ?? null,
        color: form.color ?? "amber",
        joinDate: form.joinDate ?? null,
      };
      await fetch(form.id ? `/api/members/${form.id}` : "/api/members", {
        method: form.id ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      setForm(null);
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  async function removePerson(id: number) {
    setBusy(true);
    try {
      await fetch(`/api/members/${id}`, { method: "DELETE" });
      setConfirmId(null);
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  // ---------- report ----------
  const report = useMemo(() => {
    const byMember = new Map<number, Map<string, AttendanceStatus>>();
    for (const r of monthRecords) {
      const m = byMember.get(r.memberId) ?? new Map();
      m.set(r.date, r.status);
      byMember.set(r.memberId, m);
    }
    const dim = daysInMonth(month);
    const days = Array.from({ length: dim }, (_, i) => {
      const ds = `${month}-${String(i + 1).padStart(2, "0")}`;
      return { date: ds, day: i + 1, weekend: isWeekend(ds), future: ds > today, isToday: ds === today };
    });
    const rows = people.map((p) => {
      const m = byMember.get(p.id);
      const cells = days.map((d) => m?.get(d.date) ?? null);
      const tot = { present: 0, absent: 0, leave: 0, half_day: 0 };
      for (const c of cells) if (c) tot[c] += 1;
      const mk = tot.present + tot.absent + tot.leave + tot.half_day;
      return {
        person: p,
        cells,
        tot,
        score: mk ? Math.round(((tot.present + tot.half_day * 0.5) / mk) * 100) : null,
      };
    });
    return { days, rows };
  }, [monthRecords, people, month, today]);

  function exportCsv() {
    const head = [group.memberLabel, group.roleLabel, "ID", "Phone", "Present", "Absent", "Leave", "Half day", "Score %"];
    const lines = report.rows.map((r) =>
      [
        r.person.name,
        r.person.role ?? "",
        r.person.identifier ?? "",
        r.person.phone ?? "",
        r.tot.present,
        r.tot.absent,
        r.tot.leave,
        r.tot.half_day,
        r.score ?? "",
      ]
        .map((v) => `"${String(v).replaceAll('"', '""')}"`)
        .join(","),
    );
    const blob = new Blob([[head.join(","), ...lines].join("\n")], {
      type: "text/csv;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${group.name.replace(/\s+/g, "-").toLowerCase()}-${month}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  const field =
    "w-full rounded-xl border border-white/[0.08] bg-white/[0.03] px-3.5 py-2.5 text-sm text-stone-100 outline-none transition-colors placeholder:text-stone-600 focus:border-acc-400/50";
  const lbl = "mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.18em] text-stone-500";

  const TABS: Array<{ id: Tab; label: string; icon: typeof Users }> = [
    { id: "register", label: t("tab.register"), icon: CalendarCheck2 },
    { id: "people", label: t("tab.people"), icon: Users },
    { id: "report", label: t("tab.report"), icon: BarChart3 },
  ];

  return (
    <div className="space-y-6 pb-28">
      {/* header */}
      <header className="animate-fade-up">
        <Link
          href="/"
          className="inline-flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.2em] text-stone-500 transition-colors hover:text-stone-300"
        >
          <ArrowLeft className="size-3.5 rtl:rotate-180" /> {t("c.back")}
        </Link>
        <div className="mt-3 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="grid size-14 place-items-center rounded-2xl bg-white/[0.04] text-3xl">
              {group.icon}
            </span>
            <div>
              <h1 className="font-display text-3xl font-bold tracking-tight text-stone-50 sm:text-4xl">
                {group.name}
              </h1>
              <p className="mt-0.5 text-xs text-stone-500">
                {group.orgName || t(`kind.${group.kind}`)} · {people.length} {t("home.members")}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1 rounded-2xl border border-white/[0.06] bg-white/[0.02] p-1">
            {TABS.map((x) => (
              <button
                key={x.id}
                onClick={() => setTab(x.id)}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-[11px] font-bold transition-all",
                  tab === x.id ? "bg-acc-400/15 text-acc-300" : "text-stone-500 hover:text-stone-300",
                )}
              >
                <x.icon className="size-3.5" /> {x.label}
              </button>
            ))}
          </div>
        </div>
      </header>

      {/* ============ REGISTER ============ */}
      {tab === "register" && (
        <>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 rounded-2xl border border-white/[0.06] bg-white/[0.02] p-1.5">
              <button
                onClick={() => goDate(addDays(date, -1))}
                aria-label="Previous day"
                className="grid size-9 place-items-center rounded-xl text-stone-400 hover:bg-white/[0.05] hover:text-stone-100"
              >
                <ChevronLeft className="size-4 rtl:rotate-180" />
              </button>
              <input
                type="date"
                value={date}
                onChange={(e) => e.target.value && goDate(e.target.value)}
                className="w-[132px] rounded-xl bg-transparent px-2 py-1.5 font-mono text-xs text-stone-200 outline-none"
              />
              <button
                onClick={() => goDate(addDays(date, 1))}
                aria-label="Next day"
                className="grid size-9 place-items-center rounded-xl text-stone-400 hover:bg-white/[0.05] hover:text-stone-100"
              >
                <ChevronRight className="size-4 rtl:rotate-180" />
              </button>
              {date !== todayStr() && (
                <button
                  onClick={() => goDate(todayStr())}
                  className="rounded-xl bg-acc-400/15 px-3 py-2 text-[11px] font-bold text-acc-300"
                >
                  {t("reg.today")}
                </button>
              )}
            </div>
            <p className="text-xs text-stone-500">
              <CalendarDays className="me-1.5 inline size-3.5" />
              {friendlyDate(date)}
              {isWeekend(date) && <span className="ms-2 text-stone-600">(weekend)</span>}
            </p>
          </div>

          {people.length === 0 ? (
            <EmptyPeople t={t} onAdd={() => { setTab("people"); setForm({ color: "amber" }); }} />
          ) : (
            <>
              <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                {(["present", "absent", "leave", "half_day"] as const).map((k) => (
                  <div key={k} className="rounded-2xl border border-white/[0.05] bg-white/[0.02] px-4 py-3">
                    <p className={cn("flex items-center gap-1.5 text-[11px] font-semibold", STATUS_META[k].text)}>
                      <span className={cn("size-1.5 rounded-full", STATUS_META[k].dot)} />
                      {t(`st.${k}`)}
                    </p>
                    <p className="font-display mt-1 text-2xl font-bold text-stone-100 tabular-nums">
                      {counts[k]}
                    </p>
                  </div>
                ))}
              </section>

              <div className="flex flex-wrap items-center gap-3">
                <div className="relative min-w-[200px] flex-1">
                  <Search className="pointer-events-none absolute start-3.5 top-1/2 size-4 -translate-y-1/2 text-stone-600" />
                  <input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder={t("c.search")}
                    className="w-full rounded-2xl border border-white/[0.06] bg-white/[0.02] py-2.5 ps-10 pe-4 text-sm text-stone-200 outline-none focus:border-acc-400/40"
                  />
                </div>
                <button
                  onClick={markAll}
                  className="inline-flex items-center gap-2 rounded-2xl border border-emerald-400/20 bg-emerald-400/10 px-4 py-2.5 text-xs font-bold text-emerald-300 hover:bg-emerald-400/20"
                >
                  <UserCheck className="size-4" strokeWidth={2.4} /> {t("reg.markAll")}
                </button>
                <div className="flex items-center gap-2 text-xs text-stone-500">
                  <div className="h-1.5 w-24 overflow-hidden rounded-full bg-white/[0.06]">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-acc-400 to-acc-500 transition-all"
                      style={{ width: `${pct(marked, people.length)}%` }}
                    />
                  </div>
                  <span className="tabular-nums">{marked}/{people.length}</span>
                </div>
              </div>

              <div className="overflow-hidden rounded-3xl border border-white/[0.06] bg-white/[0.02]">
                <ul className="divide-y divide-white/[0.04]">
                  {filtered.map((p) => {
                    const m = marks[p.id];
                    return (
                      <li
                        key={p.id}
                        className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-4 py-3.5 transition-colors hover:bg-white/[0.02] sm:px-5 md:grid-cols-[minmax(0,1.5fr)_minmax(0,1fr)_auto_auto]"
                      >
                        <div className="flex min-w-0 items-center gap-3">
                          <Avatar name={p.name} color={p.color} photoUrl={p.photoUrl} />
                          <div className="min-w-0">
                            <p className="truncate text-sm font-semibold text-stone-100">{p.name}</p>
                            <p className="truncate text-[11px] text-stone-500">
                              {[p.identifier, p.role, p.phone].filter(Boolean).join(" · ") || "—"}
                            </p>
                          </div>
                        </div>
                        <input
                          value={m?.note ?? ""}
                          onChange={(e) => setNote(p.id, e.target.value)}
                          disabled={!m}
                          placeholder={m ? t("reg.note") : "—"}
                          className="hidden w-full rounded-xl border border-transparent bg-transparent px-3 py-2 text-xs text-stone-300 outline-none placeholder:text-stone-700 hover:border-white/[0.06] focus:border-white/[0.12] disabled:opacity-40 md:block"
                        />
                        {group.trackTime && (
                          <span className="hidden font-mono text-xs text-stone-500 tabular-nums md:block">
                            {m?.checkIn ?? "—"}
                          </span>
                        )}
                        <div className="justify-self-end">
                          <StatusToggle value={m?.status ?? null} onChange={(s) => setMark(p.id, s)} />
                        </div>
                      </li>
                    );
                  })}
                </ul>
              </div>
            </>
          )}
        </>
      )}

      {/* ============ PEOPLE ============ */}
      {tab === "people" && (
        <>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="relative min-w-[200px] flex-1">
              <Search className="pointer-events-none absolute start-3.5 top-1/2 size-4 -translate-y-1/2 text-stone-600" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={t("c.search")}
                className="w-full rounded-2xl border border-white/[0.06] bg-white/[0.02] py-2.5 ps-10 pe-4 text-sm text-stone-200 outline-none focus:border-acc-400/40"
              />
            </div>
            <button
              onClick={() => setForm({ color: "amber" })}
              className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-br from-acc-400 to-acc-500 px-5 py-2.5 text-xs font-bold text-ink-950 transition-transform hover:-translate-y-0.5"
            >
              <Plus className="size-4" strokeWidth={2.8} /> {t("p.add")}
            </button>
          </div>

          {people.length === 0 ? (
            <EmptyPeople t={t} onAdd={() => setForm({ color: "amber" })} />
          ) : (
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
              {filtered.map((p) => (
                <div
                  key={p.id}
                  className="group relative rounded-3xl border border-white/[0.06] bg-white/[0.02] p-4 transition-all hover:border-white/[0.13]"
                >
                  <div className="flex items-start gap-3">
                    <Avatar name={p.name} color={p.color} photoUrl={p.photoUrl} size="lg" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-display text-sm font-semibold text-stone-100">
                        {p.name}
                      </p>
                      {p.role && <p className="truncate text-[11px] text-stone-500">{p.role}</p>}
                      {p.identifier && (
                        <span className="mt-1 inline-block rounded-lg bg-acc-400/10 px-2 py-0.5 font-mono text-[10px] font-bold text-acc-300">
                          {p.identifier}
                        </span>
                      )}
                      {p.phone && (
                        <a
                          href={`tel:${p.phone}`}
                          className="mt-1 block truncate text-[11px] text-stone-500 hover:text-acc-300"
                        >
                          {p.phone}
                        </a>
                      )}
                    </div>
                    <div className="flex flex-col gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                      <button
                        onClick={() => setIdCardFor(p)}
                        aria-label="ID Card"
                        className="grid size-8 place-items-center rounded-xl border border-white/[0.06] text-stone-500 hover:border-acc-400/40 hover:text-acc-300"
                      >
                        <IdCard className="size-3.5" />
                      </button>
                      <button
                        onClick={() => setForm(p)}
                        aria-label={t("p.edit")}
                        className="grid size-8 place-items-center rounded-xl border border-white/[0.06] text-stone-500 hover:text-stone-200"
                      >
                        <Pencil className="size-3.5" />
                      </button>
                      <button
                        onClick={() => setConfirmId(confirmId === p.id ? null : p.id)}
                        aria-label={t("c.delete")}
                        className="grid size-8 place-items-center rounded-xl border border-white/[0.06] text-stone-500 hover:border-rose-400/40 hover:text-rose-300"
                      >
                        <Trash2 className="size-3.5" />
                      </button>
                    </div>
                  </div>

                  <AnimatePresence>
                    {confirmId === p.id && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-2.5 rounded-3xl bg-ink-900/95 p-4 text-center backdrop-blur"
                      >
                        <p className="text-sm font-semibold text-stone-100">{t("p.deleteQ")}</p>
                        <p className="text-[11px] text-stone-500">{t("p.deleteHint")}</p>
                        <div className="flex gap-2">
                          <button
                            onClick={() => setConfirmId(null)}
                            className="rounded-xl border border-white/[0.08] px-3 py-1.5 text-xs font-semibold text-stone-300"
                          >
                            {t("c.cancel")}
                          </button>
                          <button
                            onClick={() => removePerson(p.id)}
                            disabled={busy}
                            className="inline-flex items-center gap-1.5 rounded-xl bg-rose-500 px-3 py-1.5 text-xs font-bold text-white disabled:opacity-50"
                          >
                            {busy && <Loader2 className="size-3 animate-spin" />}
                            {t("c.delete")}
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {/* ============ REPORT ============ */}
      {tab === "report" && (
        <>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 rounded-2xl border border-white/[0.06] bg-white/[0.02] p-1.5">
              <button
                onClick={() => goMonth(shiftMonth(month, -1))}
                aria-label="Previous month"
                className="grid size-9 place-items-center rounded-xl text-stone-400 hover:bg-white/[0.05] hover:text-stone-100"
              >
                <ChevronLeft className="size-4 rtl:rotate-180" />
              </button>
              <span className="min-w-[120px] text-center font-display text-sm font-semibold text-stone-200">
                {monthLabel(month)}
              </span>
              <button
                onClick={() => goMonth(shiftMonth(month, 1))}
                disabled={shiftMonth(month, 1) > today.slice(0, 7)}
                aria-label="Next month"
                className="grid size-9 place-items-center rounded-xl text-stone-400 hover:bg-white/[0.05] hover:text-stone-100 disabled:opacity-30"
              >
                <ChevronRight className="size-4 rtl:rotate-180" />
              </button>
            </div>
            {people.length > 0 && (
              <button
                onClick={exportCsv}
                className="inline-flex items-center gap-2 rounded-2xl border border-white/[0.08] bg-white/[0.03] px-4 py-2.5 text-xs font-bold text-stone-200 hover:border-acc-400/30 hover:text-acc-200"
              >
                <Download className="size-4" strokeWidth={2.4} /> {t("rep.csv")}
              </button>
            )}
          </div>

          {people.length === 0 || monthRecords.length === 0 ? (
            <div className="rounded-3xl border border-dashed border-white/[0.08] py-16 text-center text-sm text-stone-500">
              {t("rep.empty")}
            </div>
          ) : (
            <div className="overflow-hidden rounded-3xl border border-white/[0.06] bg-white/[0.02]">
              <div className="overflow-x-auto p-4 sm:p-5">
                <table className="w-full min-w-[720px] border-separate" style={{ borderSpacing: "3px" }}>
                  <thead>
                    <tr>
                      <th className="sticky start-0 z-10 min-w-[170px] bg-ink-900/95 text-start text-[10px] font-semibold uppercase tracking-[0.15em] text-stone-600 backdrop-blur">
                        {group.memberLabel}
                      </th>
                      {report.days.map((d) => (
                        <th
                          key={d.date}
                          title={d.date}
                          className={cn(
                            "w-6 pb-1 text-center font-mono text-[9px]",
                            d.isToday ? "text-acc-300" : d.weekend ? "text-stone-700" : "text-stone-500",
                          )}
                        >
                          {d.day}
                        </th>
                      ))}
                      <th className="min-w-[56px] text-end text-[10px] font-semibold uppercase tracking-[0.15em] text-stone-600">
                        {t("st.score")}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {report.rows.map((r) => (
                      <tr key={r.person.id}>
                        <td className="sticky start-0 z-10 bg-ink-900/95 backdrop-blur">
                          <div className="flex items-center gap-2.5 py-1 pe-3">
                            <Avatar
                              name={r.person.name}
                              color={r.person.color}
                              photoUrl={r.person.photoUrl}
                              size="sm"
                            />
                            <p className="truncate text-xs font-semibold text-stone-200">
                              {r.person.name}
                            </p>
                          </div>
                        </td>
                        {report.days.map((d, i) => {
                          const s = r.cells[i];
                          return (
                            <td key={d.date} className="text-center">
                              <div
                                title={`${r.person.name} · ${d.date}${s ? ` · ${t(`st.${s}`)}` : ""}`}
                                className={cn(
                                  "mx-auto size-[18px] rounded-[6px] transition-transform hover:scale-125",
                                  !s && !d.future && "bg-white/[0.05]",
                                  !s && d.future && "border border-dashed border-white/[0.06]",
                                  d.isToday && "ring-1 ring-acc-300/60",
                                )}
                                style={s ? { background: `${STATUS_META[s].hex}cc` } : undefined}
                              />
                            </td>
                          );
                        })}
                        <td className="text-end">
                          <span
                            className={cn(
                              "font-display text-sm font-bold tabular-nums",
                              r.score === null
                                ? "text-stone-600"
                                : r.score >= 90
                                  ? "text-emerald-300"
                                  : r.score >= 75
                                    ? "text-acc-300"
                                    : "text-rose-300",
                            )}
                          >
                            {r.score === null ? "—" : `${r.score}%`}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}

      {/* save bar */}
      <AnimatePresence>
        {dirty.size > 0 && tab === "register" && (
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 24 }}
            className="fixed inset-x-4 bottom-5 z-40 mx-auto flex max-w-xl items-center justify-between gap-3 rounded-2xl border border-white/10 bg-ink-800/95 px-4 py-3 shadow-[0_24px_60px_-16px_rgba(0,0,0,0.9)] backdrop-blur-xl lg:start-[272px]"
          >
            <p className="text-xs font-semibold text-stone-300">
              <span className="text-acc-300">{dirty.size}</span> {t("reg.pending")}
            </p>
            <div className="flex items-center gap-2">
              <button
                onClick={reset}
                className="inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-semibold text-stone-400 hover:bg-white/[0.05] hover:text-stone-200"
              >
                <RotateCcw className="size-3.5" /> {t("reg.reset")}
              </button>
              <button
                onClick={save}
                disabled={saving}
                className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-br from-acc-400 to-acc-500 px-4 py-2 text-xs font-bold text-ink-950 disabled:opacity-50"
              >
                {saving ? <Loader2 className="size-3.5 animate-spin" /> : <Save className="size-3.5" strokeWidth={2.6} />}
                {t("reg.save")}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {flash && dirty.size === 0 && tab === "register" && (
        <p className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-300">
          <CheckCheck className="size-4" /> {t("reg.saved")}
        </p>
      )}

      {/* ID card modal */}
      <AnimatePresence>
        {idCardFor && (
          <IdCardModal
            person={idCardFor}
            group={{ id: group.id, name: group.name, orgName: group.orgName, icon: group.icon }}
            onClose={() => setIdCardFor(null)}
          />
        )}
      </AnimatePresence>

      {/* person modal */}
      <AnimatePresence>
        {form && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setForm(null)}
            className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/70 p-4 py-10 backdrop-blur-sm"
          >
            <motion.form
              initial={{ opacity: 0, scale: 0.95, y: 18 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 18 }}
              onClick={(e) => e.stopPropagation()}
              onSubmit={savePerson}
              className="w-full max-w-md rounded-3xl border border-white/10 bg-ink-900 p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg font-bold text-stone-50">
                  {form.id ? t("p.edit") : t("p.add")}
                </h2>
                <button
                  type="button"
                  onClick={() => setForm(null)}
                  aria-label={t("c.cancel")}
                  className="grid size-8 place-items-center rounded-xl text-stone-500 hover:text-stone-200"
                >
                  <X className="size-4" />
                </button>
              </div>

              <div className="mt-5 flex items-center gap-4">
                <button
                  type="button"
                  onClick={() => fileRef.current?.click()}
                  className="group relative"
                  aria-label={t("p.photo")}
                >
                  <Avatar
                    name={form.name || "?"}
                    color={form.color ?? "amber"}
                    photoUrl={form.photoUrl}
                    size="lg"
                    className="size-20 rounded-3xl"
                  />
                  <span className="absolute inset-0 grid place-items-center rounded-3xl bg-black/55 opacity-0 transition-opacity group-hover:opacity-100">
                    <Camera className="size-5 text-white" />
                  </span>
                </button>
                <div className="flex-1">
                  <p className="text-xs font-semibold text-stone-300">{t("p.photo")}</p>
                  <p className="mt-0.5 text-[11px] text-stone-500">{t("p.photoHint")}</p>
                  {form.photoUrl && (
                    <button
                      type="button"
                      onClick={() => setForm({ ...form, photoUrl: null })}
                      className="mt-1.5 text-[11px] font-semibold text-rose-300 hover:underline"
                    >
                      {t("c.delete")}
                    </button>
                  )}
                </div>
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={async (e) => {
                    const f = e.target.files?.[0];
                    if (!f) return;
                    try {
                      setForm({ ...form, photoUrl: await readPhoto(f) });
                    } catch {}
                    e.target.value = "";
                  }}
                />
              </div>

              <div className="mt-5 space-y-3.5">
                <div>
                  <label className={lbl}>{t("p.name")}</label>
                  <input
                    required
                    autoFocus
                    value={form.name ?? ""}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className={field}
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className={lbl}>{t("p.id")}</label>
                    <input
                      value={form.identifier ?? ""}
                      onChange={(e) => setForm({ ...form, identifier: e.target.value })}
                      className={field}
                    />
                  </div>
                  <div>
                    <label className={lbl}>{group.roleLabel}</label>
                    <input
                      value={form.role ?? ""}
                      onChange={(e) => setForm({ ...form, role: e.target.value })}
                      className={field}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className={lbl}>{t("p.phone")}</label>
                    <input
                      inputMode="tel"
                      value={form.phone ?? ""}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      className={field}
                    />
                  </div>
                  <div>
                    <label className={lbl}>{t("p.joined")}</label>
                    <input
                      type="date"
                      value={form.joinDate ?? ""}
                      onChange={(e) => setForm({ ...form, joinDate: e.target.value })}
                      className={field}
                    />
                  </div>
                </div>
                <div>
                  <label className={lbl}>{t("p.email")}</label>
                  <input
                    type="email"
                    value={form.email ?? ""}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    className={field}
                  />
                </div>
                <div className="flex gap-2">
                  {SWATCHES.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setForm({ ...form, color: c })}
                      aria-label={c}
                      className={cn(
                        "size-7 rounded-full transition-all",
                        {
                          amber: "bg-amber-400", emerald: "bg-emerald-400", sky: "bg-sky-400",
                          violet: "bg-violet-400", rose: "bg-rose-400", teal: "bg-teal-400",
                          orange: "bg-orange-400", fuchsia: "bg-fuchsia-400",
                        }[c],
                        form.color === c ? "scale-110 ring-2 ring-white/70" : "opacity-60",
                      )}
                    />
                  ))}
                </div>
              </div>

              <button
                type="submit"
                disabled={busy}
                className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-acc-400 to-acc-500 py-3 text-sm font-bold text-ink-950 transition-transform hover:-translate-y-0.5 disabled:opacity-50"
              >
                {busy && <Loader2 className="size-4 animate-spin" />}
                {t("c.save")}
              </button>
            </motion.form>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function EmptyPeople({ t, onAdd }: { t: (k: string) => string; onAdd: () => void }) {
  return (
    <div className="rounded-3xl border border-dashed border-white/[0.09] bg-white/[0.02] px-6 py-16 text-center">
      <div className="mx-auto grid size-14 place-items-center rounded-full border border-white/[0.08]">
        <Users className="size-6 text-stone-500" strokeWidth={1.6} />
      </div>
      <p className="mt-4 text-sm text-stone-400">{t("reg.empty")}</p>
      <button
        onClick={onAdd}
        className="mt-4 inline-flex items-center gap-2 rounded-xl bg-gradient-to-br from-acc-400 to-acc-500 px-4 py-2 text-xs font-bold text-ink-950"
      >
        <Plus className="size-4" strokeWidth={2.8} /> {t("p.add")}
      </button>
    </div>
  );
}
