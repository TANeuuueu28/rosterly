import { NextRequest, NextResponse } from "next/server";
import { and, eq, gte, inArray, lte } from "drizzle-orm";
import { db } from "@/db";
import { attendance, groups, members, type AttendanceStatus } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

const VALID: AttendanceStatus[] = ["present", "absent", "leave", "half_day"];
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

/** All member ids inside a group the current user owns. */
async function ownedMemberIds(userId: number, groupId: number): Promise<number[]> {
  const rows = await db
    .select({ id: members.id })
    .from(members)
    .innerJoin(groups, eq(groups.id, members.groupId))
    .where(and(eq(members.groupId, groupId), eq(groups.userId, userId)));
  return rows.map((r) => r.id);
}

export async function GET(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const groupId = Number(searchParams.get("groupId"));
  const from = searchParams.get("from");
  const to = searchParams.get("to");
  if (!Number.isFinite(groupId) || !from || !to || !DATE_RE.test(from) || !DATE_RE.test(to)) {
    return NextResponse.json({ error: "Provide ?groupId=&from=&to=" }, { status: 400 });
  }

  const ids = await ownedMemberIds(user.id, groupId);
  if (ids.length === 0) return NextResponse.json({ records: [] });

  const rows = await db
    .select()
    .from(attendance)
    .where(
      and(
        inArray(attendance.memberId, ids),
        gte(attendance.date, from),
        lte(attendance.date, to),
      ),
    );
  return NextResponse.json({ records: rows });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  try {
    const body = await req.json();
    const date = String(body.date ?? "");
    const groupId = Number(body.groupId);
    const records: Array<{ memberId?: number; status?: string; checkIn?: string | null; note?: string | null }> =
      Array.isArray(body.records) ? body.records : [];

    if (!DATE_RE.test(date) || !Number.isFinite(groupId)) {
      return NextResponse.json({ error: "Valid date and groupId required" }, { status: 400 });
    }
    if (records.length === 0) return NextResponse.json({ ok: true, saved: 0 });

    const allowed = new Set(await ownedMemberIds(user.id, groupId));
    const values = records
      .filter(
        (r) =>
          allowed.has(Number(r.memberId)) &&
          typeof r.status === "string" &&
          VALID.includes(r.status as AttendanceStatus),
      )
      .map((r) => ({
        memberId: Number(r.memberId),
        date,
        status: r.status as AttendanceStatus,
        checkIn: typeof r.checkIn === "string" && r.checkIn ? r.checkIn.slice(0, 5) : null,
        note: typeof r.note === "string" && r.note.trim() ? r.note.trim().slice(0, 300) : null,
      }));

    if (values.length === 0) {
      return NextResponse.json({ error: "No valid records" }, { status: 400 });
    }

    const saved = await db
      .insert(attendance)
      .values(values)
      .onConflictDoUpdate({
        target: [attendance.memberId, attendance.date],
        set: {
          status: attendance.status,
          checkIn: attendance.checkIn,
          note: attendance.note,
        },
      })
      .returning();

    return NextResponse.json({ ok: true, saved: saved.length });
  } catch {
    return NextResponse.json({ error: "Could not save attendance" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const date = searchParams.get("date");
  const memberId = Number(searchParams.get("memberId"));
  const groupId = Number(searchParams.get("groupId"));
  if (!date || !DATE_RE.test(date) || !Number.isFinite(memberId) || !Number.isFinite(groupId)) {
    return NextResponse.json({ error: "Provide ?date=&memberId=&groupId=" }, { status: 400 });
  }

  const allowed = await ownedMemberIds(user.id, groupId);
  if (!allowed.includes(memberId)) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  await db
    .delete(attendance)
    .where(and(eq(attendance.date, date), eq(attendance.memberId, memberId)));
  return NextResponse.json({ ok: true });
}
