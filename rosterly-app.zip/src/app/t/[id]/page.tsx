import { notFound, redirect } from "next/navigation";
import { and, asc, eq, gte, inArray, lte } from "drizzle-orm";
import { db } from "@/db";
import { attendance, groups, members } from "@/db/schema";
import { getViewer } from "@/lib/session-user";
import { monthEnd, monthOf, monthStart, todayStr } from "@/lib/dates";
import { GroupWorkspace } from "@/components/group-workspace";

export const dynamic = "force-dynamic";

export default async function GroupPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ month?: string; date?: string; tab?: string }>;
}) {
  const viewer = await getViewer();
  if (!viewer) redirect("/login");

  const { id } = await params;
  const sp = await searchParams;
  const groupId = Number(id);
  if (!Number.isFinite(groupId)) notFound();

  const rows = await db
    .select()
    .from(groups)
    .where(and(eq(groups.id, groupId), eq(groups.userId, viewer.id)))
    .limit(1);
  const group = rows[0];
  if (!group) notFound();

  const today = todayStr();
  const month = sp.month && /^\d{4}-\d{2}$/.test(sp.month) ? sp.month : monthOf(today);
  const date = sp.date && /^\d{4}-\d{2}-\d{2}$/.test(sp.date) ? sp.date : today;

  const people = await db
    .select()
    .from(members)
    .where(eq(members.groupId, groupId))
    .orderBy(asc(members.name));

  const ids = people.map((p) => p.id);
  const from = monthStart(month);
  const to = monthEnd(month);

  const records = ids.length
    ? await db
        .select()
        .from(attendance)
        .where(
          and(
            inArray(attendance.memberId, ids),
            gte(attendance.date, from),
            lte(attendance.date, to),
          ),
        )
    : [];

  // Today may fall outside the browsed month — fetch it separately
  const todayRecords =
    ids.length && (date < from || date > to)
      ? await db
          .select()
          .from(attendance)
          .where(and(inArray(attendance.memberId, ids), eq(attendance.date, date)))
      : records.filter((r) => r.date === date);

  return (
    <GroupWorkspace
      group={{
        id: group.id,
        name: group.name,
        kind: group.kind,
        orgName: group.orgName,
        icon: group.icon,
        color: group.color,
        memberLabel: group.memberLabel,
        roleLabel: group.roleLabel,
        trackTime: group.trackTime === "yes",
      }}
      people={people.map((p) => ({
        id: p.id,
        name: p.name,
        identifier: p.identifier,
        role: p.role,
        phone: p.phone,
        email: p.email,
        photoUrl: p.photoUrl,
        color: p.color,
        joinDate: p.joinDate,
      }))}
      monthRecords={records.map((r) => ({
        memberId: r.memberId,
        date: r.date,
        status: r.status,
      }))}
      dayRecords={todayRecords.map((r) => ({
        memberId: r.memberId,
        status: r.status,
        checkIn: r.checkIn,
        note: r.note,
      }))}
      date={date}
      month={month}
      today={today}
      initialTab={sp.tab === "people" || sp.tab === "report" ? sp.tab : "register"}
    />
  );
}
