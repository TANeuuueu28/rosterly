"use client";

import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { STATUS_META } from "@/lib/ui";

export type TrendPoint = {
  label: string;
  present: number;
  half_day: number;
  leave: number;
  absent: number;
};

function ChartTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: Array<{ name: string; value: number; color: string }>;
  label?: string;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-2xl border border-white/10 bg-ink-900/95 px-4 py-3 shadow-2xl backdrop-blur">
      <p className="mb-1.5 font-display text-xs font-semibold text-stone-200">{label}</p>
      {payload.map((p) => (
        <div key={p.name} className="flex items-center gap-2 text-xs">
          <span className="size-2 rounded-full" style={{ background: p.color }} />
          <span className="capitalize text-stone-400">{p.name.replace("_", " ")}</span>
          <span className="ml-auto pl-4 font-semibold text-stone-100 tabular-nums">{p.value}</span>
        </div>
      ))}
    </div>
  );
}

export function TrendChart({ data }: { data: TrendPoint[] }) {
  return (
    <div className="h-[280px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 10, right: 6, left: -18, bottom: 0 }}>
          <defs>
            {(["present", "half_day", "leave", "absent"] as const).map((k) => (
              <linearGradient key={k} id={`g-${k}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={STATUS_META[k].hex} stopOpacity={0.35} />
                <stop offset="100%" stopColor={STATUS_META[k].hex} stopOpacity={0.02} />
              </linearGradient>
            ))}
          </defs>
          <CartesianGrid stroke="rgba(255,255,255,0.04)" vertical={false} />
          <XAxis
            dataKey="label"
            tick={{ fill: "#78716c", fontSize: 10 }}
            tickLine={false}
            axisLine={false}
            interval="preserveStartEnd"
            minTickGap={30}
          />
          <YAxis
            tick={{ fill: "#78716c", fontSize: 10 }}
            tickLine={false}
            axisLine={false}
            allowDecimals={false}
          />
          <Tooltip content={<ChartTooltip />} cursor={{ stroke: "rgba(255,255,255,0.12)" }} />
          <Area
            type="monotone"
            dataKey="present"
            stackId="1"
            stroke={STATUS_META.present.hex}
            strokeWidth={2}
            fill="url(#g-present)"
          />
          <Area
            type="monotone"
            dataKey="half_day"
            stackId="1"
            stroke={STATUS_META.half_day.hex}
            strokeWidth={1.6}
            fill="url(#g-half_day)"
          />
          <Area
            type="monotone"
            dataKey="leave"
            stackId="1"
            stroke={STATUS_META.leave.hex}
            strokeWidth={1.6}
            fill="url(#g-leave)"
          />
          <Area
            type="monotone"
            dataKey="absent"
            stackId="1"
            stroke={STATUS_META.absent.hex}
            strokeWidth={1.6}
            fill="url(#g-absent)"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
