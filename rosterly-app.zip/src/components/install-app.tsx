"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Download, Smartphone, X } from "lucide-react";
import { useT } from "@/components/providers";

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

let deferredPrompt: BeforeInstallPromptEvent | null = null;

export function ServiceWorkerRegister() {
  useEffect(() => {
    if ("serviceWorker" in navigator && process.env.NODE_ENV === "production") {
      navigator.serviceWorker.register("/sw.js").catch(() => {});
    }
  }, []);
  return null;
}

/** Shared install trigger used by the banner and the /install page. */
export function useInstallPrompt() {
  const [available, setAvailable] = useState(Boolean(deferredPrompt));

  useEffect(() => {
    const onPrompt = (e: Event) => {
      e.preventDefault();
      deferredPrompt = e as BeforeInstallPromptEvent;
      setAvailable(true);
    };
    const onInstalled = () => {
      deferredPrompt = null;
      setAvailable(false);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  async function install() {
    if (!deferredPrompt) return false;
    await deferredPrompt.prompt();
    const choice = await deferredPrompt.userChoice.catch(() => null);
    deferredPrompt = null;
    setAvailable(false);
    return choice?.outcome === "accepted";
  }

  return { available, install };
}

const DISMISS_KEY = "haziri-install-dismissed";

export function InstallBanner() {
  const t = useT();
  const { available, install } = useInstallPrompt();
  const [dismissed, setDismissed] = useState(true);

  useEffect(() => {
    try {
      setDismissed(Boolean(localStorage.getItem(DISMISS_KEY)));
    } catch {
      setDismissed(false);
    }
  }, []);

  function hide() {
    setDismissed(true);
    try {
      localStorage.setItem(DISMISS_KEY, "1");
    } catch {}
  }

  return (
    <AnimatePresence>
      {available && !dismissed && (
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 24 }}
          transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
          className="fixed inset-x-4 bottom-5 z-50 mx-auto flex max-w-md items-center gap-3 rounded-2xl border border-white/10 bg-ink-800/95 p-3.5 shadow-[0_24px_60px_-16px_rgba(0,0,0,0.9)] backdrop-blur-xl lg:start-[272px]"
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/icons/icon-192.png" alt="" className="size-11 rounded-xl" />
          <div className="min-w-0 flex-1">
            <p className="flex items-center gap-1.5 text-xs font-bold text-stone-100">
              <Smartphone className="size-3.5 text-acc-300" />
              {t("install.title")}
            </p>
            <p className="mt-0.5 truncate text-[11px] text-stone-500">{t("install.sub")}</p>
          </div>
          <button
            onClick={() => void install()}
            className="inline-flex shrink-0 items-center gap-1.5 rounded-xl bg-gradient-to-br from-acc-400 to-acc-500 px-3.5 py-2 text-[11px] font-bold text-ink-950 transition-transform hover:-translate-y-0.5"
          >
            <Download className="size-3.5" strokeWidth={2.6} />
            {t("install.btn")}
          </button>
          <button
            onClick={hide}
            aria-label="Dismiss"
            className="grid size-8 shrink-0 place-items-center rounded-xl text-stone-500 hover:text-stone-300"
          >
            <X className="size-4" />
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
