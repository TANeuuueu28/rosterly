import { redirect } from "next/navigation";
import { getViewer } from "@/lib/session-user";
import { SettingsPanel } from "@/components/settings-panel";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const viewer = await getViewer();
  if (!viewer) redirect("/login");

  return (
    <SettingsPanel
      initial={{
        name: viewer.name,
        language: viewer.language,
        theme: viewer.theme,
        photoUrl: viewer.photoUrl,
        email: viewer.email,
        phone: viewer.phone,
      }}
    />
  );
}
