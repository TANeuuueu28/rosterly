import "server-only";
import { randomBytes, scrypt as _scrypt, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { and, desc, eq, lt, sql } from "drizzle-orm";
import { db } from "@/db";
import { otpCodes, users } from "@/db/schema";

const scrypt = promisify(_scrypt) as (
  pw: string,
  salt: string,
  len: number,
  opts?: Record<string, number>,
) => Promise<Buffer>;

export type OtpPurpose =
  | "signup"
  | "login"
  | "reset"
  | "change-password"
  | "change-email"
  | "change-phone";

export const TRUST_COOKIE = "haziri_trust";
export const TRUST_DAYS = 14;
export const MAX_PASSWORD_ATTEMPTS = 5;
export const LOCK_MINUTES = 15;
const OTP_TTL_MS = 10 * 60 * 1000;
const RESEND_COOLDOWN_MS = 15 * 1000; // fast resend
const MAX_PER_HOUR = 8;
const OTP_MAX_TRIES = 3;

/** Light KDF — codes are 10-min, 3-try limited; this keeps verify ~instant. */
const OTP_SCRYPT = { N: 2048, r: 8, p: 1, maxmem: 64 * 1024 * 1024 } as const;

export function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}
export function normalizePhone(phone: string): string {
  return phone.replace(/[^\d+]/g, "");
}

export async function hashSecret(secret: string): Promise<string> {
  const salt = randomBytes(12).toString("hex");
  const buf = await scrypt(secret, salt, 32, OTP_SCRYPT);
  return `${salt}:${buf.toString("hex")}`;
}

export async function verifySecret(secret: string, stored: string): Promise<boolean> {
  const [salt, key] = stored.split(":");
  if (!salt || !key) return false;
  const buf = await scrypt(secret, salt, 32, OTP_SCRYPT);
  const keyBuf = Buffer.from(key, "hex");
  if (keyBuf.length !== buf.length) return false;
  return timingSafeEqual(buf, keyBuf);
}

/** 0–4 strength score for the meter. */
export function passwordScore(pw: string): number {
  let s = 0;
  if (pw.length >= 8) s++;
  if (pw.length >= 12) s++;
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) s++;
  if (/\d/.test(pw)) s++;
  if (/[^A-Za-z0-9]/.test(pw)) s++;
  return Math.min(s, 4);
}

/* ---------- providers ---------- */

function emailConfigured(): boolean {
  return Boolean(process.env.RESEND_API_KEY);
}
function smsConfigured(): boolean {
  return Boolean(process.env.MSG91_AUTH_KEY && process.env.MSG91_TEMPLATE_ID);
}
export function channelsConfigured() {
  return { email: emailConfigured(), sms: smsConfigured() };
}

async function sendEmail(to: string, subject: string, html: string): Promise<boolean> {
  if (!emailConfigured()) return false;
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: process.env.RESEND_FROM || "Rosterly <onboarding@resend.dev>",
        to: [to],
        subject,
        html,
      }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function sendSms(to: string, message: string): Promise<boolean> {
  if (!smsConfigured()) return false;
  try {
    const res = await fetch(
      `https://api.msg91.com/api/v5/otp?templateId=${process.env.MSG91_TEMPLATE_ID}&mobile=${encodeURIComponent(to.replace("+", ""))}&authkey=${process.env.MSG91_AUTH_KEY}&otp=${message}`,
      { method: "GET" },
    );
    return res.ok;
  } catch {
    return false;
  }
}

const emailTemplate = (code: string, app = "Rosterly") => `
  <div style="font-family:Arial,sans-serif;background:#0b0906;padding:32px;color:#e7e5e4">
    <div style="max-width:420px;margin:auto;background:#171310;border:1px solid rgba(255,255,255,.08);border-radius:20px;padding:28px">
      <p style="font-size:13px;letter-spacing:3px;color:#fbbf24;text-transform:uppercase;margin:0">${app} · Security</p>
      <p style="font-size:22px;font-weight:bold;margin:14px 0 6px">Your verification code</p>
      <p style="font-size:42px;letter-spacing:12px;font-weight:bold;color:#fff7ed;margin:8px 0">${code}</p>
      <p style="font-size:13px;color:#a8a29e;line-height:1.5">This code expires in 10 minutes. Never share it with anyone. If you did not request it, ignore this email.</p>
    </div>
  </div>`;

/* ---------- OTP flow ---------- */

export type SendResult = { delivered: boolean; devCode?: string };

/** Create + deliver an OTP. Throws Error with a friendly message on rate limits. */
export async function createAndSendOtp(
  target: string,
  purpose: OtpPurpose,
  meta?: Record<string, unknown>,
): Promise<SendResult> {
  const isEmail = target.includes("@");

  // one query: cooldown + hourly ceiling together
  const now = Date.now();
  const [stat] = await db
    .select({
      recent: sql<number>`count(*) filter (where ${otpCodes.purpose} = ${purpose} and ${otpCodes.createdAt} > ${new Date(now - RESEND_COOLDOWN_MS)})::int`,
      hourly: sql<number>`count(*) filter (where ${otpCodes.createdAt} > ${new Date(now - 3600_000)})::int`,
    })
    .from(otpCodes)
    .where(eq(otpCodes.target, target));

  if ((stat?.recent ?? 0) > 0) {
    throw new Error("Thoda ruko — 15 second baad dobara bhej sakte ho.");
  }
  if ((stat?.hourly ?? 0) >= MAX_PER_HOUR) {
    throw new Error("Aaj ke liye codes ka limit cross ho gaya. 1 hour baad try karo.");
  }

  const code = String(100000 + Math.floor(Math.random() * 900000));

  // replace previous codes for this purpose + insert new (hash computed in parallel is trivial)
  await db.delete(otpCodes).where(and(eq(otpCodes.target, target), eq(otpCodes.purpose, purpose)));
  await db.insert(otpCodes).values({
    target,
    purpose,
    codeHash: await hashSecret(code),
    meta: meta ? JSON.stringify(meta) : null,
    expiresAt: new Date(Date.now() + OTP_TTL_MS),
  });

  const subject =
    purpose === "reset"
      ? "Reset your Rosterly password"
      : purpose === "login"
        ? "Rosterly login code"
        : "Verify your email with Rosterly";

  let delivered = false;
  if (isEmail) delivered = await sendEmail(target, subject, emailTemplate(code));
  else delivered = await sendSms(target, code);

  // No provider configured (or send failed) → dev delivery so the flow still works.
  return delivered ? { delivered: true } : { delivered: false, devCode: code };
}

/** Validate + consume an OTP. */
export async function verifyOtp(
  target: string,
  purpose: OtpPurpose,
  code: string,
): Promise<{ ok: boolean; meta?: Record<string, unknown> }> {
  const rows = await db
    .select()
    .from(otpCodes)
    .where(and(eq(otpCodes.target, target), eq(otpCodes.purpose, purpose)))
    .orderBy(desc(otpCodes.id))
    .limit(1);
  const row = rows[0];
  if (!row) return { ok: false };
  if (row.expiresAt < new Date()) {
    await db.delete(otpCodes).where(eq(otpCodes.id, row.id));
    return { ok: false };
  }
  if (row.attempts >= OTP_MAX_TRIES) {
    await db.delete(otpCodes).where(eq(otpCodes.id, row.id));
    throw new Error("Bahut zyada galat codes. Naya code request karo.");
  }
  const good = await verifySecret(code.trim(), row.codeHash);
  if (!good) {
    await db
      .update(otpCodes)
      .set({ attempts: row.attempts + 1 })
      .where(eq(otpCodes.id, row.id));
    return { ok: false };
  }
  const meta = row.meta ? (JSON.parse(row.meta) as Record<string, unknown>) : undefined;
  await db.delete(otpCodes).where(eq(otpCodes.id, row.id));
  return { ok: true, meta };
}

/* ---------- account lockout ---------- */

export async function assertNotLocked(email: string | null, phone: string | null) {
  if (!email && !phone) throw new Error("Account nahi mila");
  const rows = await db
    .select({ id: users.id, lockedUntil: users.lockedUntil })
    .from(users)
    .where(email ? eq(users.email, email) : lt(users.id, 0))
    .limit(1);
  let locked = rows[0]?.lockedUntil;
  if (!locked && phone) {
    const p = await db
      .select({ id: users.id, lockedUntil: users.lockedUntil })
      .from(users)
      .where(eq(users.phone, phone))
      .limit(1);
    locked = p[0]?.lockedUntil;
  }
  if (locked && locked > new Date()) {
    const mins = Math.ceil((locked.getTime() - Date.now()) / 60000);
    throw new Error(`Account temporarily locked. ${mins} minute baad try karo — ya "Forgot password" use karo.`);
  }
}

export async function registerFailure(userId: number) {
  await db
    .update(users)
    .set({ failedAttempts: sql`${users.failedAttempts} + 1` })
    .where(eq(users.id, userId));
  const rows = await db
    .select({ failedAttempts: users.failedAttempts })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);
  if ((rows[0]?.failedAttempts ?? 0) >= MAX_PASSWORD_ATTEMPTS) {
    await db
      .update(users)
      .set({
        lockedUntil: new Date(Date.now() + LOCK_MINUTES * 60000),
        failedAttempts: 0,
      })
      .where(eq(users.id, userId));
    throw new Error(
      `${MAX_PASSWORD_ATTEMPTS} galat attempts — account ${LOCK_MINUTES} minute ke liye lock ho gaya.`,
    );
  }
}

export async function clearFailures(userId: number) {
  await db
    .update(users)
    .set({ failedAttempts: 0, lockedUntil: null })
    .where(eq(users.id, userId));
}

export function purgeExpiredOtps() {
  return db.delete(otpCodes).where(lt(otpCodes.expiresAt, new Date())).catch(() => undefined);
}
