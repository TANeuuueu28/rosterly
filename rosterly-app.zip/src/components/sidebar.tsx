"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  BarChart3,
  CalendarCheck2,
  GraduationCap,
  LayoutDashboard,
  Settings,
  Users,
} from "lucide-react";
import { cn } from "@/lib/ui";
import { friendlyDate, todayStr } from "@/lib/dates";
import { useT } from "@/components/providers";

function navItems(t: (k: string) => string) {
  return [
    { href: "/", label: t("nav.dashboard"), icon: LayoutDashboard },
    { href: "/attendance", label: t("nav.attendance"), icon: CalendarCheck2 },
    { href: "/employees", label: t("nav.employees"), icon: Users },
    { href: "/students", label: t("nav.students"), icon: GraduationCap },
    { href: "/reports", label: t("nav.reports"), icon: BarChart3 },
    { href: "/settings", label: t("nav.settings"), icon: Settings },
  ];
}

function Logo() {
  return (
    <Link href="/" className="group flex items-center gap-3">
      <img
        src="/icons/icon-192.png"
        alt="Rosterly"
        className="size-11 rounded-2xl shadow-[0_8px_30px_-8px_var(--acc-glow)] transition-transform duration-500 group-hover:rotate-6"
      />
      <div>
        <p className="font-hindi text-2xl leading-tight text-stone-100">हाज़िरी</p>
        <p className="text-[10px] font-semibold uppercase tracking-[0.28em] text-stone-500">
          Rosterly · Attendance
        </p>
      </div>
    </Link>
  );
}

export function Sidebar() {
  const pathname = usePathname();
  const t = useT();
  const today = friendlyDate(todayStr());
  const NAV = navItems(t);

  return (
    <aside className="fixed inset-y-0 left-0 z-30 hidden w-[264px] flex-col border-r border-white/[0.05] bg-ink-900/60 px-5 py-8 backdrop-blur-xl lg:flex">
      <div className="px-2">
        <Logo />
      </div>

      <nav className="mt-12 flex flex-1 flex-col gap-1.5">
        <p className="mb-2 px-3 text-[10px] font-semibold uppercase tracking-[0.3em] text-stone-600">
          {t("nav.menu")}
        </p>
        {NAV.map((item) => {
          const active =
            item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "group relative flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-medium transition-all duration-300",
                active
                  ? "bg-white/[0.06] text-acc-300"
                  : "text-stone-400 hover:bg-white/[0.03] hover:text-stone-200",
              )}
            >
              <span
                className={cn(
                  "absolute left-0 top-1/2 h-6 w-1 -translate-y-1/2 rounded-full bg-gradient-to-b from-acc-400 to-acc-500 transition-all duration-300",
                  active ? "opacity-100 scale-100" : "opacity-0 scale-50",
                )}
              />
              <item.icon
                className={cn(
                  "size-[18px] transition-transform duration-300 group-hover:-rotate-6",
                  active ? "text-acc-400" : "text-stone-500",
                )}
                strokeWidth={2.2}
              />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="rounded-3xl border border-white/[0.06] bg-white/[0.02] p-5">
        <p className="text-[10px] font-semibold uppercase tracking-[0.3em] text-stone-600">
          {t("nav.aajKaDin")}
        </p>
        <p className="mt-2 font-display text-lg font-semibold leading-snug text-stone-100">
          {today}
        </p>
        <p className="mt-3 font-hindi text-sm text-acc-300/90">{t("nav.quote")}</p>
      </div>
    </aside>
  );
}

export function MobileNav() {
  const pathname = usePathname();
  const t = useT();
  const NAV = navItems(t);
  return (
    <header className="fixed inset-x-0 top-0 z-30 border-b border-white/[0.05] bg-ink-950/80 backdrop-blur-xl lg:hidden">
      <div className="flex items-center justify-between gap-2 px-4 py-3">
        <Logo />
        <nav className="flex items-center gap-1">
          {NAV.map((item) => {
            const active =
              item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                aria-label={item.label}
                className={cn(
                  "grid size-10 place-items-center rounded-xl transition-colors",
                  active
                    ? "bg-acc-400/15 text-acc-300"
                    : "text-stone-500 hover:bg-white/[0.04] hover:text-stone-300",
                )}
              >
                <item.icon className="size-[18px]" strokeWidth={2.2} />
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
