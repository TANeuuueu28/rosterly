import { NextRequest, NextResponse } from "next/server";
import { googleConfigured } from "@/lib/auth";

/** Kick off Google OAuth (enabled automatically when credentials exist). */
export async function GET(req: NextRequest) {
  if (!googleConfigured()) {
    return NextResponse.redirect(new URL("/login?error=google_not_configured", req.url));
  }
  const redirectUri = new URL("/api/auth/google/callback", req.nextUrl.origin).toString();
  const params = new URLSearchParams({
    client_id: process.env.GOOGLE_CLIENT_ID!,
    redirect_uri: redirectUri,
    response_type: "code",
    scope: "openid email profile",
    access_type: "online",
    prompt: "select_account",
  });
  return NextResponse.redirect(
    `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`,
  );
}
