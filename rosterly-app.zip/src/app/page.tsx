import { redirect } from "next/navigation";
import { and, asc, eq, gte, inArray } from "drizzle-orm";
import { db } from "@/db";
import { attendance, groups, holidays, members } from "@/db/schema";
import { getViewer } from "@/lib/session-user";
import { todayStr } from "@/lib/dates";
import { GroupsDashboard, type GroupCard } from "@/components/groups-dashboard";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const viewer = await getViewer();
  if (!viewer) redirect("/login");

  const [rows, upcoming] = await Promise.all([
    db
      .select()
      .from(groups)
      .where(eq(groups.userId, viewer.id))
      .orderBy(asc(groups.createdAt)),
    db
      .select()
      .from(holidays)
      .where(and(eq(holidays.userId, viewer.id), gte(holidays.date, todayStr())))
      .limit(5),
  ]);

  const groupIds = rows.map((g) => g.id);
  const today = todayStr();

  const memberRows = groupIds.length
    ? await db
        .select({ id: members.id, groupId: members.groupId })
        .from(members)
        .where(inArray(members.groupId, groupIds))
    : [];

  const memberIds = memberRows.map((m) => m.id);
  const todayRows = memberIds.length
    ? await db
        .select({ memberId: attendance.memberId, status: attendance.status })
        .from(attendance)
        .where(and(inArray(attendance.memberId, memberIds), eq(attendance.date, today)))
    : [];

  const statusByMember = new Map(todayRows.map((r) => [r.memberId, r.status]));
  const markedSet = new Set(statusByMember.keys());
  const todayStats = { members: memberIds.length, present: 0, absent: 0, leave: 0, half_day: 0 };
  for (const s of statusByMember.values()) todayStats[s] += 1;
  const marked = markedSet.size;

  const counts = new Map<number, { total: number; marked: number }>();
  for (const m of memberRows) {
    const c = counts.get(m.groupId) ?? { total: 0, marked: 0 };
    c.total += 1;
    if (markedSet.has(m.id)) c.marked += 1;
    counts.set(m.groupId, c);
  }

  const cards: GroupCard[] = rows.map((g) => {
    const c = counts.get(g.id) ?? { total: 0, marked: 0 };
    return {
      id: g.id,
      name: g.name,
      kind: g.kind,
      orgName: g.orgName,
      icon: g.icon,
      color: g.color,
      memberLabel: g.memberLabel,
      total: c.total,
      markedToday: c.marked,
    };
  });

  return (
    <GroupsDashboard
      viewerName={viewer.name}
      groups={cards}
      todayStats={{ ...todayStats, marked }}
      upcomingHolidays={upcoming.map((h) => ({ date: h.date, name: h.name }))}
    />
  );
}
