import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    id: "/",
    name: "Rosterly — Attendance for every workplace",
    short_name: "Rosterly",
    description:
      "Create attendance tables for any office, school, gym or team. Mark daily attendance, track reports. Created by Tanuj.",
    start_url: "/",
    scope: "/",
    display: "standalone",
    background_color: "#0b0906",
    theme_color: "#0b0906",
    orientation: "portrait",
    categories: ["productivity", "business", "education"],
    lang: "hi",
    icons: [
      {
        src: "/icons/icon-192.png",
        sizes: "192x192",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/icons/icon-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/icons/icon-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "maskable",
      },
    ],
  };
}
