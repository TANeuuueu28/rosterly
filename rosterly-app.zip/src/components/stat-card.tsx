"use client";

import { useEffect, useState } from "react";
import { animate, motion } from "framer-motion";
import {
  CalendarOff,
  CircleDashed,
  Clock3,
  UserCheck,
  UserX,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/ui";

const ICONS: Record<string, LucideIcon> = {
  "user-check": UserCheck,
  "user-x": UserX,
  "calendar-off": CalendarOff,
  "circle-dashed": CircleDashed,
  "clock-3": Clock3,
};

export type StatIcon = keyof typeof ICONS;

export function StatCard({
  label,
  labelHi,
  value,
  suffix,
  icon,
  accent,
  sub,
  delay = 0,
}: {
  label: string;
  labelHi: string;
  value: number;
  suffix?: string;
  icon: StatIcon;
  accent: "emerald" | "rose" | "violet" | "amber" | "sky";
  sub: string;
  delay?: number;
}) {
  const Icon = ICONS[icon] ?? CircleDashed;
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    const controls = animate(0, value, {
      duration: 1.1,
      delay,
      ease: [0.22, 1, 0.36, 1],
      onUpdate: (v) => setDisplay(Math.round(v)),
    });
    return () => controls.stop();
  }, [value, delay]);

  const accents = {
    emerald: "text-emerald-300 bg-emerald-400/10 ring-emerald-400/25",
    rose: "text-rose-300 bg-rose-400/10 ring-rose-400/25",
    violet: "text-violet-300 bg-violet-400/10 ring-violet-400/25",
    amber: "text-acc-300 bg-acc-400/10 ring-acc-400/25",
    sky: "text-sky-300 bg-sky-400/10 ring-sky-400/25",
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] }}
      className="group rounded-3xl border border-white/[0.06] bg-white/[0.02] p-5 backdrop-blur-sm transition-all duration-500 hover:-translate-y-1 hover:border-white/[0.12] hover:bg-white/[0.04]"
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-stone-500">
            {label}
          </p>
          <p className="font-hindi mt-0.5 text-xs text-stone-600">{labelHi}</p>
        </div>
        <div className={cn("grid size-10 place-items-center rounded-2xl ring-1", accents[accent])}>
          <Icon className="size-[18px]" strokeWidth={2.2} />
        </div>
      </div>
      <p className="font-display mt-4 text-4xl font-bold tracking-tight text-stone-50 tabular-nums">
        {display}
        {suffix && <span className="ml-0.5 text-xl text-stone-500">{suffix}</span>}
      </p>
      <p className="mt-1.5 text-xs text-stone-500">{sub}</p>
    </motion.div>
  );
}
