import { redirect } from "next/navigation";
import { and, asc, eq, gte, inArray, lte } from "drizzle-orm";
import { db } from "@/db";
import { attendance, groups, holidays, members } from "@/db/schema";
import { getViewer } from "@/lib/session-user";
import { monthEnd, monthOf, monthStart, todayStr } from "@/lib/dates";
import { CalendarView, type CalendarDayData } from "@/components/calendar-view";

export const dynamic = "force-dynamic";

export default async function CalendarPage({
  searchParams,
}: {
  searchParams: Promise<{ month?: string; g?: string }>;
}) {
  const viewer = await getViewer();
  if (!viewer) redirect("/login");

  const sp = await searchParams;
  const today = todayStr();
  const month = sp.month && /^\d{4}-\d{2}$/.test(sp.month) ? sp.month : monthOf(today);
  const from = monthStart(month);
  const to = monthEnd(month) > today ? today : monthEnd(month);

  const allGroups = await db
    .select()
    .from(groups)
    .where(eq(groups.userId, viewer.id))
    .orderBy(asc(groups.createdAt));

  const selected =
    allGroups.find((g) => String(g.id) === sp.g)?.id ?? allGroups[0]?.id ?? null;

  const people = selected
    ? await db
        .select()
        .from(members)
        .where(eq(members.groupId, selected))
        .orderBy(asc(members.name))
    : [];

  const ids = people.map((p) => p.id);
  const rows = ids.length
    ? await db
        .select()
        .from(attendance)
        .where(
          and(inArray(attendance.memberId, ids), gte(attendance.date, from), lte(attendance.date, to)),
        )
    : [];

  const userHolidays = await db
    .select()
    .from(holidays)
    .where(and(eq(holidays.userId, viewer.id), gte(holidays.date, from), lte(holidays.date, to)));

  const holidayMap = new Map(userHolidays.map((h) => [h.date, h.id]));

  const byMember = new Map<number, typeof people[0] & { name: string }>();
  for (const p of people) byMember.set(p.id, p);

  const dayMap = new Map<string, CalendarDayData>();
  for (const r of rows) {
    const d =
      dayMap.get(r.date) ??
      { date: r.date, present: 0, absent: 0, leave: 0, half_day: 0, holidayId: holidayMap.get(r.date) ?? null, items: [] };
    d[r.status] += 1;
    const p = byMember.get(r.memberId);
    if (p) d.items.push({ name: p.name, photoUrl: p.photoUrl, color: p.color, status: r.status, note: r.note });
    dayMap.set(r.date, d);
  }

  return (
    <CalendarView
      month={month}
      today={today}
      days={[...dayMap.values()]}
      holidays={userHolidays.map((h) => ({ id: h.id, date: h.date, name: h.name }))}
      groupName={allGroups[0] ? allGroups.find((g) => g.id === selected)?.name ?? "" : ""}
      groups={allGroups.map((g) => ({ id: g.id, name: g.name, icon: g.icon }))}
      selectedGroupId={selected}
      memberCount={people.length}
    />
  );
}
