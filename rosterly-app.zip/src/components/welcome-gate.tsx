"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, Check, Globe, Volume2, VolumeX } from "lucide-react";
import { LANGS, greetKey, langMeta, tr, type Lang } from "@/lib/i18n";
import { speak, useApp } from "@/components/providers";
import { cn } from "@/lib/ui";

const SEEN_KEY = "haziri-welcome-v3";

export function WelcomeGate({
  viewerName,
  loggedIn,
}: {
  viewerName: string | null;
  loggedIn: boolean;
}) {
  const router = useRouter();
  const { lang, setLang } = useApp();
  const [stage, setStage] = useState<"boot" | "hello" | "language" | "done">("boot");
  const [muted, setMuted] = useState(false);
  const spokenFor = useRef<string>("");

  useEffect(() => {
    let seen = false;
    try {
      seen = Boolean(sessionStorage.getItem(SEEN_KEY));
    } catch {}
    setStage(seen ? "done" : "hello");
  }, []);

  // Speak the welcome line, then slide to the language picker
  useEffect(() => {
    if (stage !== "hello") return;
    const line = viewerName
      ? `${tr(lang, greetKey(new Date().getHours()))}, ${viewerName}`
      : tr(lang, "welcome.spoken");
    if (!muted && spokenFor.current !== line) {
      spokenFor.current = line;
      // voices load async on first visit
      const t = setTimeout(() => speak(line, lang), 450);
      const id = setTimeout(() => setStage("language"), 2600);
      return () => {
        clearTimeout(t);
        clearTimeout(id);
      };
    }
    const id = setTimeout(() => setStage("language"), 2000);
    return () => clearTimeout(id);
  }, [stage, lang, viewerName, muted]);

  function pick(l: Lang) {
    setLang(l);
    if (!muted) speak(tr(l, "welcome.spoken"), l);
  }

  async function finish() {
    try {
      sessionStorage.setItem(SEEN_KEY, "1");
    } catch {}
    try {
      window.speechSynthesis?.cancel();
    } catch {}
    setStage("done");
    if (loggedIn) {
      await fetch("/api/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ language: lang }),
      }).catch(() => {});
      router.refresh();
    }
  }

  const greeting = viewerName
    ? `${tr(lang, greetKey(new Date().getHours()))}, ${viewerName}!`
    : tr(lang, "auth.welcome");

  return (
    <AnimatePresence>
      {(stage === "hello" || stage === "language") && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.45 } }}
          className="fixed inset-0 z-[90] flex flex-col items-center justify-center overflow-y-auto bg-ink-950/97 p-5 backdrop-blur-2xl"
        >
          {/* mute toggle */}
          <button
            onClick={() => {
              setMuted((m) => !m);
              try {
                window.speechSynthesis?.cancel();
              } catch {}
            }}
            aria-label="Toggle welcome sound"
            className="absolute right-5 top-5 grid size-10 place-items-center rounded-2xl border border-white/[0.08] text-stone-400 transition-colors hover:text-stone-100"
          >
            {muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
          </button>

          <AnimatePresence mode="wait">
            {stage === "hello" ? (
              <motion.div
                key="hello"
                initial={{ opacity: 0, scale: 0.92, y: 18 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 1.04, y: -14 }}
                transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
                className="flex flex-col items-center text-center"
              >
                <motion.img
                  src="/icons/icon-512.png"
                  alt="Rosterly"
                  className="size-28 rounded-[26%] shadow-[0_24px_70px_-18px_var(--acc-glow)]"
                  initial={{ rotate: -10, scale: 0.8 }}
                  animate={{ rotate: 0, scale: 1 }}
                  transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
                />
                <motion.p
                  initial={{ opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3, duration: 0.6 }}
                  className="font-display mt-8 bg-gradient-to-r from-acc-300 via-acc-500 to-acc-300 bg-clip-text text-5xl font-bold tracking-tight text-transparent sm:text-6xl"
                >
                  Rosterly
                </motion.p>
                <motion.p
                  initial={{ opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5, duration: 0.6 }}
                  className="font-display mt-5 text-xl font-semibold text-stone-100 sm:text-2xl"
                >
                  {greeting}
                </motion.p>
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.75, duration: 0.6 }}
                  className="mt-2 text-sm text-stone-500"
                >
                  {tr(lang, "app.tagline")}
                </motion.p>
              </motion.div>
            ) : (
              <motion.div
                key="language"
                initial={{ opacity: 0, y: 24 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
                className="w-full max-w-lg"
              >
                <div className="text-center">
                  <span className="inline-flex items-center gap-2 rounded-full border border-white/[0.08] bg-white/[0.03] px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.2em] text-acc-300">
                    <Globe className="size-3.5" />
                    {tr(lang, "set.language")}
                  </span>
                  <h2 className="font-display mt-4 text-3xl font-bold tracking-tight text-stone-50">
                    {tr(lang, "welcome.pick")}
                  </h2>
                  <p className="mt-1.5 text-sm text-stone-500">{tr(lang, "welcome.pickSub")}</p>
                </div>

                <div className="mt-7 grid max-h-[46vh] grid-cols-2 gap-2 overflow-y-auto pr-1 sm:grid-cols-3">
                  {LANGS.map((l) => (
                    <button
                      key={l.id}
                      onClick={() => pick(l.id)}
                      dir={l.dir}
                      className={cn(
                        "relative flex items-center gap-2.5 rounded-2xl border px-3.5 py-3 text-start transition-all duration-200",
                        lang === l.id
                          ? "border-acc-400/50 bg-acc-400/10"
                          : "border-white/[0.07] hover:border-white/[0.16] hover:bg-white/[0.03]",
                      )}
                    >
                      <span className="text-lg leading-none">{l.flag}</span>
                      <span className="min-w-0 flex-1">
                        <span
                          className={cn(
                            "block truncate text-sm font-semibold",
                            lang === l.id ? "text-acc-200" : "text-stone-200",
                          )}
                        >
                          {l.native}
                        </span>
                        <span className="block truncate text-[10px] text-stone-500">
                          {l.english}
                        </span>
                      </span>
                      {lang === l.id && (
                        <Check className="size-4 shrink-0 text-acc-300" strokeWidth={3} />
                      )}
                    </button>
                  ))}
                </div>

                <button
                  onClick={finish}
                  className="group mt-7 inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-br from-acc-400 to-acc-500 px-6 py-3.5 text-sm font-bold text-ink-950 shadow-[0_18px_44px_-14px_var(--acc-glow)] transition-transform hover:-translate-y-0.5"
                >
                  {tr(lang, "welcome.continue")}
                  <ArrowRight
                    className="size-4 transition-transform group-hover:translate-x-1 rtl:rotate-180"
                    strokeWidth={2.6}
                  />
                </button>
                <p className="mt-4 text-center text-[11px] text-stone-600">
                  {tr(lang, "app.credit")}
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
