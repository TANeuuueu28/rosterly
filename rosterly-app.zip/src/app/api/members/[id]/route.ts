import { NextRequest, NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { groups, members } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

type Ctx = { params: Promise<{ id: string }> };
const MAX_PHOTO = 1_500_000;

/** Make sure this member belongs to a group owned by the current user. */
async function ownsMember(userId: number, memberId: number): Promise<boolean> {
  const rows = await db
    .select({ id: members.id })
    .from(members)
    .innerJoin(groups, eq(groups.id, members.groupId))
    .where(and(eq(members.id, memberId), eq(groups.userId, userId)))
    .limit(1);
  return rows.length > 0;
}

export async function PATCH(req: NextRequest, ctx: Ctx) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await ctx.params;
  const memberId = Number(id);
  if (!Number.isFinite(memberId) || !(await ownsMember(user.id, memberId))) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  try {
    const body = await req.json();
    const patch: Partial<typeof members.$inferInsert> = {};
    if (body.name !== undefined) patch.name = String(body.name).trim().slice(0, 120);
    if (body.identifier !== undefined)
      patch.identifier = body.identifier ? String(body.identifier).trim().slice(0, 40) : null;
    if (body.role !== undefined)
      patch.role = body.role ? String(body.role).trim().slice(0, 120) : null;
    if (body.phone !== undefined)
      patch.phone = body.phone ? String(body.phone).trim().slice(0, 24) : null;
    if (body.email !== undefined)
      patch.email = body.email ? String(body.email).trim().slice(0, 200) : null;
    if (body.color !== undefined) patch.color = String(body.color).slice(0, 16);
    if (body.joinDate !== undefined) patch.joinDate = body.joinDate ? String(body.joinDate) : null;
    if (body.photoUrl !== undefined) {
      const photo = typeof body.photoUrl === "string" ? body.photoUrl : null;
      if (photo && photo.length > MAX_PHOTO) {
        return NextResponse.json({ error: "Photo too large" }, { status: 413 });
      }
      patch.photoUrl = photo;
    }

    const [updated] = await db
      .update(members)
      .set(patch)
      .where(eq(members.id, memberId))
      .returning();
    return NextResponse.json({ member: updated });
  } catch {
    return NextResponse.json({ error: "Could not update" }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await ctx.params;
  const memberId = Number(id);
  if (!Number.isFinite(memberId) || !(await ownsMember(user.id, memberId))) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  await db.delete(members).where(eq(members.id, memberId));
  return NextResponse.json({ ok: true });
}
