"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  CalendarDays,
  CalendarPlus,
  ChevronLeft,
  ChevronRight,
  PartyPopper,
  Trash2,
  X,
} from "lucide-react";
import { Avatar } from "@/components/avatar";
import { StatusPill } from "@/components/ui";
import { STATUS_META, cn } from "@/lib/ui";
import { addDays, daysInMonth, friendlyDate, isWeekend, monthLabel, parseDate, shiftMonth, todayStr, weekdayOf } from "@/lib/dates";
import type { AttendanceStatus } from "@/db/schema";

export type CalendarDayData = {
  date: string;
  present: number;
  absent: number;
  leave: number;
  half_day: number;
  holidayId: number | null;
  items: {
    name: string;
    photoUrl: string | null;
    color: string;
    status: AttendanceStatus;
    note: string | null;
  }[];
};

type Holiday = { id: number; date: string; name: string };

const WEEK = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export function CalendarView({
  month,
  today,
  days,
  holidays,
  groups,
  selectedGroupId,
  memberCount,
}: {
  month: string;
  today: string;
  days: CalendarDayData[];
  holidays: Holiday[];
  groupName: string;
  groups: { id: number; name: string; icon: string }[];
  selectedGroupId: number | null;
  memberCount: number;
}) {
  const router = useRouter();
  const [, startNav] = useTransition();
  const [selectedDay, setSelectedDay] = useState<string | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [holName, setHolName] = useState("");
  const [holDate, setHolDate] = useState(today);
  const [busy, setBusy] = useState(false);

  const dayMap = new Map(days.map((d) => [d.date, d]));
  const holidayMap = new Map(holidays.map((h) => [h.date, h]));

  function go(m: string) {
    startNav(() =>
      router.push(
        `/calendar?month=${m}${selectedGroupId ? `&g=${selectedGroupId}` : ""}`,
      ),
    );
  }

  async function addHoliday() {
    if (!holName.trim() || !holDate) return;
    setBusy(true);
    try {
      await fetch("/api/holidays", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date: holDate, name: holName.trim() }),
      });
      setAddOpen(false);
      setHolName("");
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  async function removeHoliday(date: string) {
    await fetch(`/api/holidays?date=${date}`, { method: "DELETE" });
    router.refresh();
  }

  const dim = daysInMonth(month);
  const firstWeekday = parseDate(`${month}-01`).getDay();
  const cells: (string | null)[] = [
    ...Array.from({ length: firstWeekday }, () => null),
    ...Array.from({ length: dim }, (_, i) => `${month}-${String(i + 1).padStart(2, "0")}`),
  ];
  while (cells.length % 7 !== 0) cells.push(null);

  const sel = selectedDay
    ? {
        date: selectedDay,
        data: dayMap.get(selectedDay) ?? null,
        holiday: holidayMap.get(selectedDay) ?? null,
      }
    : null;

  const monthTotals = days.reduce(
    (a, d) => ({
      present: a.present + d.present,
      absent: a.absent + d.absent,
      leave: a.leave + d.leave,
      half_day: a.half_day + d.half_day,
      markedDays: a.markedDays + (d.present + d.absent + d.leave + d.half_day > 0 ? 1 : 0),
    }),
    { present: 0, absent: 0, leave: 0, half_day: 0, markedDays: 0 },
  );

  return (
    <div className="space-y-6">
      {/* header */}
      <header className="animate-fade-up flex flex-wrap items-end justify-between gap-5">
        <div>
          <p className="inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.25em] text-acc-300/90">
            <CalendarDays className="size-3.5" /> Attendance Calendar
          </p>
          <h1 className="font-display mt-3 text-4xl font-bold tracking-tight text-stone-50 sm:text-5xl">
            {monthLabel(month)}
          </h1>
          <p className="mt-1.5 text-sm text-stone-500">
            {monthTotals.markedDays} working day{monthTotals.markedDays === 1 ? "" : "s"} marked ·{" "}
            {holidays.length} holiday{holidays.length === 1 ? "" : "s"} · {memberCount}{" "}
            {selectedGroupId ? "people" : ""}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 rounded-2xl border border-white/[0.06] bg-white/[0.02] p-1.5">
            <button
              onClick={() => go(shiftMonth(month, -1))}
              aria-label="Previous month"
              className="grid size-9 place-items-center rounded-xl text-stone-400 hover:bg-white/[0.05] hover:text-stone-100"
            >
              <ChevronLeft className="size-4 rtl:rotate-180" />
            </button>
            <input
              type="month"
              value={month}
              max={todayStr().slice(0, 7)}
              onChange={(e) => e.target.value && go(e.target.value)}
              className="w-[128px] rounded-xl bg-transparent px-2 py-1.5 font-mono text-xs text-stone-200 outline-none"
            />
            <button
              onClick={() => go(shiftMonth(month, 1))}
              disabled={shiftMonth(month, 1) > today.slice(0, 7)}
              aria-label="Next month"
              className="grid size-9 place-items-center rounded-xl text-stone-400 hover:bg-white/[0.05] hover:text-stone-100 disabled:opacity-30"
            >
              <ChevronRight className="size-4 rtl:rotate-180" />
            </button>
          </div>
          <button
            onClick={() => setAddOpen(true)}
            className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-br from-acc-400 to-acc-500 px-4 py-3 text-xs font-bold text-ink-950 shadow-[0_12px_30px_-10px_var(--acc-glow)] transition-transform hover:-translate-y-0.5"
          >
            <CalendarPlus className="size-4" strokeWidth={2.4} /> Add holiday
          </button>
        </div>
      </header>

      {/* group chips */}
      {groups.length > 1 && (
        <div className="flex flex-wrap gap-1.5">
          {groups.map((g) => (
            <button
              key={g.id}
              onClick={() =>
                startNav(() => router.push(`/calendar?month=${month}&g=${g.id}`))
              }
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-[11px] font-semibold transition-colors",
                selectedGroupId === g.id
                  ? "bg-acc-400/15 text-acc-300"
                  : "bg-white/[0.03] text-stone-500 hover:text-stone-300",
              )}
            >
              <span>{g.icon}</span> {g.name}
            </button>
          ))}
        </div>
      )}

      <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
        {/* calendar grid */}
        <div className="rounded-3xl border border-white/[0.06] bg-white/[0.02] p-4 sm:p-5">
          <div className="grid grid-cols-7 gap-1.5">
            {WEEK.map((w) => (
              <div
                key={w}
                className="pb-1 text-center text-[10px] font-semibold uppercase tracking-[0.15em] text-stone-600"
              >
                {w}
              </div>
            ))}
            {cells.map((date, i) =>
              !date ? (
                <div key={`b${i}`} />
              ) : (
                <DayCell
                  key={date}
                  date={date}
                  isToday={date === today}
                  weekend={isWeekend(date)}
                  future={date > today}
                  data={dayMap.get(date) ?? null}
                  holidayName={holidayMap.get(date)?.name ?? null}
                  selected={selectedDay === date}
                  onClick={() => setSelectedDay(selectedDay === date ? null : date)}
                />
              ),
            )}
          </div>
          {/* legend */}
          <div className="mt-4 flex flex-wrap items-center gap-3 border-t border-white/[0.05] pt-3.5 text-[10px] text-stone-500">
            {(["present", "absent", "leave", "half_day"] as const).map((k) => (
              <span key={k} className="inline-flex items-center gap-1.5">
                <span className="size-2 rounded-[3px]" style={{ background: STATUS_META[k].hex }} />
                {STATUS_META[k].label}
              </span>
            ))}
            <span className="inline-flex items-center gap-1.5">
              <PartyPopper className="size-3 text-acc-300" /> Holiday
            </span>
            <span className="ms-auto">Kisi din par click karke detail dekho →</span>
          </div>
        </div>

        {/* day panel */}
        <AnimatePresence mode="wait">
          {sel ? (
            <motion.aside
              key={sel.date}
              initial={{ opacity: 0, x: 16 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 16 }}
              transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="h-fit rounded-3xl border border-white/[0.06] bg-white/[0.02] p-5 lg:sticky lg:top-6"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-display text-base font-bold text-stone-50">
                    {friendlyDate(sel.date)}
                  </p>
                  <p className="text-[11px] text-stone-500">{weekdayOf(sel.date)} · {sel.data?.items.length ?? 0} marked</p>
                </div>
                <button
                  onClick={() => setSelectedDay(null)}
                  aria-label="Close"
                  className="grid size-8 place-items-center rounded-xl text-stone-500 hover:bg-white/[0.05] hover:text-stone-200"
                >
                  <X className="size-4" />
                </button>
              </div>

              {sel.holiday && (
                <div className="mt-3 flex items-center gap-2 rounded-2xl border border-acc-400/25 bg-acc-400/10 px-3.5 py-2.5">
                  <PartyPopper className="size-4 shrink-0 text-acc-300" />
                  <p className="min-w-0 flex-1 truncate text-xs font-bold text-acc-200">
                    {sel.holiday.name}
                  </p>
                  <button
                    onClick={() => removeHoliday(sel.date)}
                    aria-label="Delete holiday"
                    className="text-acc-300/60 hover:text-rose-300"
                  >
                    <Trash2 className="size-3.5" />
                  </button>
                </div>
              )}

              {sel.data && sel.data.items.length > 0 ? (
                <ul className="mt-3 max-h-[420px] space-y-2 overflow-y-auto pe-1">
                  {sel.data.items.map((it, idx) => (
                    <li
                      key={idx}
                      className="rounded-2xl bg-white/[0.03] px-3.5 py-2.5"
                    >
                      <div className="flex items-center gap-2.5">
                        <Avatar name={it.name} color={it.color} photoUrl={it.photoUrl} size="sm" />
                        <p className="min-w-0 flex-1 truncate text-xs font-semibold text-stone-200">
                          {it.name}
                        </p>
                        <StatusPill status={it.status} />
                      </div>
                      {it.note && (
                        <p className="mt-1.5 rounded-xl bg-white/[0.04] px-3 py-2 text-[11px] leading-relaxed text-stone-400">
                          <b className="text-stone-300">Reason:</b> {it.note}
                        </p>
                      )}
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="mt-4 rounded-2xl border border-dashed border-white/[0.09] px-4 py-6 text-center text-[11px] text-stone-500">
                  {sel.date > today
                    ? "Aane wala din — abhi kuch record nahi."
                    : sel.holiday
                      ? "Holiday hai — attendance off."
                      : "Is din koi mark nahi kiya gaya."}
                </p>
              )}
            </motion.aside>
          ) : (
            <motion.aside
              key="month-summary"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="rounded-3xl border border-white/[0.06] bg-white/[0.02] p-5 lg:sticky lg:top-6"
            >
              <p className="font-display text-base font-bold text-stone-50">
                {monthLabel(month)} summary
              </p>
              <div className="mt-3 space-y-2">
                {(["present", "absent", "leave", "half_day"] as const).map((k) => (
                  <div
                    key={k}
                    className="flex items-center justify-between rounded-2xl bg-white/[0.03] px-3.5 py-2.5 text-xs"
                  >
                    <span className="inline-flex items-center gap-2 text-stone-400">
                      <span className={cn("size-1.5 rounded-full", STATUS_META[k].dot)} />
                      {STATUS_META[k].label}
                    </span>
                    <span className="font-display text-sm font-bold text-stone-100 tabular-nums">
                      {monthTotals[k]}
                    </span>
                  </div>
                ))}
              </div>
              {holidays.length > 0 && (
                <div className="mt-4">
                  <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-stone-500">
                    Holidays this month
                  </p>
                  <ul className="mt-2 space-y-1.5">
                    {holidays.map((h) => (
                      <li
                        key={h.id}
                        className="flex items-center justify-between rounded-xl bg-acc-400/[0.07] px-3 py-2 text-[11px]"
                      >
                        <span className="inline-flex items-center gap-1.5 text-acc-200">
                          <PartyPopper className="size-3" />
                          {h.name}
                        </span>
                        <button
                          onClick={() => setSelectedDay(h.date)}
                          className="font-mono text-stone-400 hover:text-acc-300"
                        >
                          {h.date.slice(8)}
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              <p className="mt-4 text-[10px] leading-relaxed text-stone-600">
                Kisi bhi din par click karo — kaun aaya, kaun nahi, kiski kis wajah se chhutti thi,
                sab dikha dega.
              </p>
            </motion.aside>
          )}
        </AnimatePresence>
      </div>

      {/* add holiday modal */}
      <AnimatePresence>
        {addOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setAddOpen(false)}
            className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4 backdrop-blur-sm"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.94, y: 16 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-sm rounded-3xl border border-white/10 bg-ink-900 p-6"
            >
              <div className="flex items-center justify-between">
                <h2 className="font-display text-base font-bold text-stone-50">Add holiday</h2>
                <button
                  onClick={() => setAddOpen(false)}
                  aria-label="Close"
                  className="grid size-8 place-items-center rounded-xl text-stone-500 hover:text-stone-200"
                >
                  <X className="size-4" />
                </button>
              </div>
              <div className="mt-4 space-y-3">
                <input
                  autoFocus
                  value={holName}
                  onChange={(e) => setHolName(e.target.value)}
                  placeholder="Kaun si chhutti? e.g. Diwali / Foundation Day"
                  className="w-full rounded-xl border border-white/[0.08] bg-white/[0.03] px-3.5 py-2.5 text-sm text-stone-100 outline-none placeholder:text-stone-600 focus:border-acc-400/50"
                />
                <input
                  type="date"
                  value={holDate}
                  onChange={(e) => setHolDate(e.target.value)}
                  className="w-full rounded-xl border border-white/[0.08] bg-white/[0.03] px-3.5 py-2.5 text-sm text-stone-100 outline-none focus:border-acc-400/50"
                />
                <div className="flex flex-wrap gap-1.5">
                  {["New Year", "Republic Day", "Holi", "Independence Day", "Gandhi Jayanti", "Diwali", "Christmas"].map(
                    (q) => (
                      <button
                        key={q}
                        onClick={() => setHolName(q)}
                        className="rounded-full bg-white/[0.04] px-2.5 py-1 text-[10px] font-semibold text-stone-400 hover:bg-white/[0.08] hover:text-stone-200"
                      >
                        {q}
                      </button>
                    ),
                  )}
                </div>
              </div>
              <button
                onClick={addHoliday}
                disabled={busy || !holName.trim()}
                className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-acc-400 to-acc-500 py-3 text-sm font-bold text-ink-950 disabled:opacity-50"
              >
                <CalendarPlus className="size-4" /> Holiday add karo
              </button>
              <p className="mt-3 text-center text-[10px] text-stone-600">
                Holiday calendar par saari tables mein dikhega
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function DayCell({
  date,
  isToday,
  weekend,
  future,
  data,
  holidayName,
  selected,
  onClick,
}: {
  date: string;
  isToday: boolean;
  weekend: boolean;
  future: boolean;
  data: CalendarDayData | null;
  holidayName: string | null;
  selected: boolean;
  onClick: () => void;
}) {
  const dayNum = Number(date.slice(8));
  const total = data ? data.present + data.absent + data.leave + data.half_day : 0;
  const bar =
    data && total > 0
      ? [
          { v: data.present / total, c: STATUS_META.present.hex },
          { v: data.half_day / total, c: STATUS_META.half_day.hex },
          { v: data.leave / total, c: STATUS_META.leave.hex },
          { v: data.absent / total, c: STATUS_META.absent.hex },
        ]
      : null;

  return (
    <button
      onClick={onClick}
      className={cn(
        "group relative flex min-h-[64px] flex-col rounded-2xl border p-1.5 text-start transition-all duration-200 sm:min-h-[84px] sm:p-2",
        selected
          ? "border-acc-400/50 bg-acc-400/10"
          : "border-white/[0.05] bg-white/[0.02] hover:border-white/[0.14] hover:bg-white/[0.04]",
        isToday && !selected && "border-acc-300/40",
        future && "opacity-45",
      )}
    >
      <span className="flex items-center justify-between">
        <span
          className={cn(
            "font-mono text-[11px] font-semibold sm:text-xs",
            isToday ? "text-acc-300" : weekend ? "text-stone-600" : "text-stone-300",
          )}
        >
          {dayNum}
        </span>
        {total > 0 && (
          <span className="rounded-full bg-white/[0.07] px-1.5 text-[9px] font-bold text-stone-300 tabular-nums">
            {total}
          </span>
        )}
      </span>

      {holidayName && (
        <span className="mt-0.5 flex items-center gap-1 truncate rounded-md bg-acc-400/15 px-1 py-0.5 text-[8px] font-bold text-acc-200 sm:text-[9px]">
          <PartyPopper className="size-2.5 shrink-0" />
          <span className="truncate">{holidayName}</span>
        </span>
      )}

      <span className="mt-auto block h-1 overflow-hidden rounded-full bg-white/[0.05]">
        {bar && (
          <span className="flex h-full w-full">
            {bar.map((seg, i) =>
              seg.v > 0 ? (
                <span key={i} style={{ width: `${seg.v * 100}%`, background: seg.c }} />
              ) : null,
            )}
          </span>
        )}
      </span>
    </button>
  );
}
