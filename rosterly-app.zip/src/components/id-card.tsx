"use client";

import { useCallback, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { QRCodeCanvas } from "qrcode.react";
import { Download, Loader2, X } from "lucide-react";
import { Avatar } from "@/components/avatar";
import { AVATAR_COLORS, cn } from "@/lib/ui";

export type IdCardPerson = {
  id: number;
  name: string;
  identifier: string | null;
  role: string | null;
  phone: string | null;
  photoUrl: string | null;
  color: string;
};

export type IdCardGroup = { id: number; name: string; orgName: string | null; icon: string };

/** Draw text with an auto-shrinking fit. */
function fitText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxW: number,
  base: number,
  font: (px: number) => string,
) {
  let px = base;
  ctx.font = font(px);
  while (ctx.measureText(text).width > maxW && px > 10) {
    px -= 1;
    ctx.font = font(px);
  }
  ctx.fillText(text, x, y);
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

export function IdCardModal({
  person,
  group,
  onClose,
}: {
  person: IdCardPerson;
  group: IdCardGroup;
  onClose: () => void;
}) {
  const [downloading, setDownloading] = useState(false);
  const qrWrapRef = useRef<HTMLDivElement>(null);
  const c = AVATAR_COLORS[person.color] ?? AVATAR_COLORS.amber;

  const download = useCallback(async () => {
    setDownloading(true);
    try {
      const W = 720;
      const H = 1140;
      const canvas = document.createElement("canvas");
      canvas.width = W;
      canvas.height = H;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      // background
      const bg = ctx.createLinearGradient(0, 0, 0, H);
      bg.addColorStop(0, "#171310");
      bg.addColorStop(1, "#0b0906");
      ctx.fillStyle = bg;
      roundRect(ctx, 0, 0, W, H, 48);
      ctx.fill();

      // accent header
      const hg = ctx.createLinearGradient(0, 0, W, 0);
      hg.addColorStop(0, "#fbbf24");
      hg.addColorStop(1, "#f97316");
      ctx.fillStyle = hg;
      roundRect(ctx, 0, 0, W, 14, 7);
      ctx.fill();

      // logo + org
      const logo = new Image();
      await new Promise<void>((res) => {
        logo.onload = () => res();
        logo.onerror = () => res();
        logo.src = "/icons/icon-512.png";
      });
      if (logo.complete && logo.naturalWidth) {
        ctx.save();
        roundRect(ctx, 48, 56, 88, 88, 26);
        ctx.clip();
        ctx.drawImage(logo, 48, 56, 88, 88);
        ctx.restore();
      }
      ctx.fillStyle = "#fbbf24";
      ctx.font = "700 34px 'Space Grotesk', Arial, sans-serif";
      ctx.textBaseline = "middle";
      ctx.fillText("Rosterly", 160, 88);
      ctx.fillStyle = "#a8a29e";
      ctx.font = "600 22px Arial, sans-serif";
      ctx.fillText((group.orgName || group.name).slice(0, 40), 160, 124);

      // photo circle
      const cx0 = W / 2;
      ctx.beginPath();
      ctx.arc(cx0, 330, 130, 0, Math.PI * 2);
      ctx.fillStyle = "#26211a";
      ctx.fill();
      if (person.photoUrl) {
        const img = new Image();
        await new Promise<void>((res) => {
          img.onload = () => res();
          img.onerror = () => res();
          img.src = person.photoUrl!;
        });
        if (img.complete && img.naturalWidth) {
          ctx.save();
          ctx.beginPath();
          ctx.arc(cx0, 330, 126, 0, Math.PI * 2);
          ctx.clip();
          const side = Math.min(img.width, img.height);
          ctx.drawImage(
            img,
            (img.width - side) / 2,
            (img.height - side) / 2,
            side,
            side,
            cx0 - 126,
            204,
            252,
            252,
          );
          ctx.restore();
        }
      } else {
        ctx.fillStyle = "#fcd34d";
        ctx.textAlign = "center";
        ctx.font = "700 88px 'Space Grotesk', Arial, sans-serif";
        ctx.fillText(
          person.name
            .split(" ")
            .filter(Boolean)
            .slice(0, 2)
            .map((p) => p[0]?.toUpperCase())
            .join(""),
          cx0,
          330,
        );
        ctx.textAlign = "start";
      }
      ctx.beginPath();
      ctx.arc(cx0, 330, 130, 0, Math.PI * 2);
      ctx.strokeStyle = "rgba(251,191,36,.6)";
      ctx.lineWidth = 4;
      ctx.stroke();

      // name + role
      ctx.fillStyle = "#fafaf9";
      fitText(ctx, person.name, 48, 540, W - 96, 54, (p) => `700 ${p}px 'Space Grotesk', Arial`);
      ctx.fillStyle = "#d6d3d1";
      ctx.font = "500 28px Arial, sans-serif";
      const roleLine = [person.role, group.name].filter(Boolean).join(" · ");
      fitText(ctx, roleLine || "Member", 48, 594, W - 96, 28, (p) => `500 ${p}px Arial`);

      // info card
      ctx.fillStyle = "rgba(255,255,255,0.04)";
      roundRect(ctx, 48, 650, W - 96, 210, 28);
      ctx.fill();
      const rows: Array<[string, string]> = [
        ["ID", person.identifier || `RST-${String(person.id).padStart(4, "0")}`],
        ["Phone", person.phone || "—"],
        ["Group", group.icon + " " + group.name],
      ];
      rows.forEach(([k, v], i) => {
        const y = 700 + i * 58;
        ctx.fillStyle = "#78716c";
        ctx.font = "700 18px Arial";
        ctx.fillText(k.toUpperCase(), 80, y);
        ctx.fillStyle = "#e7e5e4";
        ctx.font = "600 26px Arial";
        fitText(ctx, v, 200, y, W - 96 - 160, 26, (p) => `600 ${p}px Arial`);
      });

      // QR
      const qrCanvas = qrWrapRef.current?.querySelector("canvas");
      if (qrCanvas) {
        const qs = 180;
        ctx.fillStyle = "#ffffff";
        roundRect(ctx, W - 48 - qs - 0, 900, qs + 24, qs + 24, 22);
        ctx.fill();
        ctx.drawImage(qrCanvas, W - 48 - qs + 12, 912, qs, qs);
      }
      ctx.fillStyle = "#a8a29e";
      ctx.font = "500 20px Arial";
      ctx.fillText("Scan to verify membership", 60, 990);
      ctx.fillStyle = "#57534e";
      ctx.font = "600 18px Arial";
      ctx.fillText("Rosterly · Created by Tanuj", 60, 1030);

      // download
      const url = canvas.toDataURL("image/png");
      const a = document.createElement("a");
      a.href = url;
      a.download = `${person.name.replace(/\s+/g, "-").toLowerCase()}-id-card.png`;
      a.click();
    } finally {
      setDownloading(false);
    }
  }, [person, group]);

  const qrValue =
    typeof window !== "undefined"
      ? `${window.location.origin}/t/${group.id}?tab=people&member=${person.id}`
      : `rosterly://member/${person.id}`;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
      className="fixed inset-0 z-50 grid place-items-center overflow-y-auto bg-black/75 p-4 backdrop-blur-sm"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.93, y: 18 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.93, y: 18 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-[360px]"
      >
        {/* card preview */}
        <div className="overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-b from-ink-800 to-ink-950 shadow-2xl">
          <div className="h-1 bg-gradient-to-r from-acc-400 to-acc-500" />
          <div className="flex items-center gap-2.5 px-5 pt-4">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/icons/icon-512.png" alt="" className="size-8 rounded-lg" />
            <div className="min-w-0 flex-1">
              <p className="font-display text-sm font-bold text-acc-300">Rosterly</p>
              <p className="truncate text-[10px] text-stone-500">
                {group.orgName || group.name}
              </p>
            </div>
          </div>
          <div className="flex flex-col items-center px-5 pt-4">
            {person.photoUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={person.photoUrl}
                alt=""
                className="size-28 rounded-full object-cover ring-2 ring-acc-300/50"
              />
            ) : (
              <div
                className={cn(
                  "grid size-28 place-items-center rounded-full text-3xl font-bold ring-2 ring-acc-300/50",
                  c.bg,
                  c.text,
                )}
              >
                {person.name
                  .split(" ")
                  .filter(Boolean)
                  .slice(0, 2)
                  .map((p) => p[0]?.toUpperCase())
                  .join("")}
              </div>
            )}
            <p className="font-display mt-3 max-w-full truncate text-lg font-bold text-stone-50">
              {person.name}
            </p>
            <p className="mt-0.5 text-[11px] text-stone-400">
              {[person.role, group.name].filter(Boolean).join(" · ") || "Member"}
            </p>
          </div>
          <div className="mx-5 mt-4 space-y-1.5 rounded-2xl bg-white/[0.04] px-4 py-3 text-[11px]">
            <div className="flex justify-between">
              <span className="text-stone-500">ID</span>
              <span className="font-mono font-semibold text-stone-200">
                {person.identifier || `RST-${String(person.id).padStart(4, "0")}`}
              </span>
            </div>
            {person.phone && (
              <div className="flex justify-between">
                <span className="text-stone-500">Phone</span>
                <span className="font-mono text-stone-200">{person.phone}</span>
              </div>
            )}
          </div>
          <div className="mt-4 flex items-end justify-between gap-3 px-5 pb-5">
            <div>
              <p className="text-[9px] leading-relaxed text-stone-600">
                Scan to verify
                <br />
                membership
              </p>
              <p className="mt-1 text-[9px] font-semibold text-stone-700">
                Rosterly · by Tanuj
              </p>
            </div>
            <div ref={qrWrapRef} className="rounded-xl bg-white p-1.5">
              <QRCodeCanvas value={qrValue} size={84} level="M" marginSize={0} />
            </div>
          </div>
        </div>

        <div className="mt-3 flex gap-2">
          <button
            onClick={download}
            disabled={downloading}
            className="inline-flex flex-1 items-center justify-center gap-2 rounded-2xl bg-gradient-to-br from-acc-400 to-acc-500 py-3 text-xs font-bold text-ink-950"
          >
            {downloading ? (
              <Loader2 className="size-3.5 animate-spin" />
            ) : (
              <Download className="size-3.5" strokeWidth={2.6} />
            )}
            Download PNG card
          </button>
          <button
            onClick={onClose}
            className="grid size-12 shrink-0 place-items-center rounded-2xl border border-white/10 bg-white/[0.04] text-stone-300"
            aria-label="Close"
          >
            <X className="size-4" />
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}
