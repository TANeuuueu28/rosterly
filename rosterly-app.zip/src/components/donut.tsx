import { STATUS_META } from "@/lib/ui";
import type { AttendanceStatus } from "@/db/schema";

type Counts = Record<AttendanceStatus, number> & { unmarked: number };

const UNMARKED_COLOR = "#3a342b";

export function AttendanceDonut({
  counts,
  size = 190,
  stroke = 16,
}: {
  counts: Counts;
  size?: number;
  stroke?: number;
}) {
  const total = Math.max(
    counts.present + counts.absent + counts.leave + counts.half_day + counts.unmarked,
    1,
  );
  const r = (size - stroke) / 2;
  const C = 2 * Math.PI * r;

  const segments: Array<{ color: string; value: number }> = [
    { color: STATUS_META.present.hex, value: counts.present },
    { color: STATUS_META.half_day.hex, value: counts.half_day },
    { color: STATUS_META.leave.hex, value: counts.leave },
    { color: STATUS_META.absent.hex, value: counts.absent },
    { color: UNMARKED_COLOR, value: counts.unmarked },
  ];

  let offset = 0;
  const effectiveScore = counts.present + counts.half_day * 0.5;
  const markedTotal = total - counts.unmarked;
  const pct = markedTotal > 0 ? Math.round((effectiveScore / markedTotal) * 100) : 0;

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          strokeWidth={stroke}
          className="stroke-white/[0.04]"
        />
        {segments.map((seg, i) => {
          const len = (seg.value / total) * C;
          const dash = `${Math.max(len - 2, 0)} ${C - Math.max(len - 2, 0)}`;
          const el = (
            <circle
              key={i}
              cx={size / 2}
              cy={size / 2}
              r={r}
              fill="none"
              stroke={seg.color}
              strokeWidth={stroke}
              strokeLinecap="round"
              strokeDasharray={dash}
              strokeDashoffset={-offset}
              className="transition-all duration-700"
            />
          );
          offset += len;
          return el;
        })}
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <p className="font-display text-4xl font-bold tracking-tight text-stone-50 tabular-nums">
          {pct}
          <span className="text-lg text-stone-500">%</span>
        </p>
        <p className="text-[10px] font-semibold uppercase tracking-[0.25em] text-stone-500">
          Rosterly
        </p>
      </div>
    </div>
  );
}
