"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  KeyRound,
  Laptop,
  Loader2,
  Mail,
  MonitorSmartphone,
  PhoneCall,
  ShieldCheck,
  Smartphone,
  Trash2,
  X,
} from "lucide-react";
import { Card } from "@/components/ui";
import { cn } from "@/lib/ui";

type SecurityInfo = {
  stats: {
    email: string | null;
    phone: string | null;
    emailVerified: boolean;
    phoneVerified: boolean;
    lastLoginAt: string | null;
    channels: { email: boolean; sms: boolean };
  };
  sessions: { token: string; current: boolean; userAgent: string | null; createdAt: string }[];
  devices: { id: number; userAgent: string | null; createdAt: string; expiresAt: string }[];
};

function shortDevice(ua: string | null): string {
  if (!ua) return "Unknown device";
  if (/iPhone/.test(ua)) return "iPhone";
  if (/iPad/.test(ua)) return "iPad";
  if (/Android/.test(ua)) return "Android";
  if (/Mac/.test(ua)) return "Mac";
  if (/Windows/.test(ua)) return "Windows";
  if (/Linux/.test(ua)) return "Linux";
  return "Browser";
}

function fmt(iso: string | null): string {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleString();
  } catch {
    return iso;
  }
}

type ModalState = null | "password" | "email" | "phone";

export function SecuritySection() {
  const router = useRouter();
  const [info, setInfo] = useState<SecurityInfo | null>(null);
  const [modal, setModal] = useState<ModalState>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [note, setNote] = useState<string | null>(null);
  const [devCode, setDevCode] = useState<string | null>(null);

  const load = useCallback(async () => {
    const res = await fetch("/api/security");
    if (res.ok) setInfo((await res.json()) as SecurityInfo);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function api(payload: Record<string, unknown>) {
    const res = await fetch("/api/security", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json().catch(() => null);
    if (!res.ok) throw new Error(data?.error ?? "Kuch galat ho gaya");
    return data as Record<string, unknown>;
  }

  async function act(fn: () => Promise<void>, done?: string) {
    setBusy(true);
    setError(null);
    try {
      await fn();
      if (done) {
        setNote(done);
        setModal(null);
        setDevCode(null);
        await load();
        router.refresh();
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error");
    } finally {
      setBusy(false);
    }
  }

  const field =
    "w-full rounded-xl border border-white/[0.08] bg-white/[0.03] px-3.5 py-2.5 text-sm text-stone-100 outline-none transition-colors placeholder:text-stone-600 focus:border-acc-400/50";
  const lbl = "mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.15em] text-stone-500";

  return (
    <Card className="p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="font-display flex items-center gap-2 text-base font-semibold text-stone-100">
          <ShieldCheck className="size-4 text-emerald-300" /> Security & devices
        </h2>
        <div className="flex flex-wrap gap-1.5 text-[10px] font-semibold">
          <span
            className={cn(
              "inline-flex items-center gap-1 rounded-full px-2.5 py-1",
              info?.stats.emailVerified
                ? "bg-emerald-400/10 text-emerald-300"
                : "bg-white/[0.04] text-stone-500",
            )}
          >
            <Mail className="size-3" /> Email {info?.stats.emailVerified ? "verified" : "—"}
          </span>
          <span
            className={cn(
              "inline-flex items-center gap-1 rounded-full px-2.5 py-1",
              info?.stats.phoneVerified
                ? "bg-emerald-400/10 text-emerald-300"
                : "bg-white/[0.04] text-stone-500",
            )}
          >
            <PhoneCall className="size-3" /> Phone {info?.stats.phoneVerified ? "verified" : "—"}
          </span>
        </div>
      </div>

      <p className="mt-2 text-[11px] text-stone-500">
        Last login: <b className="text-stone-300">{fmt(info?.stats.lastLoginAt ?? null)}</b> · Har
        login par password + OTP lagta hai (yaad kiye device par 14 din tak OTP skip)
      </p>

      {note && (
        <p className="mt-3 rounded-xl bg-emerald-400/10 px-3.5 py-2.5 text-xs font-semibold text-emerald-300">
          {note}
        </p>
      )}

      <div className="mt-4 grid gap-2 sm:grid-cols-2">
        <button
          onClick={() => {
            setModal("password");
            setNote(null);
            setError(null);
          }}
          className="flex items-center gap-3 rounded-2xl border border-white/[0.07] bg-white/[0.02] px-4 py-3 text-start transition-colors hover:border-white/[0.15]"
        >
          <KeyRound className="size-4 text-acc-300" />
          <span>
            <span className="block text-xs font-bold text-stone-200">Change password</span>
            <span className="block text-[10px] text-stone-500">Current password + OTP verify</span>
          </span>
        </button>
        <button
          onClick={() => {
            setModal("email");
            setNote(null);
            setError(null);
          }}
          className="flex items-center gap-3 rounded-2xl border border-white/[0.07] bg-white/[0.02] px-4 py-3 text-start transition-colors hover:border-white/[0.15]"
        >
          <Mail className="size-4 text-acc-300" />
          <span className="min-w-0">
            <span className="block text-xs font-bold text-stone-200">Change email</span>
            <span className="block truncate text-[10px] text-stone-500">
              {info?.stats.email ?? "add email"} — naya OTP confirm
            </span>
          </span>
        </button>
        <button
          onClick={() => {
            setModal("phone");
            setNote(null);
            setError(null);
          }}
          className="flex items-center gap-3 rounded-2xl border border-white/[0.07] bg-white/[0.02] px-4 py-3 text-start transition-colors hover:border-white/[0.15]"
        >
          <Smartphone className="size-4 text-acc-300" />
          <span className="min-w-0">
            <span className="block text-xs font-bold text-stone-200">Change phone</span>
            <span className="block truncate text-[10px] text-stone-500">
              {info?.stats.phone ?? "add phone"} — naya OTP confirm
            </span>
          </span>
        </button>
        <button
          onClick={() =>
            act(async () => {
              await api({ action: "logout-others" });
            }, "Baaki saare devices se logout ho gaya.")
          }
          disabled={busy}
          className="flex items-center gap-3 rounded-2xl border border-white/[0.07] bg-white/[0.02] px-4 py-3 text-start transition-colors hover:border-white/[0.15]"
        >
          <MonitorSmartphone className="size-4 text-acc-300" />
          <span>
            <span className="block text-xs font-bold text-stone-200">Logout other devices</span>
            <span className="block text-[10px] text-stone-500">
              {Math.max((info?.sessions.length ?? 1) - 1, 0)} active session(s)
            </span>
          </span>
        </button>
      </div>

      {info && info.devices.length > 0 && (
        <div className="mt-5">
          <p className="text-[11px] font-semibold uppercase tracking-[0.15em] text-stone-500">
            Trusted devices (OTP skip)
          </p>
          <ul className="mt-2 space-y-1.5">
            {info.devices.map((d) => (
              <li
                key={d.id}
                className="flex items-center gap-3 rounded-xl bg-white/[0.02] px-3.5 py-2.5 text-xs"
              >
                <Laptop className="size-3.5 text-stone-500" />
                <span className="flex-1 truncate text-stone-300">
                  {shortDevice(d.userAgent)} · exp {new Date(d.expiresAt).toLocaleDateString()}
                </span>
                <button
                  onClick={() =>
                    act(async () => {
                      await api({ action: "revoke-device", id: d.id });
                    }, "Device ka trust hata diya.")
                  }
                  aria-label="Revoke"
                  className="grid size-7 place-items-center rounded-lg text-stone-500 hover:text-rose-300"
                >
                  <Trash2 className="size-3.5" />
                </button>
              </li>
            ))}
          </ul>
          <button
            onClick={() =>
              act(
                async () => void (await api({ action: "revoke-all-devices" })),
                "Saare trusted devices hata diye.",
              )
            }
            disabled={busy}
            className="mt-2 text-[11px] font-semibold text-stone-500 hover:text-rose-300"
          >
            Sab ka trust hatao
          </button>
        </div>
      )}

      {/* modals */}
      {modal && (
        <SecurityModal
          kind={modal}
          busy={busy}
          error={error}
          devCode={devCode}
          onClose={() => {
            setModal(null);
            setDevCode(null);
            setError(null);
          }}
          onError={setError}
          onDev={setDevCode}
          api={api}
          field={field}
          lbl={lbl}
          onDone={(msg) => {
            setModal(null);
            setDevCode(null);
            setNote(msg);
            void load();
            router.refresh();
          }}
          setBusy={setBusy}
        />
      )}
    </Card>
  );
}

function SecurityModal({
  kind,
  busy,
  error,
  devCode,
  onClose,
  onError,
  onDev,
  api,
  field,
  lbl,
  onDone,
  setBusy,
}: {
  kind: Exclude<ModalState, null>;
  busy: boolean;
  error: string | null;
  devCode: string | null;
  onClose: () => void;
  onError: (s: string | null) => void;
  onDev: (s: string | null) => void;
  api: (p: Record<string, unknown>) => Promise<Record<string, unknown>>;
  field: string;
  lbl: string;
  onDone: (msg: string) => void;
  setBusy: (b: boolean) => void;
}) {
  const [sent, setSent] = useState(false);
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [value, setValue] = useState("");
  const [code, setCode] = useState("");

  async function start() {
    setBusy(true);
    onError(null);
    try {
      if (kind === "password") {
        if (!current) throw new Error("Current password daalo");
        const d = await api({ action: "password-send", currentPassword: current });
        onDev((d.devCode as string) ?? null);
        if (d.devCode) setCode(String(d.devCode));
      } else if (kind === "email") {
        const d = await api({ action: "email-send", email: value });
        onDev((d.devCode as string) ?? null);
        if (d.devCode) setCode(String(d.devCode));
      } else {
        const d = await api({ action: "phone-send", phone: value });
        onDev((d.devCode as string) ?? null);
        if (d.devCode) setCode(String(d.devCode));
      }
      setSent(true);
    } catch (e) {
      onError(e instanceof Error ? e.message : "Error");
    } finally {
      setBusy(false);
    }
  }

  async function confirm() {
    setBusy(true);
    onError(null);
    try {
      if (kind === "password") {
        await api({ action: "password-change", code, newPassword: next, currentPassword: current });
        onDone("Password badal gaya — agla login naye password + OTP se hoga.");
      } else if (kind === "email") {
        await api({ action: "email-confirm", email: value, code });
        onDone("Email change ho gaya ✓");
      } else {
        await api({ action: "phone-confirm", phone: value, code });
        onDone("Phone change ho gaya ✓");
      }
    } catch (e) {
      onError(e instanceof Error ? e.message : "Error");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm">
      <div className="w-full max-w-sm rounded-3xl border border-white/10 bg-ink-900 p-6 shadow-2xl">
        <div className="flex items-center justify-between">
          <h3 className="font-display text-base font-bold text-stone-50">
            {kind === "password" ? "Change password" : kind === "email" ? "Change email" : "Change phone"}
          </h3>
          <button
            onClick={onClose}
            aria-label="Close"
            className="grid size-8 place-items-center rounded-xl text-stone-500 hover:text-stone-200"
          >
            <X className="size-4" />
          </button>
        </div>

        {!sent ? (
          <div className="mt-4 space-y-3">
            {kind === "password" ? (
              <>
                <div>
                  <label className={lbl}>Current password</label>
                  <input
                    type="password"
                    value={current}
                    onChange={(e) => setCurrent(e.target.value)}
                    className={field}
                    autoFocus
                  />
                </div>
                <div>
                  <label className={lbl}>Naya password (8+, strong)</label>
                  <input
                    type="password"
                    value={next}
                    onChange={(e) => setNext(e.target.value)}
                    className={field}
                  />
                </div>
              </>
            ) : (
              <div>
                <label className={lbl}>{kind === "email" ? "Naya email" : "Naya phone (with +code)"}</label>
                <input
                  value={value}
                  onChange={(e) => setValue(e.target.value)}
                  type={kind === "email" ? "email" : "tel"}
                  className={field}
                  autoFocus
                  placeholder={kind === "email" ? "you@work.com" : "+9198xxxxxxxx"}
                />
              </div>
            )}
            {error && <p className="text-xs font-semibold text-rose-300">{error}</p>}
            <button
              onClick={start}
              disabled={busy}
              className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-acc-400 to-acc-500 py-3 text-sm font-bold text-ink-950 disabled:opacity-50"
            >
              {busy && <Loader2 className="size-4 animate-spin" />} OTP bhejo
            </button>
          </div>
        ) : (
          <div className="mt-4 space-y-3">
            <p className="text-xs text-stone-400">
              {kind === "password"
                ? "Apke verified email/phone par code bheja hai."
                : `Naye ${kind} par code bheja hai — verify karo.`}
            </p>
            {devCode && (
              <p className="rounded-xl border border-amber-400/25 bg-amber-400/10 px-3 py-2 text-[11px] text-amber-200">
                Demo code: <b className="font-mono tracking-[0.25em]">{devCode}</b> (provider keys
                ke baad real mail/SMS par jayega)
              </p>
            )}
            <input
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
              maxLength={6}
              placeholder="••••••"
              className={cn(field, "text-center font-mono text-lg tracking-[0.5em]")}
              autoFocus
            />
            {error && <p className="text-xs font-semibold text-rose-300">{error}</p>}
            <button
              onClick={confirm}
              disabled={busy || code.length !== 6}
              className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-acc-400 to-acc-500 py-3 text-sm font-bold text-ink-950 disabled:opacity-50"
            >
              {busy && <Loader2 className="size-4 animate-spin" />} Confirm
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
