import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { destroySession, getCurrentUser } from "@/lib/auth";

/** Full account wipe — groups, members and attendance cascade away. */
export async function DELETE() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  await db.delete(users).where(eq(users.id, user.id));
  await destroySession();
  return NextResponse.json({ ok: true });
}
